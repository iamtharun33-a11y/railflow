import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { useAIModal } from '../context/AIModalContext';
import { RadiumGraphVisualizer } from '../components/RadiumGraphVisualizer';
import { PNRHashVisualizer } from '../components/PNRHashVisualizer';
import { DSA_TOPICS } from '../data/dsa-content';
import {
  Train,
  ArrowRight,
  Sparkles,
  Layers,
  Hash,
  Route,
  History,
  Play,
  CheckCircle2,
  Cpu,
  Bot,
  BarChart3
} from 'lucide-react';

export const HomePage: React.FC<{ onNavigate: (path: string) => void }> = ({ onNavigate }) => {
  const { language, t } = useLanguage();
  const { user } = useAuth();
  const { openAI } = useAIModal();

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 border-b border-slate-200 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-4xl mx-auto">
            {/* Tag Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-xs font-bold uppercase tracking-wider mb-6">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              <span>Where Railway Reservation Meets Data Structures</span>
            </div>

            <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-slate-900 mb-6 leading-tight">
              {t('hero_title_1')}{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-700 via-indigo-600 to-blue-800">
                {t('hero_title_2')}
              </span>
            </h1>

            <p className="text-lg sm:text-xl text-slate-600 font-normal leading-relaxed mb-10 max-w-3xl mx-auto">
              {t('hero_subtitle')}
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center justify-center gap-4">
              <button
                onClick={() => onNavigate('/trains')}
                className="flex items-center gap-2 px-7 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-base shadow-sm shadow-blue-600/30 transition-all hover:scale-102"
              >
                <Train className="w-5 h-5" />
                <span>{t('btn_search_trains')}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => onNavigate('/barchart')}
                className="flex items-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-blue-700 to-indigo-700 hover:from-blue-800 hover:to-indigo-800 text-white font-bold text-base shadow-sm shadow-blue-700/30 transition-all hover:scale-102"
              >
                <BarChart3 className="w-5 h-5 text-amber-300" />
                <span>Bar Chart Lab (Auto Flow)</span>
              </button>

              <button
                onClick={() => onNavigate('/dsa-lab')}
                className="flex items-center gap-2 px-7 py-3.5 rounded-xl bg-white hover:bg-slate-50 border-2 border-slate-200 text-slate-800 font-bold text-base transition-all shadow-2xs hover:border-blue-400"
              >
                <Cpu className="w-5 h-5 text-blue-600" />
                <span>{t('btn_explore_dsa')}</span>
              </button>

              <button
                onClick={() => onNavigate('/dsa-game')}
                className="flex items-center gap-2 px-6 py-3.5 rounded-xl bg-purple-50 hover:bg-purple-100 border border-purple-200 text-purple-800 font-semibold text-base transition-all"
              >
                <Play className="w-4 h-4 fill-current text-purple-600" />
                <span>{t('btn_play_game')}</span>
              </button>
            </div>
          </div>

          {/* System Pipeline Infographic */}
          <div className="mt-16 bg-slate-50 border border-slate-200 rounded-2xl p-6 shadow-2xs">
            <div className="text-xs uppercase font-bold tracking-wider text-slate-500 mb-4 text-center">
              The Real-Time Railway Algorithm Execution Pipeline
            </div>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3 text-center">
              <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-2xs">
                <span className="text-xs font-mono text-blue-600 font-bold block mb-1">Step 1</span>
                <strong className="text-sm text-slate-800 block">Seat Allocation</strong>
                <span className="text-[11px] text-slate-500 font-mono">Array Slot O(1)</span>
              </div>
              <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-2xs">
                <span className="text-xs font-mono text-amber-600 font-bold block mb-1">Step 2</span>
                <strong className="text-sm text-slate-800 block">Waiting List</strong>
                <span className="text-[11px] text-slate-500 font-mono">FIFO Queue O(1)</span>
              </div>
              <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-2xs">
                <span className="text-xs font-mono text-purple-600 font-bold block mb-1">Step 3</span>
                <strong className="text-sm text-slate-800 block">PNR Generation</strong>
                <span className="text-[11px] text-slate-500 font-mono">Hash Map O(1)</span>
              </div>
              <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-2xs">
                <span className="text-xs font-mono text-emerald-600 font-bold block mb-1">Step 4</span>
                <strong className="text-sm text-slate-800 block">Track Routing</strong>
                <span className="text-[11px] text-slate-500 font-mono">Optimal Green BFS</span>
              </div>
              <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-2xs col-span-2 md:col-span-1">
                <span className="text-xs font-mono text-rose-600 font-bold block mb-1">Step 5</span>
                <strong className="text-sm text-slate-800 block">Cancellation</strong>
                <span className="text-[11px] text-slate-500 font-mono">Stack & Dequeue</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Live Clean Route Section */}
      <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-6 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-blue-700 block mb-1">
              Interactive Topology Explorer
            </span>
            <h2 className="text-3xl font-extrabold text-slate-900">
              Railway Routes & Green Route Discovery
            </h2>
            <p className="text-sm text-slate-500 mt-1">
              Normal clean network view. Click "Find Route" to calculate the easy route illuminated in vibrant green!
            </p>
          </div>
          <button
            onClick={() => onNavigate('/dsa-lab')}
            className="text-sm text-blue-700 hover:underline flex items-center gap-1 font-bold"
          >
            <span>Open in Full DSA Lab</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <RadiumGraphVisualizer />
      </section>

      {/* PNR Hash Map Live Engine Section */}
      <section className="py-16 bg-white border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8 text-center max-w-3xl mx-auto">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-600 block mb-1">
              Direct Memory Addressing
            </span>
            <h2 className="text-3xl font-extrabold text-slate-900 mb-2">
              PNR Status & Real-Time Hash Map Connector
            </h2>
            <p className="text-sm text-slate-600">
              Enter your 10-digit PNR to witness the mathematical polynomial hash function map directly to its table bucket in constant O(1) time.
            </p>
          </div>

          <PNRHashVisualizer />
        </div>
      </section>

      {/* DSA Core Knowledge Cards */}
      <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-purple-700 block mb-1">
            Data Structures Behind The Railway Engine
          </span>
          <h2 className="text-3xl font-extrabold text-slate-900 mb-3">
            The Algorithms Powering Every Ticket
          </h2>
          <p className="text-sm text-slate-600">
            Click any data structure to study its practical railway implementation, why we use it, and what happens if we do not!
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {DSA_TOPICS.slice(0, 6).map((topic) => {
            const trans = topic.translations[language] || topic.translations.en;
            return (
              <div
                key={topic.id}
                onClick={() => onNavigate('/dsa-lab')}
                className="bg-white border border-slate-200 hover:border-blue-400 rounded-2xl p-6 shadow-2xs transition-all hover:-translate-y-0.5 cursor-pointer group flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="px-2.5 py-1 rounded-md text-xs font-bold bg-blue-50 text-blue-700 font-mono">
                      {topic.shortTag}
                    </span>
                    <span className="text-xs font-mono text-emerald-700 font-bold">
                      {topic.timeComplexity}
                    </span>
                  </div>

                  <h3 className="text-xl font-bold text-slate-900 group-hover:text-blue-700 transition-colors mb-2">
                    {topic.name}
                  </h3>

                  <p className="text-sm text-slate-600 line-clamp-3 mb-4 leading-relaxed font-normal">
                    {trans.definition}
                  </p>
                </div>

                <div className="border-t border-slate-100 pt-3 flex items-center justify-between text-xs text-slate-500 font-medium">
                  <span className="truncate max-w-[200px]">{topic.railwayFeature}</span>
                  <span className="text-blue-600 group-hover:translate-x-1 transition-transform flex items-center font-bold">
                    Explore →
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Presentation & Sandbox Callout Banner */}
      <section className="py-12 bg-blue-50/70 border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h3 className="text-2xl font-bold text-slate-900 mb-1">
              Evaluating RailFlow for Hackathons, Faculty or Interviews?
            </h3>
            <p className="text-sm text-slate-600">
              Explore the dedicated Presentation Mode and Waiting Queue Simulation Sandbox without touching production data.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('/simulation')}
              className="px-5 py-2.5 bg-white hover:bg-slate-50 border border-slate-200 text-slate-800 font-bold rounded-xl text-sm transition-all shadow-2xs"
            >
              Queue Sandbox
            </button>
            <button
              onClick={() => onNavigate('/presentation')}
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-sm transition-all shadow-sm shadow-blue-600/30"
            >
              Open Presentation Deck
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
