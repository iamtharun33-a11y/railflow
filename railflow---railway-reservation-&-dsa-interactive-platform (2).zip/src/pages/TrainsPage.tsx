import React, { useState, useEffect } from 'react';
import { Train, Station, TrainClassConfig } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { Search, Train as TrainIcon, Calendar, ArrowRight, ShieldCheck, Clock, Users, CheckCircle, AlertCircle } from 'lucide-react';

interface TrainsPageProps {
  onNavigate: (path: string, state?: any) => void;
}

export const TrainsPage: React.FC<TrainsPageProps> = ({ onNavigate }) => {
  const { language, t } = useLanguage();
  const { user } = useAuth();
  const [stations, setStations] = useState<Station[]>([]);
  const [fromStation, setFromStation] = useState<string>('MAS');
  const [toStation, setToStation] = useState<string>('SBC');
  const [journeyDate, setJourneyDate] = useState<string>(
    new Date(Date.now() + 86400000).toISOString().split('T')[0]
  );
  const [trains, setTrains] = useState<Train[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedClassMap, setSelectedClassMap] = useState<Record<string, TrainClassConfig>>({});

  useEffect(() => {
    fetch('/api/stations')
      .then((res) => res.json())
      .then((data) => {
        if (data.stations) {
          setStations(data.stations);
        }
      });
  }, []);

  const searchTrains = async () => {
    setLoading(true);
    try {
      const query = new URLSearchParams({
        from: fromStation,
        to: toStation,
        date: journeyDate
      });
      const res = await fetch(`/api/trains?${query.toString()}`);
      const data = await res.json();
      setTrains(data.trains || []);

      const classMap: Record<string, TrainClassConfig> = {};
      data.trains?.forEach((tr: Train) => {
        if (tr.classAvailabilities && tr.classAvailabilities.length > 0) {
          classMap[tr.id] = tr.classAvailabilities[0];
        }
      });
      setSelectedClassMap(classMap);
    } catch (e) {
      console.error('Failed to search trains', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    searchTrains();
  }, [fromStation, toStation, journeyDate]);

  const handleBookNow = (train: Train) => {
    const selectedClass = selectedClassMap[train.id] || train.classes[0];
    onNavigate('/book', {
      train,
      journeyDate,
      travelClass: selectedClass.type,
      selectedClassConfig: selectedClass
    });
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-2">
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200 uppercase tracking-wider">
              Real-Time Seat Inventory & Waiting List
            </span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900">
            Search & Book Real Trains
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Real trains and actual seat inventory. If capacity is exhausted, tickets automatically join the FIFO Waiting List queue!
          </p>
        </div>

        {/* Search Bar Form */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 mb-10 shadow-xs">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">
                From Station
              </label>
              <select
                value={fromStation}
                onChange={(e) => setFromStation(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-800 focus:outline-none focus:border-blue-500 font-semibold"
              >
                {stations.map((s) => (
                  <option key={s.id} value={s.code}>
                    {s.name} ({s.code}) - {s.state}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">
                To Station
              </label>
              <select
                value={toStation}
                onChange={(e) => setToStation(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-800 focus:outline-none focus:border-blue-500 font-semibold"
              >
                {stations.map((s) => (
                  <option key={s.id} value={s.code}>
                    {s.name} ({s.code}) - {s.state}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">
                Journey Date
              </label>
              <input
                type="date"
                value={journeyDate}
                min={new Date().toISOString().split('T')[0]}
                onChange={(e) => setJourneyDate(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-800 focus:outline-none focus:border-blue-500 font-semibold"
              />
            </div>
          </div>
        </div>

        {/* Trains Results List */}
        {loading ? (
          <div className="py-20 text-center">
            <TrainIcon className="w-8 h-8 text-blue-600 animate-bounce mx-auto mb-3" />
            <p className="text-slate-500 text-sm font-medium">Searching real trains & calculating seat inventory...</p>
          </div>
        ) : trains.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-3xl p-12 text-center text-slate-500 shadow-xs">
            <AlertCircle className="w-12 h-12 text-amber-500 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-slate-900 mb-1">No direct trains found for this route</h3>
            <p className="text-sm text-slate-500 max-w-md mx-auto mb-6">
              Try searching popular routes like <strong>Chennai (MAS) → Bengaluru (SBC)</strong> or <strong>New Delhi (NDLS) → Mumbai (BCT)</strong>.
            </p>
            <button
              onClick={() => {
                setFromStation('MAS');
                setToStation('SBC');
              }}
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-sm transition-all shadow-xs"
            >
              Reset to Chennai → Bengaluru
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            {trains.map((train) => {
              const activeClass = selectedClassMap[train.id] || train.classes[0];
              const isWL = activeClass.isWaitingList || (activeClass.availableSeats ?? 0) <= 0;

              return (
                <div
                  key={train.id}
                  className="bg-white border border-slate-200 hover:border-blue-300 rounded-3xl p-6 shadow-xs transition-all"
                >
                  {/* Train Top Info */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4 mb-4">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-mono text-xs font-bold px-2.5 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200">
                          #{train.trainNumber}
                        </span>
                        <h3 className="text-xl font-bold text-slate-900">{train.name}</h3>
                      </div>
                      <span className="text-xs text-slate-500 font-medium">
                        Runs on: {train.runsOn.join(', ')}
                      </span>
                    </div>

                    <div className="flex items-center gap-6 text-sm">
                      <div className="text-left sm:text-right">
                        <span className="text-lg font-bold text-slate-900">{train.departureTime}</span>
                        <span className="text-xs text-slate-500 block">{fromStation}</span>
                      </div>
                      <div className="flex flex-col items-center">
                        <span className="text-xs text-slate-500 font-mono">{train.duration}</span>
                        <div className="w-16 h-0.5 bg-slate-300 relative my-1">
                          <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-blue-600" />
                        </div>
                        <span className="text-[10px] text-emerald-700 font-bold">Direct Track</span>
                      </div>
                      <div>
                        <span className="text-lg font-bold text-slate-900">{train.arrivalTime}</span>
                        <span className="text-xs text-slate-500 block">{toStation}</span>
                      </div>
                    </div>
                  </div>

                  {/* Classes Selector */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
                    {train.classAvailabilities?.map((cls) => {
                      const isSelected = activeClass.type === cls.type;
                      const isWaiting = cls.isWaitingList || (cls.availableSeats ?? 0) <= 0;

                      return (
                        <div
                          key={cls.type}
                          onClick={() => {
                            setSelectedClassMap({
                              ...selectedClassMap,
                              [train.id]: cls
                            });
                          }}
                          className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                            isSelected
                              ? 'bg-blue-50 border-blue-600 shadow-xs ring-2 ring-blue-500/20'
                              : 'bg-slate-50 border-slate-200 hover:border-slate-300'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-bold text-slate-900 text-sm">{cls.name}</span>
                            <span className="font-mono text-xs text-blue-700 font-bold">
                              ₹{cls.fare}
                            </span>
                          </div>

                          <div className="flex items-center justify-between text-xs">
                            <span className="text-slate-500 font-medium">{cls.type}</span>
                            {isWaiting ? (
                              <span className="font-bold text-amber-700 font-mono">
                                WL {cls.waitingCount ? cls.waitingCount + 1 : 1}
                              </span>
                            ) : (
                              <span className="font-bold text-emerald-700 font-mono">
                                AVL - {cls.availableSeats}
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Booking CTA Bar */}
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-3 border-t border-slate-100">
                    <div className="text-xs">
                      {isWL ? (
                        <div className="flex items-center gap-1.5 text-amber-700 font-medium">
                          <AlertCircle className="w-4 h-4 shrink-0" />
                          <span>
                            Confirmed seats are full. Joining the <strong>FIFO Waiting List (Queue)</strong>.
                          </span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5 text-emerald-700 font-medium">
                          <CheckCircle className="w-4 h-4 shrink-0" />
                          <span>
                            Seats available! Instant O(1) array slot allocation.
                          </span>
                        </div>
                      )}
                    </div>

                    <button
                      onClick={() => handleBookNow(train)}
                      className="w-full sm:w-auto px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-sm transition-all shadow-sm shadow-blue-600/30 flex items-center justify-center gap-2"
                    >
                      <span>{isWL ? 'Join Waiting List' : 'Book Confirmed Seat'}</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
