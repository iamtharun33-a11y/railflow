import React, { useState } from 'react';
import { GAME_CHALLENGES } from '../data/dsa-content';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { useAIModal } from '../context/AIModalContext';
import confetti from 'canvas-confetti';
import {
  Gamepad2,
  Trophy,
  CheckCircle2,
  XCircle,
  Sparkles,
  HelpCircle,
  ArrowRight,
  RotateCcw
} from 'lucide-react';

export const DSAGamePage: React.FC<{ onNavigate: (path: string) => void }> = ({ onNavigate }) => {
  const { language } = useLanguage();
  const { user, updateUserXp } = useAuth();
  const { openAI } = useAIModal();

  const [currentLevelIdx, setCurrentLevelIdx] = useState<number>(0);
  const [selectedOptionId, setSelectedOptionId] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [showHint, setShowHint] = useState<boolean>(false);
  const [score, setScore] = useState<number>(0);

  const challenge = GAME_CHALLENGES[currentLevelIdx];
  const levelTitle = challenge.levelTitle[language] || challenge.levelTitle.en;
  const scenario = challenge.scenario[language] || challenge.scenario.en;
  const question = challenge.question[language] || challenge.question.en;
  const hint = challenge.hint[language] || challenge.hint.en;

  const handleSelectOption = (optId: string) => {
    if (isAnswered) return;
    setSelectedOptionId(optId);
  };

  const handleSubmitAnswer = async () => {
    if (!selectedOptionId || isAnswered) return;

    const chosen = challenge.options.find((o) => o.id === selectedOptionId);
    const isCorrect = chosen?.isCorrect || false;
    setIsAnswered(true);

    if (isCorrect) {
      setScore((prev) => prev + 100);
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch {}
    }

    if (user) {
      try {
        const res = await fetch('/api/game/submit', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            level: challenge.level,
            challengeId: challenge.id,
            selectedOption: selectedOptionId,
            isCorrect,
            score: isCorrect ? 100 : 0,
            xpEarned: isCorrect ? 100 : 0,
            language
          })
        });
        const data = await res.json();
        if (data.totalXp) {
          updateUserXp(data.totalXp, data.level);
        }
      } catch (err) {
        console.error('Failed to submit game progress', err);
      }
    }
  };

  const handleNextLevel = () => {
    if (currentLevelIdx < GAME_CHALLENGES.length - 1) {
      setCurrentLevelIdx((prev) => prev + 1);
      setSelectedOptionId(null);
      setIsAnswered(false);
      setShowHint(false);
    } else {
      confetti({
        particleCount: 150,
        spread: 100,
        origin: { y: 0.5 }
      });
    }
  };

  const handleRestart = () => {
    setCurrentLevelIdx(0);
    setSelectedOptionId(null);
    setIsAnswered(false);
    setShowHint(false);
    setScore(0);
  };

  const selectedOpt = challenge.options.find((o) => o.id === selectedOptionId);
  const isGameCompleted = currentLevelIdx === GAME_CHALLENGES.length - 1 && isAnswered;

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        {/* Top Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-5 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-3 py-0.5 rounded-full text-xs font-bold bg-purple-50 text-purple-700 border border-purple-200 uppercase tracking-wider flex items-center gap-1.5">
                <Gamepad2 className="w-3.5 h-3.5" />
                Railway Algorithm Control
              </span>
              <span className="text-xs text-amber-600 font-mono font-bold">+100 XP per Level</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900">DSA Challenge Game</h1>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-white border border-slate-200 rounded-2xl px-4 py-2 flex items-center gap-2 shadow-2xs">
              <Trophy className="w-4 h-4 text-amber-500" />
              <span className="text-xs text-slate-500 font-medium">Score:</span>
              <strong className="text-sm font-mono text-slate-900">{score} XP</strong>
            </div>

            {user && (
              <div className="bg-blue-50 border border-blue-200 rounded-2xl px-4 py-2 text-xs">
                <span className="text-slate-500 font-medium">User Level: </span>
                <strong className="text-blue-700 font-mono">Lv.{user.level}</strong>
              </div>
            )}
          </div>
        </div>

        {/* Level Progression Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium mb-2">
            <span>Progress: Level {currentLevelIdx + 1} of {GAME_CHALLENGES.length}</span>
            <span>{Math.round(((currentLevelIdx + (isAnswered ? 1 : 0)) / GAME_CHALLENGES.length) * 100)}%</span>
          </div>
          <div className="w-full h-2.5 bg-slate-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-blue-600 transition-all duration-500"
              style={{
                width: `${((currentLevelIdx + (isAnswered ? 1 : 0)) / GAME_CHALLENGES.length) * 100}%`
              }}
            />
          </div>
        </div>

        {/* Main Challenge Card */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-xs relative overflow-hidden mb-8">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-6">
            <span className="text-xs font-mono font-bold uppercase tracking-wider text-purple-700">
              {levelTitle}
            </span>
            <span className="text-xs font-mono text-slate-500 font-medium">
              Concept: <strong className="text-slate-800">{challenge.dsaConcept}</strong>
            </span>
          </div>

          {/* Scenario Description */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 mb-6 text-sm text-slate-700 leading-relaxed font-medium">
            <strong className="text-amber-800 block text-xs uppercase tracking-wider mb-1 font-bold">
              Railway Scenario:
            </strong>
            {scenario}
          </div>

          {/* Question */}
          <h3 className="text-xl sm:text-2xl font-bold text-slate-900 mb-6 leading-snug">
            {question}
          </h3>

          {/* Options */}
          <div className="space-y-3 mb-8">
            {challenge.options.map((opt) => {
              const isSelected = selectedOptionId === opt.id;
              const label = opt.label[language] || opt.label.en;

              let cardStyle = 'bg-slate-50 border-slate-200 hover:border-slate-300 text-slate-700';
              if (isSelected && !isAnswered) {
                cardStyle = 'bg-blue-50 border-blue-600 text-blue-950 shadow-xs ring-2 ring-blue-500/20';
              } else if (isAnswered) {
                if (opt.isCorrect) {
                  cardStyle = 'bg-emerald-50 border-emerald-500 text-emerald-950 shadow-xs';
                } else if (isSelected && !opt.isCorrect) {
                  cardStyle = 'bg-rose-50 border-rose-500 text-rose-950';
                }
              }

              return (
                <div
                  key={opt.id}
                  onClick={() => handleSelectOption(opt.id)}
                  className={`p-4 rounded-2xl border cursor-pointer transition-all flex items-center justify-between ${cardStyle}`}
                >
                  <span className="font-bold text-base">{label}</span>
                  {isAnswered && opt.isCorrect && (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  )}
                  {isAnswered && isSelected && !opt.isCorrect && (
                    <XCircle className="w-5 h-5 text-rose-600" />
                  )}
                </div>
              );
            })}
          </div>

          {/* Hint Section */}
          <div className="mb-6">
            {!showHint ? (
              <button
                onClick={() => setShowHint(true)}
                className="text-xs text-slate-500 hover:text-amber-600 flex items-center gap-1 transition-colors font-medium"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Need a Hint?</span>
              </button>
            ) : (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 font-medium">
                <strong>Hint: </strong> {hint}
              </div>
            )}
          </div>

          {/* Answer Explanation Box */}
          {isAnswered && selectedOpt && (
            <div
              className={`p-5 rounded-2xl border mb-6 text-sm leading-relaxed ${
                selectedOpt.isCorrect
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-950 shadow-2xs'
                  : 'bg-rose-50 border-rose-300 text-rose-950'
              }`}
            >
              <div className="flex items-center gap-2 font-bold mb-1.5">
                {selectedOpt.isCorrect ? (
                  <>
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    <span className="text-slate-900 text-base">Brilliant! +100 XP Earned</span>
                  </>
                ) : (
                  <>
                    <XCircle className="w-5 h-5 text-rose-600" />
                    <span className="text-slate-900 text-base">Not quite right</span>
                  </>
                )}
              </div>
              <p className="font-medium">{selectedOpt.explanation[language] || selectedOpt.explanation.en}</p>
            </div>
          )}

          {/* Action Bar */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-100">
            {!isAnswered ? (
              <button
                onClick={handleSubmitAnswer}
                disabled={!selectedOptionId}
                className="px-6 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-400 text-white font-bold rounded-xl text-sm transition-all shadow-xs"
              >
                Submit Answer
              </button>
            ) : currentLevelIdx < GAME_CHALLENGES.length - 1 ? (
              <button
                onClick={handleNextLevel}
                className="flex items-center gap-2 px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-sm transition-all shadow-xs"
              >
                <span>Next Challenge</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <div className="flex items-center gap-3">
                <span className="text-sm font-bold text-emerald-700">All Levels Mastered!</span>
                <button
                  onClick={handleRestart}
                  className="flex items-center gap-1.5 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition-all"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Play Again</span>
                </button>
              </div>
            )}

            <button
              onClick={() =>
                openAI(
                  `In the railway challenge "${levelTitle}", why does ${challenge.dsaConcept} apply?`,
                  `Challenge: ${levelTitle}`
                )
              }
              className="text-xs text-blue-700 hover:text-blue-800 font-bold flex items-center gap-1"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Ask AI Guide</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
