import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import {
  Layers,
  RotateCcw,
  Plus,
  Trash2,
  CheckCircle2,
  ShieldAlert
} from 'lucide-react';

interface SimPassenger {
  id: string;
  name: string;
  status: 'CONFIRMED' | 'WAITING';
  seatNumber?: string;
  waitingPosition?: number;
}

export const SimulationPage: React.FC = () => {
  const { language } = useLanguage();
  const [capacity, setCapacity] = useState<number>(2);
  const [passengers, setPassengers] = useState<SimPassenger[]>([
    { id: 'sim_1', name: 'Passenger Alpha', status: 'CONFIRMED', seatNumber: 'Seat-1' },
    { id: 'sim_2', name: 'Passenger Beta', status: 'CONFIRMED', seatNumber: 'Seat-2' },
    { id: 'sim_3', name: 'Passenger Charlie', status: 'WAITING', waitingPosition: 1 },
    { id: 'sim_4', name: 'Passenger David', status: 'WAITING', waitingPosition: 2 }
  ]);
  const [newName, setNewName] = useState('');
  const [lastEvent, setLastEvent] = useState<string>(
    'Simulation initialized. 2 Confirmed seats (Alpha, Beta), 2 Waiting list entries in FIFO Queue (Charlie WL1, David WL2).'
  );

  const confirmedList = passengers.filter((p) => p.status === 'CONFIRMED');
  const waitingQueue = passengers
    .filter((p) => p.status === 'WAITING')
    .sort((a, b) => (a.waitingPosition || 0) - (b.waitingPosition || 0));

  const handleAddPassenger = () => {
    const name = newName.trim() || `Passenger ${String.fromCharCode(65 + passengers.length)}`;
    const isAvailable = confirmedList.length < capacity;

    if (isAvailable) {
      const seatNumber = `Seat-${confirmedList.length + 1}`;
      const newP: SimPassenger = {
        id: 'sim_' + Date.now(),
        name,
        status: 'CONFIRMED',
        seatNumber
      };
      setPassengers([...passengers, newP]);
      setLastEvent(`Direct Slot Allocation: ${name} booked ${seatNumber} in constant O(1) time.`);
    } else {
      const nextWlPos = waitingQueue.length + 1;
      const newP: SimPassenger = {
        id: 'sim_' + Date.now(),
        name,
        status: 'WAITING',
        waitingPosition: nextWlPos
      };
      setPassengers([...passengers, newP]);
      setLastEvent(
        `FIFO Queue Enqueue: Coach full. ${name} joined rear of Waiting List at Position WL${nextWlPos} (O(1) enqueue).`
      );
    }
    setNewName('');
  };

  const handleCancelPassenger = (id: string) => {
    const target = passengers.find((p) => p.id === id);
    if (!target) return;

    if (target.status === 'CONFIRMED') {
      const releasedSeat = target.seatNumber || 'Seat-1';
      const remainingPassengers = passengers.filter((p) => p.id !== id);

      const currentWaiting = remainingPassengers
        .filter((p) => p.status === 'WAITING')
        .sort((a, b) => (a.waitingPosition || 0) - (b.waitingPosition || 0));

      if (currentWaiting.length > 0) {
        const promoted = currentWaiting[0];
        promoted.status = 'CONFIRMED';
        promoted.seatNumber = releasedSeat;
        promoted.waitingPosition = undefined;

        currentWaiting.slice(1).forEach((p, idx) => {
          p.waitingPosition = idx + 1;
        });

        setLastEvent(
          `FIFO DEQUEUE & PROMOTION: ${target.name} cancelled ${releasedSeat}. Earliest waitlist passenger "${promoted.name}" dequeued from WL1 and promoted to CONFIRMED! Remaining waitlist shifted up.`
        );
      } else {
        setLastEvent(`Seat Released: ${target.name} cancelled ${releasedSeat}. No waiting passengers; seat is now free.`);
      }

      setPassengers([...remainingPassengers]);
    } else {
      const remainingPassengers = passengers.filter((p) => p.id !== id);
      const remainingWaiting = remainingPassengers
        .filter((p) => p.status === 'WAITING')
        .sort((a, b) => (a.waitingPosition || 0) - (b.waitingPosition || 0));

      remainingWaiting.forEach((p, idx) => {
        p.waitingPosition = idx + 1;
      });

      setPassengers(remainingPassengers);
      setLastEvent(`Waiting entry for ${target.name} cancelled. Queue indices re-calculated.`);
    }
  };

  const handleReset = () => {
    setPassengers([
      { id: 'sim_1', name: 'Passenger Alpha', status: 'CONFIRMED', seatNumber: 'Seat-1' },
      { id: 'sim_2', name: 'Passenger Beta', status: 'CONFIRMED', seatNumber: 'Seat-2' },
      { id: 'sim_3', name: 'Passenger Charlie', status: 'WAITING', waitingPosition: 1 },
      { id: 'sim_4', name: 'Passenger David', status: 'WAITING', waitingPosition: 2 }
    ]);
    setLastEvent('Simulation reset to standard testing benchmark (2 Confirmed, 2 Waiting).');
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto">
        {/* Banner Alert */}
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 mb-8 flex items-center gap-3 text-xs text-amber-900 font-medium">
          <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0" />
          <span>
            <strong>ISOLATED SIMULATION SANDBOX:</strong> In-memory algorithm playground for faculty and evaluators to test waiting queue capacity, cancellation, and promotion without modifying production database data.
          </span>
        </div>

        {/* Title */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-5 mb-8">
          <div>
            <h1 className="text-3xl font-extrabold text-slate-900">Waiting Queue Algorithm Sandbox</h1>
            <p className="text-sm text-slate-500 mt-1">
              Test custom coach capacities, add passengers, cancel tickets, and watch FIFO queue dequeue and promotions live!
            </p>
          </div>

          <button
            onClick={handleReset}
            className="flex items-center gap-1.5 px-4 py-2 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-all shadow-2xs self-start sm:self-auto"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Scenario</span>
          </button>
        </div>

        {/* Control Bar */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 mb-8 shadow-xs">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
            <div>
              <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">
                Coach Capacity (Confirmed Seats)
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min="1"
                  max="10"
                  value={capacity}
                  onChange={(e) => setCapacity(Math.max(1, parseInt(e.target.value, 10) || 1))}
                  className="w-24 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 font-mono text-center font-bold"
                />
                <span className="text-xs text-slate-500 font-medium">Total Berths</span>
              </div>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">
                Add Simulated Passenger
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="e.g. Passenger Ethan..."
                  className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-sm text-slate-800 focus:outline-none focus:border-blue-500 font-medium"
                />
                <button
                  onClick={handleAddPassenger}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-sm transition-all shadow-xs"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Event Log Output */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 text-xs flex items-center gap-2">
            <span className="px-2 py-0.5 rounded-md bg-blue-100 text-blue-800 font-mono font-bold uppercase shrink-0">
              DSA Event
            </span>
            <span className="text-slate-700 font-medium leading-relaxed">{lastEvent}</span>
          </div>
        </div>

        {/* Confirmed Seats & FIFO Queue View */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Confirmed Seats */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs">
            <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                <span>Confirmed Seats ({confirmedList.length}/{capacity})</span>
              </h3>
              <span className="text-xs text-emerald-700 font-mono font-bold">Array Indexed Slots</span>
            </div>

            <div className="space-y-3">
              {confirmedList.map((p) => (
                <div
                  key={p.id}
                  className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between"
                >
                  <div>
                    <span className="font-bold text-slate-900 text-sm block">{p.name}</span>
                    <span className="text-xs font-mono text-emerald-700 font-bold">{p.seatNumber}</span>
                  </div>

                  <button
                    onClick={() => handleCancelPassenger(p.id)}
                    className="px-3 py-1 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 text-xs font-bold rounded-lg transition-all"
                  >
                    Cancel Seat
                  </button>
                </div>
              ))}

              {confirmedList.length === 0 && (
                <div className="text-center py-8 text-slate-400 text-sm">All confirmed seats are empty.</div>
              )}
            </div>
          </div>

          {/* FIFO Waiting Queue */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs">
            <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Layers className="w-5 h-5 text-amber-600" />
                <span>Waiting List Queue ({waitingQueue.length})</span>
              </h3>
              <span className="text-xs text-amber-700 font-mono font-bold">FIFO Queue</span>
            </div>

            <div className="space-y-3">
              {waitingQueue.map((p, idx) => (
                <div
                  key={p.id}
                  className={`p-3.5 rounded-2xl border flex items-center justify-between transition-all ${
                    idx === 0
                      ? 'bg-amber-50/80 border-amber-300'
                      : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <div>
                    <span className="font-bold text-slate-900 text-sm block">{p.name}</span>
                    <span className="text-xs font-mono text-amber-800 font-bold">
                      Position: WL{p.waitingPosition} {idx === 0 ? '(Earliest • Next Dequeue)' : ''}
                    </span>
                  </div>

                  <button
                    onClick={() => handleCancelPassenger(p.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}

              {waitingQueue.length === 0 && (
                <div className="text-center py-8 text-slate-400 text-sm">
                  Waiting list is empty. Add passengers after filling confirmed capacity.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
