import React, { useState, useEffect } from 'react';
import { Booking, DSAEvent } from '../types';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import {
  Ticket,
  Train,
  Calendar,
  AlertTriangle,
  RotateCcw,
  CheckCircle,
  Hash,
  Sparkles,
  ArrowRight
} from 'lucide-react';

interface MyTicketsPageProps {
  onNavigate: (path: string, state?: any) => void;
}

export const MyTicketsPage: React.FC<MyTicketsPageProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const { language, t } = useLanguage();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [cancellationResult, setCancellationResult] = useState<{
    cancelledBooking: Booking;
    promotedBooking?: Booking;
    events: DSAEvent[];
  } | null>(null);

  const fetchBookings = async () => {
    if (!user) {
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/bookings/my');
      const data = await res.json();
      setBookings(data.bookings || []);
    } catch (err) {
      console.error('Failed to fetch user bookings', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBookings();
  }, [user]);

  const handleCancelBooking = async (bookingId: string) => {
    if (!confirm('Are you sure you want to cancel this booking? This will release the seat and dequeue the earliest passenger on the waiting list.')) {
      return;
    }

    try {
      const res = await fetch(`/api/bookings/${bookingId}/cancel`, {
        method: 'POST'
      });
      const data = await res.json();
      if (!res.ok) {
        alert(data.error || 'Cancellation failed');
        return;
      }
      setCancellationResult(data);
      fetchBookings();
    } catch (err: any) {
      alert(err.message || 'Cancellation failed');
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] text-slate-800 py-20 px-4 text-center">
        <Ticket className="w-12 h-12 text-blue-600 mx-auto mb-4" />
        <h2 className="text-2xl font-bold mb-2 text-slate-900">Login Required</h2>
        <p className="text-slate-500 text-sm mb-6">Please log in or register to view your real bookings.</p>
        <button
          onClick={() => onNavigate('/login')}
          className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-sm shadow-xs"
        >
          Go to Login
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-5 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200 uppercase tracking-wider">
                Real User Tickets
              </span>
            </div>
            <h1 className="text-3xl font-extrabold text-slate-900">My Journey Tickets</h1>
            <p className="text-sm text-slate-500">
              Only authentic database records for {user.name} ({user.email}). No fake bookings.
            </p>
          </div>

          <button
            onClick={() => onNavigate('/trains')}
            className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-sm transition-all shadow-xs self-start sm:self-auto"
          >
            <Train className="w-4 h-4" />
            <span>Book New Train</span>
          </button>
        </div>

        {/* Cancellation Promotion Event Banner (If just executed) */}
        {cancellationResult && (
          <div className="bg-emerald-50 border-2 border-emerald-400 rounded-3xl p-6 mb-8 shadow-xs animate-in fade-in">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-5 h-5 text-emerald-600" />
              <h3 className="text-lg font-bold text-emerald-950 uppercase tracking-wider">
                FIFO Queue Dequeue & Seat Promotion Executed!
              </h3>
            </div>

            <p className="text-sm text-emerald-900 mb-4 leading-relaxed font-medium">
              Ticket for PNR <code className="text-blue-700 font-mono font-bold">{cancellationResult.cancelledBooking.pnr}</code> was cancelled. 
              {cancellationResult.promotedBooking ? (
                <span>
                  {' '}The waiting list engine immediately executed <strong>dequeue()</strong> and promoted passenger PNR{' '}
                  <code className="text-emerald-700 font-mono font-bold">{cancellationResult.promotedBooking.pnr}</code> from Waiting List to <strong>CONFIRMED</strong>!
                </span>
              ) : (
                <span> The seat was safely returned to inventory and cancellation was pushed to the audit Stack.</span>
              )}
            </p>

            <div className="bg-white border border-emerald-200 rounded-xl p-3 text-xs space-y-1 text-slate-700 shadow-2xs">
              {cancellationResult.events.map((ev, i) => (
                <div key={i} className="flex items-start gap-2">
                  <span className="font-mono text-emerald-700 font-bold">[{ev.type}]</span>
                  <span>{ev.details}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Bookings List */}
        {loading ? (
          <div className="py-20 text-center text-slate-400">Loading your tickets...</div>
        ) : bookings.length === 0 ? (
          /* Clean Professional Empty State */
          <div className="bg-white border border-slate-200 rounded-3xl p-12 text-center max-w-lg mx-auto shadow-xs">
            <Ticket className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-slate-900 mb-2">{t('empty_tickets_title')}</h3>
            <p className="text-sm text-slate-500 mb-6 leading-relaxed">
              {t('empty_tickets_desc')}
            </p>
            <button
              onClick={() => onNavigate('/trains')}
              className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-sm transition-all shadow-sm shadow-blue-600/30"
            >
              Search Trains
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            {bookings.map((booking) => {
              const isCancelled = booking.status === 'CANCELLED';
              const isConfirmed = booking.status === 'CONFIRMED';
              const isWaiting = booking.status === 'WAITING';

              return (
                <div
                  key={booking.id}
                  className={`bg-white border rounded-3xl p-6 shadow-xs transition-all ${
                    isCancelled
                      ? 'border-slate-200 opacity-60'
                      : isConfirmed
                      ? 'border-emerald-300 hover:border-emerald-500'
                      : 'border-amber-300 hover:border-amber-500'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4 mb-4">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-mono text-base font-extrabold text-blue-700 tracking-wider">
                          PNR: {booking.pnr}
                        </span>
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider ${
                            isConfirmed
                              ? 'bg-emerald-100 text-emerald-800'
                              : isWaiting
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {booking.status}
                          {booking.waitingNumber ? ` (WL${booking.waitingNumber})` : ''}
                        </span>
                      </div>
                      <h3 className="text-lg font-bold text-slate-900">
                        {booking.trainName} (#{booking.trainNumber})
                      </h3>
                    </div>

                    <div className="text-right text-xs">
                      <span className="text-slate-500 block font-medium">Travel Date</span>
                      <strong className="text-slate-800 text-sm font-mono">{booking.journeyDate}</strong>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs mb-4">
                    <div>
                      <span className="text-slate-500 block font-medium">Route</span>
                      <strong className="text-slate-800 text-sm">
                        {booking.fromStationCode} → {booking.toStationCode}
                      </strong>
                    </div>
                    <div>
                      <span className="text-slate-500 block font-medium">Class</span>
                      <strong className="text-blue-700 text-sm font-bold">{booking.travelClass}</strong>
                    </div>
                    <div>
                      <span className="text-slate-500 block font-medium">Passengers</span>
                      <strong className="text-slate-800 text-sm font-semibold">{booking.passengers.length} Person(s)</strong>
                    </div>
                    <div>
                      <span className="text-slate-500 block font-medium">Total Fare</span>
                      <strong className="text-slate-800 text-sm font-mono font-bold">₹{booking.totalFare}</strong>
                    </div>
                  </div>

                  {/* Passenger berths */}
                  <div className="bg-slate-50 rounded-2xl p-3.5 mb-4 space-y-1 border border-slate-100">
                    {booking.passengers.map((p, i) => (
                      <div key={i} className="flex items-center justify-between text-xs font-medium">
                        <span className="text-slate-700">
                          {p.name} ({p.gender}, {p.age} yrs)
                        </span>
                        <strong className="text-emerald-700 font-mono font-bold">
                          {p.allocatedSeat} ({p.allocatedBerth})
                        </strong>
                      </div>
                    ))}
                  </div>

                  {/* Actions */}
                  <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                    <button
                      onClick={() => onNavigate('/pnr', { pnr: booking.pnr })}
                      className="text-xs text-blue-700 hover:text-blue-800 font-bold flex items-center gap-1.5"
                    >
                      <Hash className="w-3.5 h-3.5" />
                      <span>Inspect in Hash Map Visualizer</span>
                    </button>

                    {!isCancelled && (
                      <button
                        onClick={() => handleCancelBooking(booking.id)}
                        className="px-4 py-2 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 rounded-xl text-xs font-bold transition-all"
                      >
                        Cancel Ticket & Promote Waitlist
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
