import React, { useState } from 'react';
import { BarChartSearchVisualizer } from '../components/BarChartSearchVisualizer';
import { BarChartSortingVisualizer } from '../components/BarChartSortingVisualizer';
import { useLanguage } from '../context/LanguageContext';
import { useAIModal } from '../context/AIModalContext';
import { BarChart3, Search, ArrowDownUp, Sparkles, Bot, CheckCircle2, AlertTriangle, Clock, HardDrive, Train } from 'lucide-react';
import { DSA_TOPICS } from '../data/dsa-content';

export const BarChartLabPage: React.FC<{ onNavigate?: (path: string) => void }> = ({ onNavigate }) => {
  const { language } = useLanguage();
  const { openAI } = useAIModal();
  const [activeTab, setActiveTab] = useState<'sorting' | 'search'>('sorting');

  const binaryTopic = DSA_TOPICS.find((t) => t.id === 'binarysearch') || DSA_TOPICS[0];
  const sortingTopic = DSA_TOPICS.find((t) => t.id === 'sorting') || DSA_TOPICS[0];
  const currentTopic = activeTab === 'sorting' ? sortingTopic : binaryTopic;
  const trans = currentTopic.translations[language] || currentTopic.translations.en;

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Page Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200 uppercase tracking-wider flex items-center gap-1.5">
                <BarChart3 className="w-3.5 h-3.5" />
                Big Bar Chart Sorting & Algorithm Suite
              </span>
              <span className="text-xs text-emerald-700 font-mono font-bold">
                Selection • Insertion • Bubble • Merge Sort • Live Code Below
              </span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              Bar Chart Sorting Laboratory (Auto Step & Instant Sort)
            </h1>
            <p className="text-sm text-slate-600 mt-1 max-w-3xl font-medium">
              Watch real-time big bar chart animations for Selection Sort, Insertion Sort, Bubble Sort, and Merge Sort. Auto-sort step-by-step, view algorithm code below, or click Instant Sort for the full answer!
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() =>
                openAI(
                  `Explain Selection Sort, Insertion Sort, Bubble Sort, and Merge Sort with real step-by-step calculations and code.`,
                  `Bar Chart Sorting Laboratory`
                )
              }
              className="flex items-center gap-2 px-5 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-md shadow-blue-600/30 transition-all"
            >
              <Bot className="w-4 h-4 text-white" />
              <span>Ask AI Guide</span>
            </button>
          </div>
        </div>

        {/* View Switcher: Sorting vs Binary Search */}
        <div className="flex items-center bg-slate-200/80 p-1.5 rounded-2xl w-fit border border-slate-300">
          <button
            onClick={() => setActiveTab('sorting')}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-xl font-extrabold text-sm transition-all ${
              activeTab === 'sorting'
                ? 'bg-white text-blue-700 shadow-sm shadow-slate-400/20'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <ArrowDownUp className="w-4 h-4" />
            <span>1. 4 Sorting Algorithms (Big Bar Chart)</span>
          </button>

          <button
            onClick={() => setActiveTab('search')}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-xl font-extrabold text-sm transition-all ${
              activeTab === 'search'
                ? 'bg-white text-blue-700 shadow-sm shadow-slate-400/20'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Search className="w-4 h-4" />
            <span>2. Binary Search Bar Chart</span>
          </button>
        </div>

        {/* BIG FONT EXPLANATION CARD FOR BAR CHART TOPIC */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-6">
            <div>
              <span className="text-xs font-mono font-bold text-blue-700 uppercase tracking-wider">
                {currentTopic.shortTag} • {currentTopic.railwayFeature}
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
                {currentTopic.name}
              </h2>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs">
                <Clock className="w-4 h-4 text-emerald-600" />
                <span className="text-slate-500 font-medium">Time:</span>
                <strong className="text-slate-800 font-mono font-bold">{currentTopic.timeComplexity}</strong>
              </div>
              <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs">
                <HardDrive className="w-4 h-4 text-blue-600" />
                <span className="text-slate-500 font-medium">Space:</span>
                <strong className="text-slate-800 font-mono font-bold">{currentTopic.spaceComplexity}</strong>
              </div>
            </div>
          </div>

          {/* Big Font 3 Sections */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div className="bg-blue-50/70 border border-blue-200 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-2">
                <span className="p-1 rounded-md bg-blue-600 text-white">
                  <CheckCircle2 className="w-4 h-4" />
                </span>
                <h3 className="text-xs font-bold text-blue-900 uppercase tracking-wider">
                  Simple Easy Definition
                </h3>
              </div>
              <p className="text-base sm:text-lg text-slate-800 font-semibold leading-relaxed">
                {trans.definition}
              </p>
            </div>

            <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-2">
                <span className="p-1 rounded-md bg-emerald-600 text-white">
                  <Sparkles className="w-4 h-4" />
                </span>
                <h3 className="text-xs font-bold text-emerald-900 uppercase tracking-wider">
                  Why Are We Using It in RailFlow?
                </h3>
              </div>
              <p className="text-base sm:text-lg text-slate-800 font-semibold leading-relaxed">
                {trans.whyUsed}
              </p>
            </div>

            <div className="bg-rose-50/70 border border-rose-200 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-2">
                <span className="p-1 rounded-md bg-rose-600 text-white">
                  <AlertTriangle className="w-4 h-4" />
                </span>
                <h3 className="text-xs font-bold text-rose-900 uppercase tracking-wider">
                  What Happens If We Don't Use It?
                </h3>
              </div>
              <p className="text-base sm:text-lg text-rose-950 font-semibold leading-relaxed">
                {trans.whatHappensIfNotUsed}
              </p>
            </div>
          </div>
        </div>

        {/* ACTIVE BAR CHART VISUALIZER */}
        {activeTab === 'search' ? (
          <div>
            <BarChartSearchVisualizer />
          </div>
        ) : (
          <div>
            <BarChartSortingVisualizer />
          </div>
        )}
      </div>
    </div>
  );
};
