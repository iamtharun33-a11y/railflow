import React from 'react';
import { PNRHashVisualizer } from '../components/PNRHashVisualizer';
import { useLanguage } from '../context/LanguageContext';
import { Hash, Sparkles } from 'lucide-react';

interface PNRStatusPageProps {
  initialPnr?: string;
  onNavigate: (path: string) => void;
}

export const PNRStatusPage: React.FC<PNRStatusPageProps> = ({ initialPnr = '', onNavigate }) => {
  const { language } = useLanguage();

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto">
        {/* Title */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-700 border border-blue-200 text-xs font-bold uppercase tracking-wider mb-3">
            <Hash className="w-3.5 h-3.5" />
            <span>Direct Hash Map Connection</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold text-slate-900 tracking-tight mb-3">
            PNR Status & Hash Map Explorer
          </h1>
          <p className="text-base text-slate-600">
            {language === 'ta'
              ? 'உங்கள் 10-இலக்க PNR எண்ணை தட்டச்சு செய்யும்போது, அது உடனடியாக Hash Table-ல் எந்த Bucket-ல் அமர்கிறது என்பதைக் கண்டறியவும்.'
              : language === 'hi'
              ? 'अपना 10-अंकीय PNR नंबर दर्ज करें और देखें कि यह हैश टेबल के किस बकेट में O(1) समय में मैप होता है।'
              : 'Enter any 10-digit PNR. The system computes the polynomial hash key and maps it directly to its table bucket index in constant O(1) time.'}
          </p>
        </div>

        {/* Live Connected Hash Visualizer */}
        <PNRHashVisualizer initialPnr={initialPnr} />

        {/* Informative Explanation Below */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs">
            <h4 className="font-bold text-slate-900 text-base mb-2">1. Polynomial Hashing</h4>
            <p className="text-xs text-slate-500 leading-relaxed font-normal">
              Every character of the 10-digit PNR is multiplied by a prime constant (31) to disperse keys uniformly across buckets and avoid clustering.
            </p>
          </div>

          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs">
            <h4 className="font-bold text-slate-900 text-base mb-2">2. Modulo 16 Addressing</h4>
            <p className="text-xs text-slate-500 leading-relaxed font-normal">
              The hash result modulo 16 identifies the exact memory bucket slot. Lookups never scan the entire million-ticket database.
            </p>
          </div>

          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs">
            <h4 className="font-bold text-slate-900 text-base mb-2">3. Collision Chaining</h4>
            <p className="text-xs text-slate-500 leading-relaxed font-normal">
              If two distinct PNR keys resolve to the same bucket index, a small linked list (chain) resolves the conflict in minimal probes.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
