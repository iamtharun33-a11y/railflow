import React, { useState } from 'react';
import { Train, TrainClassConfig, Passenger, Booking, DSAEvent } from '../types';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import {
  Train as TrainIcon,
  Plus,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Sparkles
} from 'lucide-react';

interface BookPageProps {
  train?: Train;
  journeyDate?: string;
  travelClass?: '1A' | '2A' | '3A' | 'SL';
  selectedClassConfig?: TrainClassConfig;
  onNavigate: (path: string, state?: any) => void;
}

export const BookPage: React.FC<BookPageProps> = ({
  train,
  journeyDate = new Date(Date.now() + 86400000).toISOString().split('T')[0],
  travelClass = '3A',
  selectedClassConfig,
  onNavigate
}) => {
  const { user } = useAuth();
  const { language } = useLanguage();

  const [passengers, setPassengers] = useState<
    { name: string; age: number; gender: 'M' | 'F' | 'O'; berthPreference: string }[]
  >([
    {
      name: user?.name || '',
      age: 26,
      gender: 'M',
      berthPreference: 'Lower'
    }
  ]);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [bookingSuccess, setBookingSuccess] = useState<{
    booking: Booking;
    dsaEvent: DSAEvent;
  } | null>(null);

  if (!train) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] text-slate-800 py-20 px-4 text-center">
        <TrainIcon className="w-12 h-12 text-blue-600 mx-auto mb-4" />
        <h2 className="text-2xl font-bold mb-2 text-slate-900">No Train Selected</h2>
        <p className="text-slate-500 text-sm mb-6">Please select a train from the trains schedule to book.</p>
        <button
          onClick={() => onNavigate('/trains')}
          className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-sm shadow-xs"
        >
          View Trains
        </button>
      </div>
    );
  }

  const handleAddPassenger = () => {
    if (passengers.length >= 4) return;
    setPassengers([
      ...passengers,
      { name: '', age: 25, gender: 'F', berthPreference: 'Upper' }
    ]);
  };

  const handleRemovePassenger = (index: number) => {
    if (passengers.length === 1) return;
    setPassengers(passengers.filter((_, i) => i !== index));
  };

  const handlePassengerChange = (index: number, field: string, value: any) => {
    const updated = [...passengers];
    updated[index] = { ...updated[index], [field]: value };
    setPassengers(updated);
  };

  const handleConfirmBooking = async () => {
    if (!user) {
      onNavigate('/login', { returnUrl: '/trains' });
      return;
    }

    for (const p of passengers) {
      if (!p.name.trim()) {
        setError('Please enter passenger full name');
        return;
      }
      if (p.age < 1 || p.age > 120) {
        setError('Please enter a valid age (1-120)');
        return;
      }
    }

    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          trainId: train.id,
          journeyDate,
          travelClass,
          passengers
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Booking failed');
      }

      setBookingSuccess(data);
    } catch (err: any) {
      setError(err.message || 'Booking failed');
    } finally {
      setLoading(false);
    }
  };

  const farePerPassenger = selectedClassConfig?.fare || 1500;
  const totalFare = farePerPassenger * passengers.length;

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        {/* Booking Confirmation Success View */}
        {bookingSuccess ? (
          <div className="bg-white border-2 border-emerald-400 rounded-3xl p-8 shadow-sm">
            <div className="text-center mb-8">
              <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto mb-4 border border-emerald-200">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h2 className="text-3xl font-extrabold text-slate-900 mb-1">
                {bookingSuccess.booking.status === 'CONFIRMED'
                  ? 'Booking Successfully Confirmed!'
                  : 'Enqueued to Waiting List (Queue)!'}
              </h2>
              <p className="text-sm text-slate-600">
                Your unique 10-digit PNR has been generated and indexed in the Hash Map.
              </p>
            </div>

            {/* Ticket Card */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 mb-8">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4 mb-4">
                <div>
                  <span className="text-xs text-slate-500 block uppercase font-mono font-bold">10-Digit PNR Number</span>
                  <strong className="text-2xl font-mono text-blue-700 tracking-wider font-extrabold">
                    {bookingSuccess.booking.pnr}
                  </strong>
                </div>

                <div className="flex items-center gap-2">
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                      bookingSuccess.booking.status === 'CONFIRMED'
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                        : 'bg-amber-100 text-amber-800 border border-amber-200'
                    }`}
                  >
                    {bookingSuccess.booking.status}
                    {bookingSuccess.booking.waitingNumber
                      ? ` (WL${bookingSuccess.booking.waitingNumber})`
                      : ''}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs mb-4">
                <div>
                  <span className="text-slate-500 block font-medium">Train</span>
                  <strong className="text-slate-900 text-sm">{bookingSuccess.booking.trainName}</strong>
                </div>
                <div>
                  <span className="text-slate-500 block font-medium">Date</span>
                  <strong className="text-slate-900 text-sm">{bookingSuccess.booking.journeyDate}</strong>
                </div>
                <div>
                  <span className="text-slate-500 block font-medium">Class</span>
                  <strong className="text-blue-700 text-sm font-bold">{bookingSuccess.booking.travelClass}</strong>
                </div>
                <div>
                  <span className="text-slate-500 block font-medium">Total Fare</span>
                  <strong className="text-slate-900 text-sm">₹{bookingSuccess.booking.totalFare}</strong>
                </div>
              </div>

              {/* Passengers Breakdown */}
              <div className="border-t border-slate-200 pt-3">
                <span className="text-xs uppercase text-slate-500 font-bold block mb-2">
                  Passengers & Assigned Berths
                </span>
                <div className="space-y-1.5">
                  {bookingSuccess.booking.passengers.map((p, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between text-xs bg-white border border-slate-200 px-3 py-2 rounded-xl"
                    >
                      <span className="text-slate-800 font-medium">
                        {p.name} ({p.gender}, {p.age} yrs)
                      </span>
                      <strong className="text-emerald-700 font-mono font-bold">
                        {p.allocatedSeat} ({p.allocatedBerth})
                      </strong>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Real DSA Event Explanation Card */}
            <div className="bg-blue-50/70 border border-blue-200 rounded-2xl p-5 mb-8">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-5 h-5 text-blue-700" />
                <h4 className="text-sm font-bold text-blue-900 uppercase tracking-wider">
                  DSA Event Executed: {bookingSuccess.dsaEvent.type}
                </h4>
              </div>

              <div className="text-xs text-slate-700 space-y-1">
                <div>
                  <strong className="text-slate-900">Operation: </strong>
                  <span className="font-mono text-blue-700 font-bold">{bookingSuccess.dsaEvent.operation}</span>
                </div>
                <div>
                  <strong className="text-slate-900">Algorithmic Principle: </strong>
                  <span>{bookingSuccess.dsaEvent.principle}</span>
                </div>
                <div>
                  <strong className="text-slate-900">Time Complexity: </strong>
                  <span className="font-mono text-emerald-700 font-bold">{bookingSuccess.dsaEvent.complexity}</span>
                </div>
                <div>
                  <strong className="text-slate-900">Why in RailFlow: </strong>
                  <span>{bookingSuccess.dsaEvent.railwayUse}</span>
                </div>
              </div>
            </div>

            {/* Navigation Actions */}
            <div className="flex flex-wrap items-center justify-center gap-4">
              <button
                onClick={() => onNavigate('/my-tickets')}
                className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-sm transition-all shadow-xs"
              >
                Go to My Tickets
              </button>

              <button
                onClick={() => onNavigate('/pnr', { pnr: bookingSuccess.booking.pnr })}
                className="px-6 py-3 bg-white hover:bg-slate-50 border border-slate-200 text-slate-800 font-bold rounded-xl text-sm transition-all shadow-2xs"
              >
                Inspect PNR in Hash Map
              </button>
            </div>
          </div>
        ) : (
          /* Normal Booking Input Form */
          <div>
            <div className="mb-6">
              <h2 className="text-3xl font-extrabold text-slate-900">Passenger Details & Berth Selection</h2>
              <p className="text-sm text-slate-600 mt-1">
                Confirm your journey on <strong>{train.name} (#{train.trainNumber})</strong> • Class: <strong>{travelClass}</strong>
              </p>
            </div>

            {error && (
              <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm mb-6 font-medium">
                {error}
              </div>
            )}

            {/* Passenger Forms */}
            <div className="space-y-4 mb-6">
              {passengers.map((p, index) => (
                <div
                  key={index}
                  className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs relative"
                >
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs font-bold uppercase tracking-wider text-blue-700 font-mono">
                      Passenger #{index + 1}
                    </span>
                    {passengers.length > 1 && (
                      <button
                        onClick={() => handleRemovePassenger(index)}
                        className="text-slate-400 hover:text-rose-600 transition-colors p-1"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                    <div className="sm:col-span-2">
                      <label className="block text-xs text-slate-600 mb-1 font-bold">Full Name</label>
                      <input
                        type="text"
                        value={p.name}
                        onChange={(e) => handlePassengerChange(index, 'name', e.target.value)}
                        placeholder="e.g. Ramesh Kumar"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-blue-500 font-medium"
                      />
                    </div>

                    <div>
                      <label className="block text-xs text-slate-600 mb-1 font-bold">Age</label>
                      <input
                        type="number"
                        min="1"
                        max="120"
                        value={p.age}
                        onChange={(e) =>
                          handlePassengerChange(index, 'age', parseInt(e.target.value, 10) || 1)
                        }
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-blue-500 font-medium"
                      />
                    </div>

                    <div>
                      <label className="block text-xs text-slate-600 mb-1 font-bold">Gender</label>
                      <select
                        value={p.gender}
                        onChange={(e) => handlePassengerChange(index, 'gender', e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-blue-500 font-medium"
                      >
                        <option value="M">Male</option>
                        <option value="F">Female</option>
                        <option value="O">Other</option>
                      </select>
                    </div>
                  </div>

                  <div className="mt-3">
                    <label className="block text-xs text-slate-600 mb-1 font-bold">
                      Berth Preference
                    </label>
                    <select
                      value={p.berthPreference}
                      onChange={(e) => handlePassengerChange(index, 'berthPreference', e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-blue-500 font-medium"
                    >
                      <option value="Lower">Lower Berth</option>
                      <option value="Middle">Middle Berth</option>
                      <option value="Upper">Upper Berth</option>
                      <option value="Side Lower">Side Lower</option>
                      <option value="Side Upper">Side Upper</option>
                      <option value="Window">Window Seat</option>
                    </select>
                  </div>
                </div>
              ))}
            </div>

            {/* Add Passenger Button */}
            {passengers.length < 4 && (
              <button
                onClick={handleAddPassenger}
                className="mb-8 flex items-center gap-2 px-4 py-2 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 transition-all shadow-2xs"
              >
                <Plus className="w-4 h-4 text-blue-600" />
                <span>Add Another Passenger (Max 4)</span>
              </button>
            )}

            {/* Summary & Booking Confirmation Bar */}
            <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <span className="text-xs text-slate-500 block font-medium">Total Fare for {passengers.length} Passenger(s)</span>
                <span className="text-2xl font-bold text-slate-900 font-mono">₹{totalFare}</span>
              </div>

              <button
                onClick={handleConfirmBooking}
                disabled={loading}
                className="w-full sm:w-auto px-8 py-3.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white font-bold rounded-xl text-base transition-all shadow-sm shadow-blue-600/30 flex items-center justify-center gap-2"
              >
                <span>{user ? 'Confirm & Allocate Seats' : 'Login to Book'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
