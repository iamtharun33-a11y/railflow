import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import {
  User as UserIcon,
  Trophy,
  Award,
  Ticket,
  CheckCircle2,
  Gamepad2
} from 'lucide-react';
import { Booking } from '../types';

export const DashboardPage: React.FC<{ onNavigate: (path: string) => void }> = ({ onNavigate }) => {
  const { user } = useAuth();
  const { language, t } = useLanguage();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [achievements, setAchievements] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      Promise.all([
        fetch('/api/bookings/my').then((r) => r.json()),
        fetch('/api/auth/me').then((r) => r.json())
      ])
        .then(([bookingsData, meData]) => {
          setBookings(bookingsData.bookings || []);
          setAchievements(meData.achievements || []);
          setStats(meData.stats || null);
        })
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, [user]);

  if (!user) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] text-slate-800 py-20 px-4 text-center">
        <UserIcon className="w-12 h-12 text-blue-600 mx-auto mb-4" />
        <h2 className="text-2xl font-bold mb-2 text-slate-900">Login Required</h2>
        <p className="text-slate-500 text-sm mb-6">Please log in to view your user dashboard.</p>
        <button
          onClick={() => onNavigate('/login')}
          className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-sm shadow-xs"
        >
          Login
        </button>
      </div>
    );
  }

  const currentLevelBaseXP = (user.level - 1) * 250;
  const nextLevelXP = user.level * 250;
  const levelProgress = Math.min(100, Math.round(((user.xp - currentLevelBaseXP) / 250) * 100));

  const ALL_ACHIEVEMENTS = [
    {
      id: 'first_booking',
      title: 'First Journey Booked',
      desc: 'Reserved a train seat with real PNR generation.'
    },
    {
      id: 'first_challenge',
      title: 'First Challenge Solved',
      desc: 'Completed your first DSA railway challenge.'
    },
    {
      id: 'waiting_list_explorer',
      title: 'Waiting List Explorer',
      desc: 'Enqueued to a real FIFO Waiting List queue.'
    },
    {
      id: 'algorithm_master',
      title: 'Algorithm Master',
      desc: 'Successfully solved Level 6 Master Control in DSA Game.'
    }
  ];

  const unlockedSet = new Set(achievements.map((a) => a.achievementId));

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Welcome Header */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 mb-8 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-700 to-indigo-600 flex items-center justify-center text-2xl font-bold text-white shadow-sm shadow-blue-700/20">
              {user.name.charAt(0).toUpperCase()}
            </div>
            <div>
              <span className="text-xs text-blue-700 font-mono font-bold uppercase tracking-wider block">
                Passenger & Algorithm Learner
              </span>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
                Welcome, {user.name}
              </h1>
              <span className="text-xs text-slate-500 font-medium">{user.email}</span>
            </div>
          </div>

          {/* Level & XP Card */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 min-w-[240px]">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase text-slate-500">Level {user.level}</span>
              <strong className="text-xs font-mono text-blue-700 font-bold">{user.xp} Total XP</strong>
            </div>

            <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden mb-1">
              <div
                className="h-full bg-blue-600 transition-all duration-500"
                style={{ width: `${levelProgress}%` }}
              />
            </div>
            <span className="text-[10px] text-slate-500 font-mono font-medium">
              {nextLevelXP - user.xp} XP to Level {user.level + 1}
            </span>
          </div>
        </div>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
            <Ticket className="w-5 h-5 text-blue-600 mb-2" />
            <span className="text-xs text-slate-500 font-medium block">Total Bookings</span>
            <strong className="text-2xl font-bold text-slate-900 font-mono">{bookings.length}</strong>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
            <Trophy className="w-5 h-5 text-amber-500 mb-2" />
            <span className="text-xs text-slate-500 font-medium block">Achievements</span>
            <strong className="text-2xl font-bold text-slate-900 font-mono">{achievements.length}</strong>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
            <Gamepad2 className="w-5 h-5 text-purple-600 mb-2" />
            <span className="text-xs text-slate-500 font-medium block">Game Accuracy</span>
            <strong className="text-2xl font-bold text-slate-900 font-mono">{stats?.accuracy || 0}%</strong>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
            <Award className="w-5 h-5 text-emerald-600 mb-2" />
            <span className="text-xs text-slate-500 font-medium block">Current Rank</span>
            <strong className="text-lg font-bold text-slate-900">
              {user.level >= 5 ? 'DSA Engineer' : user.level >= 3 ? 'Queue Controller' : 'DSA Beginner'}
            </strong>
          </div>
        </div>

        {/* Real Achievements Section */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 mb-8 shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-6">
            <h3 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <Trophy className="w-5 h-5 text-amber-500" />
              <span>Real Achievements Earned</span>
            </h3>
            <span className="text-xs text-slate-500 font-medium">
              {achievements.length} / {ALL_ACHIEVEMENTS.length} Unlocked
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {ALL_ACHIEVEMENTS.map((ach) => {
              const isUnlocked = unlockedSet.has(ach.id);
              return (
                <div
                  key={ach.id}
                  className={`p-4 rounded-2xl border transition-all ${
                    isUnlocked
                      ? 'bg-amber-50/50 border-amber-300'
                      : 'bg-slate-50 border-slate-200 opacity-60'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <strong className={`text-sm ${isUnlocked ? 'text-slate-900 font-bold' : 'text-slate-500 font-medium'}`}>
                      {ach.title}
                    </strong>
                    {isUnlocked ? (
                      <CheckCircle2 className="w-4 h-4 text-amber-600 shrink-0" />
                    ) : (
                      <span className="text-[10px] uppercase font-mono text-slate-400 font-medium">Locked</span>
                    )}
                  </div>
                  <p className="text-xs text-slate-500">{ach.desc}</p>
                </div>
              );
            })}
          </div>

          {achievements.length === 0 && (
            <div className="text-center py-6 text-slate-400 text-sm">
              {t('empty_achievements_desc')}
            </div>
          )}
        </div>

        {/* Upcoming Journeys or Clean Empty State */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-6">
            <h3 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <Ticket className="w-5 h-5 text-blue-600" />
              <span>Upcoming Journeys</span>
            </h3>
            <button
              onClick={() => onNavigate('/my-tickets')}
              className="text-xs text-blue-700 font-bold hover:underline"
            >
              View All Tickets
            </button>
          </div>

          {bookings.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-slate-500 text-sm mb-4 font-medium">{t('empty_tickets_desc')}</p>
              <button
                onClick={() => onNavigate('/trains')}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs transition-all shadow-xs"
              >
                Search Real Trains
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {bookings.slice(0, 3).map((b) => (
                <div
                  key={b.id}
                  className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between"
                >
                  <div>
                    <span className="text-xs font-mono text-blue-700 font-bold">PNR: {b.pnr}</span>
                    <strong className="text-slate-900 text-sm block">{b.trainName}</strong>
                    <span className="text-xs text-slate-500 font-medium">
                      {b.fromStationCode} → {b.toStationCode} • {b.journeyDate}
                    </span>
                  </div>

                  <span
                    className={`px-2.5 py-1 rounded-full text-xs font-bold uppercase font-mono ${
                      b.status === 'CONFIRMED'
                        ? 'bg-emerald-100 text-emerald-800'
                        : b.status === 'WAITING'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {b.status} {b.waitingNumber ? `WL${b.waitingNumber}` : ''}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
