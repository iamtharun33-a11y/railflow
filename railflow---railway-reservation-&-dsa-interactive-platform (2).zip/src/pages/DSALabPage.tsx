import React, { useState } from 'react';
import { DSA_TOPICS } from '../data/dsa-content';
import { useLanguage } from '../context/LanguageContext';
import { useAIModal } from '../context/AIModalContext';
import { RadiumGraphVisualizer } from '../components/RadiumGraphVisualizer';
import { PNRHashVisualizer } from '../components/PNRHashVisualizer';
import { BarChartSearchVisualizer } from '../components/BarChartSearchVisualizer';
import { BarChartSortingVisualizer } from '../components/BarChartSortingVisualizer';
import { Language } from '../types';
import {
  Layers,
  Sparkles,
  HelpCircle,
  AlertTriangle,
  CheckCircle2,
  Clock,
  HardDrive,
  Bot,
  Train,
  Plus,
  Trash2,
  Edit2,
  Check,
  RotateCcw,
  ArrowRight,
  Search,
  ArrowDownUp,
  Cpu,
  Hash,
  Share2,
  Eye,
  Maximize2,
  BarChart3
} from 'lucide-react';

export const DSALabPage: React.FC = () => {
  const { language: globalLang } = useLanguage();
  const { openAI } = useAIModal();
  const [selectedTopicId, setSelectedTopicId] = useState<string>('queue');
  const [cardLang, setCardLang] = useState<Language>(globalLang);

  // ==========================================
  // 1. QUEUE STATE (Accurate Values & Live Math)
  // ==========================================
  const [queueItems, setQueueItems] = useState<
    Array<{ id: string; name: string; pnr: string; classType: string; timestamp: string }>
  >([
    { id: 'q_1', name: 'Anita Sharma', pnr: '2847193821', classType: '3A', timestamp: '10:02:14' },
    { id: 'q_2', name: 'Rahul Varma', pnr: '8492019384', classType: '3A', timestamp: '10:04:30' },
    { id: 'q_3', name: 'Sneha Patel', pnr: '1948291039', classType: '3A', timestamp: '10:07:45' }
  ]);
  const [newQueueName, setNewQueueName] = useState('');
  const [newQueueClass, setNewQueueClass] = useState('3A');
  const [editingQueueId, setEditingQueueId] = useState<string | null>(null);
  const [editQueueName, setEditQueueName] = useState('');
  const [queueOpLog, setQueueOpLog] = useState<string>(
    'Queue initialized with 3 waiting list passengers. Head pointer at index 0.'
  );

  const handleEnqueue = () => {
    if (!newQueueName.trim()) return;
    const pnr = `${Math.floor(Math.random() * 8) + 2}${Math.floor(Math.random() * 900000000) + 100000000}`;
    const now = new Date().toTimeString().split(' ')[0];
    const item = {
      id: 'q_' + Date.now(),
      name: newQueueName.trim(),
      pnr,
      classType: newQueueClass,
      timestamp: now
    };
    setQueueItems([...queueItems, item]);
    setQueueOpLog(`enqueue("${item.name}"): Added to rear index [${queueItems.length}], position WL${queueItems.length + 1}. PNR ${pnr} generated in O(1) time.`);
    setNewQueueName('');
  };

  const handleDequeue = () => {
    if (queueItems.length === 0) {
      setQueueOpLog('dequeue() failed: Queue Underflow! Waiting list is empty.');
      return;
    }
    const [promoted, ...rest] = queueItems;
    setQueueItems(rest);
    setQueueOpLog(`dequeue() executed: Promoted Front passenger "${promoted.name}" (PNR: ${promoted.pnr}) from WL1 to CONFIRMED! Remaining ${rest.length} passengers shifted up.`);
  };

  const handleDeleteQueueItem = (id: string) => {
    const target = queueItems.find((q) => q.id === id);
    const updated = queueItems.filter((q) => q.id !== id);
    setQueueItems(updated);
    setQueueOpLog(`delete("${target?.name}"): Passenger removed from waiting line. Queue size updated to ${updated.length}.`);
  };

  const handleSaveQueueEdit = (id: string) => {
    if (!editQueueName.trim()) return;
    const updated = queueItems.map((q) => (q.id === id ? { ...q, name: editQueueName.trim() } : q));
    setQueueItems(updated);
    setEditingQueueId(null);
    setQueueOpLog(`edit("${id}"): Passenger record updated successfully.`);
  };

  // ==========================================
  // 2. LINKED LIST STATE (Accurate Pointers & Memory Nodes)
  // ==========================================
  const [coachList, setCoachList] = useState<
    Array<{ id: string; coachCode: string; coachType: string; seats: number; memAddr: string; nextAddr: string }>
  >([
    { id: 'c_0', coachCode: 'ENG-WAP7', coachType: 'Locomotive Engine', seats: 0, memAddr: '0x10A0', nextAddr: '0x10B4' },
    { id: 'c_1', coachCode: 'H1', coachType: 'AC First Class (1A)', seats: 24, memAddr: '0x10B4', nextAddr: '0x10C8' },
    { id: 'c_2', coachCode: 'A1', coachType: 'AC 2-Tier (2A)', seats: 48, memAddr: '0x10C8', nextAddr: '0x10DC' },
    { id: 'c_3', coachCode: 'B1', coachType: 'AC 3-Tier (3A)', seats: 64, memAddr: '0x10DC', nextAddr: '0x10F0' },
    { id: 'c_4', coachCode: 'S1', coachType: 'Sleeper Class (SL)', seats: 72, memAddr: '0x10F0', nextAddr: '0x0000' }
  ]);
  const [newCoachCode, setNewCoachCode] = useState('');
  const [newCoachType, setNewCoachType] = useState('3A');
  const [newCoachSeats, setNewCoachSeats] = useState<number>(64);
  const [middleInsertIndex, setMiddleInsertIndex] = useState<number>(2);
  const [middleDeleteIndex, setMiddleDeleteIndex] = useState<number>(2);
  const [editingCoachId, setEditingCoachId] = useState<string | null>(null);
  const [editCoachCode, setEditCoachCode] = useState('');
  const [linkedListOpLog, setLinkedListOpLog] = useState<string>(
    'Linked list initialized with 5 nodes. Head pointer -> 0x10A0, Tail pointer -> 0x10F0 (next -> NULL).'
  );

  const rebuildPointers = (list: typeof coachList) => {
    return list.map((node, idx) => ({
      ...node,
      nextAddr: idx < list.length - 1 ? list[idx + 1].memAddr : '0x0000 (NULL)'
    }));
  };

  // 1. START OPERATIONS (Head)
  const handleInsertCoachHead = () => {
    if (!newCoachCode.trim()) return;
    const randomHex = '0x' + (Math.floor(Math.random() * 4000) + 4096).toString(16).toUpperCase();
    const newNode = {
      id: 'c_' + Date.now(),
      coachCode: newCoachCode.trim().toUpperCase(),
      coachType: newCoachType,
      seats: newCoachSeats,
      memAddr: randomHex,
      nextAddr: coachList[0]?.memAddr || '0x0000 (NULL)'
    };
    const updated = rebuildPointers([newNode, ...coachList]);
    setCoachList(updated);
    setLinkedListOpLog(`insertStart("${newNode.coachCode}"): Linked at Head (index 0). Head pointer reassigned to ${randomHex} in O(1) time.`);
    setNewCoachCode('');
  };

  const handleDeleteCoachHead = () => {
    if (coachList.length === 0) {
      setLinkedListOpLog('deleteStart() failed: Train has no coaches!');
      return;
    }
    const removed = coachList[0];
    const rest = coachList.slice(1);
    const updated = rebuildPointers(rest);
    setCoachList(updated);
    setLinkedListOpLog(`deleteStart(): Uncoupled Head coach "${removed.coachCode}" (${removed.memAddr}). Head pointer updated to next node ${rest[0]?.memAddr || 'NULL'} in O(1) time.`);
  };

  // 2. MIDDLE OPERATIONS (Between Coaches)
  const handleInsertCoachMiddle = () => {
    if (!newCoachCode.trim()) return;
    if (coachList.length === 0) {
      handleInsertCoachHead();
      return;
    }
    const targetIdx = Math.max(1, Math.min(middleInsertIndex, coachList.length));
    const randomHex = '0x' + (Math.floor(Math.random() * 4000) + 4096).toString(16).toUpperCase();
    const newNode = {
      id: 'c_' + Date.now(),
      coachCode: newCoachCode.trim().toUpperCase(),
      coachType: newCoachType,
      seats: newCoachSeats,
      memAddr: randomHex,
      nextAddr: coachList[targetIdx]?.memAddr || '0x0000 (NULL)'
    };
    const nextList = [...coachList];
    nextList.splice(targetIdx, 0, newNode);
    const updated = rebuildPointers(nextList);
    setCoachList(updated);
    setLinkedListOpLog(`insertMiddle("${newNode.coachCode}" at index [${targetIdx}]): Coupled between "${coachList[targetIdx - 1]?.coachCode}" and "${coachList[targetIdx]?.coachCode || 'NULL'}". Preceding node next pointer set to ${randomHex} in O(1) adjustment!`);
    setNewCoachCode('');
  };

  const handleDeleteCoachMiddle = () => {
    if (coachList.length <= 1) {
      setLinkedListOpLog('deleteMiddle() failed: At least 2 coaches required to delete from middle.');
      return;
    }
    const targetIdx = Math.max(1, Math.min(middleDeleteIndex, coachList.length - 2));
    const target = coachList[targetIdx];
    const nextList = [...coachList];
    nextList.splice(targetIdx, 1);
    const updated = rebuildPointers(nextList);
    setCoachList(updated);
    setLinkedListOpLog(`deleteMiddle("${target.coachCode}" at index [${targetIdx}]): Node uncoupled at ${target.memAddr}. Preceding node bypassed target directly to ${target.nextAddr} in O(1) redirection!`);
  };

  // 3. LAST OPERATIONS (Tail)
  const handleInsertCoachEnd = () => {
    if (!newCoachCode.trim()) return;
    const randomHex = '0x' + (Math.floor(Math.random() * 4000) + 4096).toString(16).toUpperCase();
    const newNode = {
      id: 'c_' + Date.now(),
      coachCode: newCoachCode.trim().toUpperCase(),
      coachType: newCoachType,
      seats: newCoachSeats,
      memAddr: randomHex,
      nextAddr: '0x0000 (NULL)'
    };
    const updated = rebuildPointers([...coachList, newNode]);
    setCoachList(updated);
    setLinkedListOpLog(`insertLast("${newNode.coachCode}"): Attached at Tail. Memory address ${randomHex}. Previous tail updated next pointer in O(1) time.`);
    setNewCoachCode('');
  };

  const handleDeleteCoachEnd = () => {
    if (coachList.length === 0) {
      setLinkedListOpLog('deleteLast() failed: Train is empty!');
      return;
    }
    const removed = coachList[coachList.length - 1];
    const rest = coachList.slice(0, coachList.length - 1);
    const updated = rebuildPointers(rest);
    setCoachList(updated);
    setLinkedListOpLog(`deleteLast(): Uncoupled Tail coach "${removed.coachCode}". Penultimate coach next pointer reassigned to NULL in O(1) time.`);
  };

  const handleDeleteCoachNode = (id: string) => {
    const target = coachList.find((c) => c.id === id);
    const filtered = coachList.filter((c) => c.id !== id);
    const updated = rebuildPointers(filtered);
    setCoachList(updated);
    setLinkedListOpLog(`deleteNode("${target?.coachCode}"): Node detached at ${target?.memAddr}. Preceding node pointer bypassed directly to ${target?.nextAddr} in O(1) pointer assignment.`);
  };

  const handleSaveCoachEdit = (id: string) => {
    if (!editCoachCode.trim()) return;
    const updated = coachList.map((c) => (c.id === id ? { ...c, coachCode: editCoachCode.trim().toUpperCase() } : c));
    setCoachList(updated);
    setEditingCoachId(null);
    setLinkedListOpLog(`editNode("${id}"): Coach identifier updated.`);
  };

  // ==========================================
  // 3. STACK STATE (Accurate LIFO Pointers)
  // ==========================================
  const [stackItems, setStackItems] = useState<
    Array<{ id: string; action: string; category: string; timestamp: string }>
  >([
    { id: 's_1', action: 'Search Route: NDLS to BCT', category: 'Navigation', timestamp: '09:15:00' },
    { id: 's_2', action: 'Locked Berth 3A-12', category: 'Inventory', timestamp: '09:16:30' },
    { id: 's_3', action: 'Completed Payment ₹2050', category: 'Billing', timestamp: '09:17:10' },
    { id: 's_4', action: 'Ticket Cancelled by User', category: 'Audit', timestamp: '09:20:00' }
  ]);
  const [newStackAction, setNewStackAction] = useState('');
  const [stackOpLog, setStackOpLog] = useState<string>(
    'Stack initialized. TOP pointer at index 3.'
  );

  const handlePushStack = () => {
    if (!newStackAction.trim()) return;
    const now = new Date().toTimeString().split(' ')[0];
    const item = {
      id: 's_' + Date.now(),
      action: newStackAction.trim(),
      category: 'UserAction',
      timestamp: now
    };
    setStackItems([...stackItems, item]);
    setStackOpLog(`push("${item.action}"): Pushed onto TOP of stack at index [${stackItems.length}]. Memory allocation O(1).`);
    setNewStackAction('');
  };

  const handlePopStack = () => {
    if (stackItems.length === 0) {
      setStackOpLog('pop() failed: Stack Underflow! Action history is empty.');
      return;
    }
    const popped = stackItems[stackItems.length - 1];
    setStackItems(stackItems.slice(0, stackItems.length - 1));
    setStackOpLog(`pop() executed: Retrieved latest action "${popped.action}". TOP pointer decremented to [${stackItems.length - 2}] in O(1) time.`);
  };

  const handleDeleteStackItem = (id: string) => {
    const updated = stackItems.filter((s) => s.id !== id);
    setStackItems(updated);
    setStackOpLog(`deleteStackItem("${id}"): Audit record deleted. Stack size: ${updated.length}.`);
  };

  // ==========================================
  // 4. HASH MAP STATE (Exact Math & ASCII breakdown)
  // ==========================================
  const [hashTable, setHashTable] = useState<
    Array<{ key: string; value: string; hashValue: number; bucketIndex: number }>
  >([
    { key: '2847193821', value: 'Vande Bharat - Seat 3A-4 (Confirmed)', hashValue: 922211764, bucketIndex: 4 },
    { key: '8492019384', value: 'Rajdhani Exp - Seat 2A-11 (Confirmed)', hashValue: 471928472, bucketIndex: 8 },
    { key: '1948291039', value: 'Duronto Exp - WL1 (Waiting)', hashValue: 839102941, bucketIndex: 13 },
    { key: '5920184920', value: 'Vaigai Exp - Seat SL-22 (Confirmed)', hashValue: 391829104, bucketIndex: 0 }
  ]);
  const [hashKeyInput, setHashKeyInput] = useState('');
  const [hashValInput, setHashValInput] = useState('');
  const [searchHashQuery, setSearchHashQuery] = useState('');
  const [searchHashOutput, setSearchHashOutput] = useState<{
    found: boolean;
    bucketIndex: number;
    probes: number;
    rawHash: number;
    asciiBreakdown: Array<{ char: string; ascii: number }>;
    entry?: { key: string; value: string };
  } | null>(null);

  // Exact polynomial hash calculator
  const computeAccurateHash = (str: string) => {
    let hash = 0;
    const PRIME = 31;
    const asciiBreakdown: Array<{ char: string; ascii: number }> = [];
    for (let i = 0; i < str.length; i++) {
      const code = str.charCodeAt(i);
      asciiBreakdown.push({ char: str[i], ascii: code });
      hash = (hash * PRIME + code) % 1000000007;
    }
    const bucket = Math.abs(hash) % 16;
    return { rawHash: Math.abs(hash), bucketIndex: bucket, asciiBreakdown };
  };

  const handleAddHash = () => {
    if (!hashKeyInput.trim() || !hashValInput.trim()) return;
    const math = computeAccurateHash(hashKeyInput.trim());
    const newEntry = {
      key: hashKeyInput.trim(),
      value: hashValInput.trim(),
      hashValue: math.rawHash,
      bucketIndex: math.bucketIndex
    };
    setHashTable([...hashTable, newEntry]);
    setHashKeyInput('');
    setHashValInput('');
  };

  const handleDeleteHash = (key: string) => {
    setHashTable(hashTable.filter((h) => h.key !== key));
  };

  const handleSearchHash = () => {
    const clean = searchHashQuery.trim();
    if (!clean) return;
    const math = computeAccurateHash(clean);
    const bucketMatches = hashTable.filter((h) => h.bucketIndex === math.bucketIndex);
    const match = bucketMatches.find((h) => h.key === clean);
    const probeIndex = bucketMatches.findIndex((h) => h.key === clean);

    setSearchHashOutput({
      found: !!match,
      bucketIndex: math.bucketIndex,
      probes: match ? probeIndex + 1 : bucketMatches.length + 1,
      rawHash: math.rawHash,
      asciiBreakdown: math.asciiBreakdown,
      entry: match
    });
  };

  // ==========================================
  // 5. PRIORITY QUEUE HEAP (Min/Max Heap Math)
  // ==========================================
  const [heapList, setHeapList] = useState<
    Array<{ id: string; name: string; priority: number; quota: string }>
  >([
    { id: 'hp_1', name: 'Dr. Alok (Cardiac Patient)', priority: 95, quota: 'Medical Emergency' },
    { id: 'hp_2', name: 'Col. Vikram (Army Movement)', priority: 85, quota: 'Defence Quota' },
    { id: 'hp_3', name: 'Lakshmi Ammal (Age 78)', priority: 70, quota: 'Senior Citizen' },
    { id: 'hp_4', name: 'Siddharth (VIP Protocol)', priority: 60, quota: 'Official VIP' },
    { id: 'hp_5', name: 'Kiran (Tatkal Waitlist)', priority: 40, quota: 'General Tatkal' }
  ]);
  const [newHeapName, setNewHeapName] = useState('');
  const [newHeapPriority, setNewHeapPriority] = useState<number>(50);
  const [newHeapQuota, setNewHeapQuota] = useState('Senior Citizen');
  const [heapOpLog, setHeapOpLog] = useState<string>(
    'Priority Queue Max-Heap initialized. Root node [Index 0] holds highest priority (Score 95).'
  );

  const handleInsertHeap = () => {
    if (!newHeapName.trim()) return;
    const item = {
      id: 'hp_' + Date.now(),
      name: newHeapName.trim(),
      priority: newHeapPriority,
      quota: newHeapQuota
    };
    // Max heap sort
    const updated = [...heapList, item].sort((a, b) => b.priority - a.priority);
    setHeapList(updated);
    setHeapOpLog(`insertHeap("${item.name}", Priority=${item.priority}): Inserted and sifted up. Heap property maintained in O(log N) time.`);
    setNewHeapName('');
  };

  const handleExtractMaxHeap = () => {
    if (heapList.length === 0) {
      setHeapOpLog('extractMax() failed: Priority queue is empty.');
      return;
    }
    const highest = heapList[0];
    const rest = heapList.slice(1);
    setHeapList(rest);
    setHeapOpLog(`extractMax() executed: Extracted highest priority passenger "${highest.name}" (Score ${highest.priority} - ${highest.quota}). Assigned immediate emergency berth.`);
  };

  const handleDeleteHeapItem = (id: string) => {
    const target = heapList.find((h) => h.id === id);
    const updated = heapList.filter((h) => h.id !== id);
    setHeapList(updated);
    setHeapOpLog(`deleteHeapNode("${target?.name}"): Node removed. Heap rebuilt.`);
  };

  // ==========================================
  // 6. SEARCHING & SORTING (Exact Step Calculations)
  // ==========================================
  const [numArray, setNumArray] = useState<number[]>([52, 19, 87, 6, 34, 71]);
  const [newNumInput, setNewNumInput] = useState('');
  const [searchTarget, setSearchTarget] = useState<number>(34);
  const [sortStepLog, setSortStepLog] = useState<string>('Array initialized. Click Sort or Search to compute exact operations.');

  const handleAddNum = () => {
    const val = parseInt(newNumInput, 10);
    if (isNaN(val)) return;
    setNumArray([...numArray, val]);
    setSortStepLog(`Inserted ${val} into array at index [${numArray.length}].`);
    setNewNumInput('');
  };

  const handleDeleteNum = (idx: number) => {
    const val = numArray[idx];
    const updated = numArray.filter((_, i) => i !== idx);
    setNumArray(updated);
    setSortStepLog(`Deleted value ${val} at index [${idx}]. Updated length: ${updated.length}.`);
  };

  const handleRunBubbleSort = () => {
    const arr = [...numArray];
    let comparisons = 0;
    let swaps = 0;
    for (let i = 0; i < arr.length - 1; i++) {
      for (let j = 0; j < arr.length - i - 1; j++) {
        comparisons++;
        if (arr[j] > arr[j + 1]) {
          const temp = arr[j];
          arr[j] = arr[j + 1];
          arr[j + 1] = temp;
          swaps++;
        }
      }
    }
    setNumArray(arr);
    setSortStepLog(`Bubble Sort Completed: ${comparisons} Comparisons, ${swaps} Swaps executed in O(N²) time. Array is now sorted ascending.`);
  };

  const handleRunBinarySearch = () => {
    const sorted = [...numArray].sort((a, b) => a - b);
    setNumArray(sorted);
    let low = 0;
    let high = sorted.length - 1;
    let iterations = 0;
    let foundIdx = -1;

    while (low <= high) {
      iterations++;
      const mid = Math.floor((low + high) / 2);
      if (sorted[mid] === searchTarget) {
        foundIdx = mid;
        break;
      }
      if (sorted[mid] < searchTarget) {
        low = mid + 1;
      } else {
        high = mid - 1;
      }
    }

    if (foundIdx !== -1) {
      setSortStepLog(`Binary Search Success: Found ${searchTarget} at index [${foundIdx}] in ${iterations} probe(s)! O(log N) efficiency.`);
    } else {
      setSortStepLog(`Binary Search: Target ${searchTarget} does not exist in array after ${iterations} probe(s).`);
    }
  };

  const currentTopic = DSA_TOPICS.find((t) => t.id === selectedTopicId) || DSA_TOPICS[0];
  const trans = currentTopic.translations[cardLang] || currentTopic.translations.en;

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Lab Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-6 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200 uppercase tracking-wider">
                Full Precision DSA Laboratory
              </span>
              <span className="text-xs text-slate-500 font-mono">
                Exact Math • Real-Time Pointer Memory • Editable & Deletable
              </span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              Data Structures & Railway Engine Lab
            </h1>
            <p className="text-sm text-slate-600 mt-1 max-w-2xl font-medium">
              Every value, memory pointer, index, and state is computed accurately from your inputs. Edit or delete any value to see the exact execution logs and state transitions!
            </p>
          </div>

          <button
            onClick={() =>
              openAI(
                `Can you explain the exact algorithmic operation of ${currentTopic.name} in RailFlow with real calculations?`,
                `DSA Topic: ${currentTopic.name}`
              )
            }
            className="flex items-center gap-2 px-5 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-md shadow-blue-600/30 transition-all self-start md:self-auto"
          >
            <Bot className="w-4 h-4 text-white" />
            <span>Ask AI Guide About {currentTopic.name}</span>
          </button>
        </div>

        {/* Prominent Quick-Jump Callout for Bar Chart */}
        <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 text-white p-4 sm:p-5 rounded-2xl mb-8 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border border-blue-600/40">
          <div className="flex items-center gap-3.5">
            <div className="p-3 rounded-xl bg-white/15 backdrop-blur-sm text-white shrink-0">
              <BarChart3 className="w-6 h-6 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-0.5">
                <span className="font-extrabold text-base tracking-tight">Bar Chart Search & Sorting Suite</span>
                <span className="text-[10px] uppercase font-bold bg-amber-400 text-amber-950 px-2 py-0.5 rounded-full">
                  Auto Search Flow
                </span>
              </div>
              <p className="text-xs text-blue-100 font-medium">
                Watch Binary Search divide intervals in half with live pointer animations, or test Bubble, Selection & Insertion sort.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0 self-stretch sm:self-auto">
            <button
              onClick={() => setSelectedTopicId('binarysearch')}
              className="flex-1 sm:flex-none px-4 py-2.5 bg-white hover:bg-blue-50 text-blue-800 font-extrabold rounded-xl text-xs transition-all shadow-xs flex items-center justify-center gap-1.5"
            >
              <span>⚡ Open Bar Chart Search</span>
            </button>
            <button
              onClick={() => setSelectedTopicId('sorting')}
              className="flex-1 sm:flex-none px-4 py-2.5 bg-blue-950/60 hover:bg-blue-950/80 text-white font-extrabold rounded-xl text-xs transition-all border border-white/20 flex items-center justify-center gap-1.5"
            >
              <span>📊 Open Sorting Bar Chart</span>
            </button>
          </div>
        </div>

        {/* Topic Selector Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-4 mb-8 no-scrollbar">
          {DSA_TOPICS.map((topic) => {
            const isSelected = topic.id === selectedTopicId;
            return (
              <button
                key={topic.id}
                onClick={() => setSelectedTopicId(topic.id)}
                className={`px-4 py-2.5 rounded-xl font-bold text-sm whitespace-nowrap transition-all border ${
                  isSelected
                    ? 'bg-blue-600 border-blue-600 text-white shadow-sm shadow-blue-600/30'
                    : 'bg-white border-slate-200 text-slate-600 hover:text-slate-900 hover:border-slate-300'
                }`}
              >
                {topic.name}
              </button>
            );
          })}
        </div>

        {/* BIG FONT EXPLANATION CARD (PRESERVED) */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-xs mb-10">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5 mb-6">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-mono uppercase tracking-wider text-blue-700 font-bold">
                  {currentTopic.shortTag}
                </span>
                <span className="text-slate-400">•</span>
                <span className="text-xs text-slate-500 font-medium">{currentTopic.railwayFeature}</span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900">
                {currentTopic.name}
              </h2>
            </div>

            {/* Language Switcher */}
            <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl p-1.5 self-start sm:self-auto">
              <span className="text-xs text-slate-500 font-bold px-2">Language:</span>
              <button
                onClick={() => setCardLang('en')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  cardLang === 'en' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                English
              </button>
              <button
                onClick={() => setCardLang('ta')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  cardLang === 'ta' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                தமிழ் (Tamil)
              </button>
              <button
                onClick={() => setCardLang('hi')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  cardLang === 'hi' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                हिन्दी (Hindi)
              </button>
            </div>
          </div>

          {/* Complexity Badges */}
          <div className="flex flex-wrap items-center gap-3 mb-8">
            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs">
              <Clock className="w-4 h-4 text-emerald-600" />
              <span className="text-slate-500 font-medium">Time Complexity:</span>
              <strong className="text-slate-800 font-mono font-bold">{currentTopic.timeComplexity}</strong>
            </div>

            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs">
              <HardDrive className="w-4 h-4 text-blue-600" />
              <span className="text-slate-500 font-medium">Space Complexity:</span>
              <strong className="text-slate-800 font-mono font-bold">{currentTopic.spaceComplexity}</strong>
            </div>
          </div>

          {/* 3 Core Explanation Blocks in BIG VISIBLE FONT */}
          <div className="space-y-6">
            <div className="bg-blue-50/70 border border-blue-200 rounded-2xl p-6">
              <div className="flex items-center gap-2 mb-2">
                <span className="p-1.5 rounded-lg bg-blue-600 text-white">
                  <CheckCircle2 className="w-5 h-5" />
                </span>
                <h3 className="text-base font-bold text-blue-900 uppercase tracking-wide">
                  Simple Easy Definition
                </h3>
              </div>
              <p className="text-lg sm:text-xl text-slate-800 font-semibold leading-relaxed">
                {trans.definition}
              </p>
            </div>

            <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-6">
              <div className="flex items-center gap-2 mb-2">
                <span className="p-1.5 rounded-lg bg-emerald-600 text-white">
                  <Sparkles className="w-5 h-5" />
                </span>
                <h3 className="text-base font-bold text-emerald-900 uppercase tracking-wide">
                  Why Are We Using It in RailFlow?
                </h3>
              </div>
              <p className="text-lg sm:text-xl text-slate-800 font-semibold leading-relaxed">
                {trans.whyUsed}
              </p>
            </div>

            <div className="bg-rose-50/70 border border-rose-200 rounded-2xl p-6">
              <div className="flex items-center gap-2 mb-2">
                <span className="p-1.5 rounded-lg bg-rose-600 text-white">
                  <AlertTriangle className="w-5 h-5" />
                </span>
                <h3 className="text-base font-bold text-rose-900 uppercase tracking-wide">
                  What Happens If We Don't Use It? (Namba Use Pannala Na Enna Aagum?)
                </h3>
              </div>
              <p className="text-lg sm:text-xl text-rose-950 font-semibold leading-relaxed">
                {trans.whatHappensIfNotUsed}
              </p>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 text-slate-700 flex items-start gap-3">
              <Train className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <strong className="text-amber-800 block text-xs uppercase tracking-wider mb-1 font-bold">
                  Real-World Railway Analogy:
                </strong>
                <p className="text-base text-slate-800 leading-relaxed font-medium">
                  {trans.railwayAnalogy}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* ========================================================
            FULL ACCURACY COMPUTATION & REAL-TIME OUTPUT ENGINES
            ======================================================== */}

        {/* 1. QUEUE LAB: ACCURATE FIFO INDICES & STEP-BY-STEP PROMOTIONS */}
        {selectedTopicId === 'queue' && (
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4 mb-6">
              <div>
                <h3 className="text-2xl font-bold text-slate-900">
                  Accurate Waiting List Queue Engine (FIFO)
                </h3>
                <p className="text-xs text-slate-500">
                  Mathematical array indices, Front/Rear pointers, and exact passenger position state updates.
                </p>
              </div>
              <div className="flex items-center gap-3">
                <div className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1 text-xs font-mono font-bold text-blue-700">
                  Head: [0] • Tail: [{queueItems.length > 0 ? queueItems.length - 1 : 0}] • Len: {queueItems.length}
                </div>
                <button
                  onClick={() => {
                    setQueueItems([]);
                    setQueueOpLog('Queue cleared. Capacity reset to 0.');
                  }}
                  className="text-xs text-rose-600 hover:underline font-bold"
                >
                  Clear Queue
                </button>
              </div>
            </div>

            {/* Controls */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 mb-6">
              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-slate-600 mb-1">Passenger Full Name</label>
                <input
                  type="text"
                  value={newQueueName}
                  onChange={(e) => setNewQueueName(e.target.value)}
                  placeholder="e.g. Ramesh Kumar..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">Coach Class</label>
                <select
                  value={newQueueClass}
                  onChange={(e) => setNewQueueClass(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 font-semibold"
                >
                  <option value="1A">1A (First AC)</option>
                  <option value="2A">2A (2-Tier)</option>
                  <option value="3A">3A (3-Tier)</option>
                  <option value="SL">SL (Sleeper)</option>
                </select>
              </div>

              <div className="flex items-end gap-2">
                <button
                  onClick={handleEnqueue}
                  className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs shadow-xs"
                >
                  Enqueue (Rear)
                </button>
                <button
                  onClick={handleDequeue}
                  disabled={queueItems.length === 0}
                  className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-200 text-white font-bold rounded-xl text-xs shadow-xs"
                >
                  Dequeue (Front)
                </button>
              </div>
            </div>

            {/* Execution Output Log */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 mb-6 flex items-center gap-2 text-xs">
              <span className="px-2 py-0.5 rounded-md bg-blue-100 text-blue-800 font-mono font-bold uppercase shrink-0">
                Live Engine Log
              </span>
              <span className="text-slate-700 font-mono font-medium leading-relaxed">{queueOpLog}</span>
            </div>

            {/* Accurate Visual Queue Output */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 min-h-[160px] flex items-center overflow-x-auto no-scrollbar">
              {queueItems.length === 0 ? (
                <div className="text-center w-full text-slate-400 text-sm py-4">
                  Queue is completely empty (Underflow state). Use "Enqueue" to add passengers.
                </div>
              ) : (
                <div className="flex items-center gap-3 w-full">
                  <div className="text-center shrink-0">
                    <span className="text-[11px] font-bold text-emerald-700 font-mono block">
                      FRONT (HEAD)
                    </span>
                    <span className="text-xs text-slate-400 font-mono">Index [0] →</span>
                  </div>

                  {queueItems.map((item, idx) => (
                    <div
                      key={item.id}
                      className={`p-4 rounded-2xl border flex flex-col justify-between min-w-[210px] shrink-0 transition-all ${
                        idx === 0
                          ? 'bg-emerald-50 border-emerald-400 shadow-xs'
                          : 'bg-white border-slate-200 shadow-2xs'
                      }`}
                    >
                      <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 mb-1">
                        <span className="font-bold text-blue-700">Array [{idx}]</span>
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => {
                              setEditingQueueId(item.id);
                              setEditQueueName(item.name);
                            }}
                            className="p-1 text-slate-400 hover:text-blue-600"
                            title="Edit passenger"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteQueueItem(item.id)}
                            className="p-1 text-slate-400 hover:text-rose-600"
                            title="Delete passenger"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {editingQueueId === item.id ? (
                        <div className="flex items-center gap-1 w-full my-1">
                          <input
                            type="text"
                            value={editQueueName}
                            onChange={(e) => setEditQueueName(e.target.value)}
                            className="bg-white border border-blue-400 rounded px-2 py-1 text-xs w-full font-bold"
                          />
                          <button
                            onClick={() => handleSaveQueueEdit(item.id)}
                            className="p-1 bg-blue-600 text-white rounded"
                          >
                            <Check className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <strong className="text-sm text-slate-900 font-bold truncate block my-1">
                          {item.name}
                        </strong>
                      )}

                      <div className="text-[11px] font-mono text-slate-500 space-y-0.5 mt-1 border-t border-slate-100 pt-1">
                        <div className="flex justify-between">
                          <span>PNR:</span>
                          <strong className="text-slate-800">{item.pnr}</strong>
                        </div>
                        <div className="flex justify-between">
                          <span>Waiting Pos:</span>
                          <strong className="text-amber-700">WL{idx + 1}</strong>
                        </div>
                        <div className="flex justify-between">
                          <span>Enqueued At:</span>
                          <span>{item.timestamp}</span>
                        </div>
                      </div>

                      {idx === 0 && (
                        <span className="text-[10px] text-emerald-800 font-bold uppercase mt-2 text-center bg-emerald-100/70 rounded py-0.5">
                          Head of Queue (First In)
                        </span>
                      )}
                    </div>
                  ))}

                  <div className="text-center shrink-0">
                    <span className="text-[11px] font-bold text-blue-700 font-mono block">
                      REAR (TAIL)
                    </span>
                    <span className="text-xs text-slate-400 font-mono">← Index [{queueItems.length - 1}]</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* 2. LINKED LIST LAB: ACCURATE COUPLING POINTERS & HEX ADDRESSES */}
        {selectedTopicId === 'linkedlist' && (
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4 mb-6">
              <div>
                <h3 className="text-2xl font-bold text-slate-900">
                  Linked List Train Bogie Engine (Dynamic Pointers)
                </h3>
                <p className="text-xs text-slate-500">
                  Every node stores its data payload and a real pointer reference to the next node in dynamic heap memory.
                </p>
              </div>
              <div className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1 text-xs font-mono font-bold text-blue-700">
                Head: {coachList[0]?.memAddr || 'NULL'} • Total Nodes: {coachList.length}
              </div>
            </div>

            {/* Coach Input Bar */}
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 mb-4 bg-slate-50 border border-slate-200 rounded-2xl p-4">
              <div className="sm:col-span-5">
                <label className="block text-xs font-bold text-slate-600 mb-1">New Coach Code</label>
                <input
                  type="text"
                  value={newCoachCode}
                  onChange={(e) => setNewCoachCode(e.target.value)}
                  placeholder="e.g. B2, PantryCar, PC1, GEN..."
                  className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 font-bold uppercase"
                />
              </div>

              <div className="sm:col-span-4">
                <label className="block text-xs font-bold text-slate-600 mb-1">Coach Class & Seats</label>
                <div className="flex gap-2">
                  <select
                    value={newCoachType}
                    onChange={(e) => setNewCoachType(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-xl px-2 py-2 text-xs font-semibold text-slate-800"
                  >
                    <option value="1A">AC First Class (1A)</option>
                    <option value="2A">AC 2-Tier (2A)</option>
                    <option value="3A">AC 3-Tier (3A)</option>
                    <option value="SL">Sleeper Class (SL)</option>
                    <option value="PC">Pantry / Dining Car</option>
                  </select>
                  <input
                    type="number"
                    value={newCoachSeats}
                    onChange={(e) => setNewCoachSeats(parseInt(e.target.value, 10) || 0)}
                    className="w-20 bg-white border border-slate-200 rounded-xl px-2 py-2 text-xs text-slate-800 font-bold text-center"
                    title="Berth Capacity"
                  />
                </div>
              </div>

              <div className="sm:col-span-3 flex items-end">
                <span className="text-[11px] text-slate-500 font-medium">
                  Use the 3 operation panels below to insert or delete at Start, Middle, or Last!
                </span>
              </div>
            </div>

            {/* 3 Explicit Linked List Operation Sections: START, MIDDLE, LAST */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              {/* 1. START (Head) Operations */}
              <div className="p-4 rounded-2xl bg-indigo-50/70 border border-indigo-200 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-bold uppercase tracking-wider text-indigo-900">
                      1. Start (Head)
                    </span>
                    <span className="text-[10px] font-mono font-bold bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded">
                      Index [0]
                    </span>
                  </div>
                  <p className="text-xs text-indigo-950 font-medium mb-3">
                    Fast O(1) pointer redirection at the head of the train.
                  </p>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={handleInsertCoachHead}
                    className="flex-1 py-2 px-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-xs"
                  >
                    Insert Head
                  </button>
                  <button
                    onClick={handleDeleteCoachHead}
                    disabled={coachList.length === 0}
                    className="flex-1 py-2 px-3 bg-rose-600 hover:bg-rose-700 disabled:bg-slate-200 text-white font-bold rounded-xl text-xs shadow-xs"
                  >
                    Delete Head
                  </button>
                </div>
              </div>

              {/* 2. MIDDLE Operations */}
              <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-200 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-bold uppercase tracking-wider text-blue-900">
                      2. Middle (In-Between)
                    </span>
                    <div className="flex items-center gap-1">
                      <span className="text-[10px] font-bold text-blue-800">Pos:</span>
                      <input
                        type="number"
                        min="1"
                        max={Math.max(1, coachList.length - 1)}
                        value={middleInsertIndex}
                        onChange={(e) => {
                          const val = parseInt(e.target.value, 10) || 1;
                          setMiddleInsertIndex(val);
                          setMiddleDeleteIndex(val);
                        }}
                        className="w-12 bg-white border border-blue-300 rounded px-1 text-center text-xs font-bold font-mono"
                      />
                    </div>
                  </div>
                  <p className="text-xs text-blue-950 font-medium mb-3">
                    Couples or uncouples node inside the chain with O(1) pointer relinking.
                  </p>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={handleInsertCoachMiddle}
                    className="flex-1 py-2 px-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs shadow-xs"
                  >
                    Insert Middle
                  </button>
                  <button
                    onClick={handleDeleteCoachMiddle}
                    disabled={coachList.length <= 1}
                    className="flex-1 py-2 px-3 bg-rose-600 hover:bg-rose-700 disabled:bg-slate-200 text-white font-bold rounded-xl text-xs shadow-xs"
                  >
                    Delete Middle
                  </button>
                </div>
              </div>

              {/* 3. LAST (Tail) Operations */}
              <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-bold uppercase tracking-wider text-amber-900">
                      3. Last (Tail)
                    </span>
                    <span className="text-[10px] font-mono font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded">
                      Index [{Math.max(0, coachList.length - 1)}]
                    </span>
                  </div>
                  <p className="text-xs text-amber-950 font-medium mb-3">
                    Attaches or detaches node at the very end of the train next to NULL.
                  </p>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={handleInsertCoachEnd}
                    className="flex-1 py-2 px-3 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-xs shadow-xs"
                  >
                    Insert Tail
                  </button>
                  <button
                    onClick={handleDeleteCoachEnd}
                    disabled={coachList.length === 0}
                    className="flex-1 py-2 px-3 bg-rose-600 hover:bg-rose-700 disabled:bg-slate-200 text-white font-bold rounded-xl text-xs shadow-xs"
                  >
                    Delete Tail
                  </button>
                </div>
              </div>
            </div>

            {/* Operation Log */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 mb-6 flex items-center gap-2 text-xs">
              <span className="px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-800 font-mono font-bold uppercase shrink-0">
                Pointer Engine
              </span>
              <span className="text-slate-700 font-mono font-medium leading-relaxed">{linkedListOpLog}</span>
            </div>

            {/* Visual Node Pointer Chain */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 overflow-x-auto no-scrollbar">
              <div className="flex items-center gap-3">
                <div className="text-center font-mono text-xs font-bold text-blue-700 shrink-0">
                  HEAD PTR →
                </div>

                {coachList.map((coach, i) => (
                  <React.Fragment key={coach.id}>
                    <div className="p-4 rounded-2xl bg-white border-2 border-blue-400 shadow-xs flex flex-col justify-between min-w-[200px] shrink-0">
                      <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 mb-2 border-b border-slate-100 pb-1">
                        <span className="text-blue-700 font-bold">Node #{i + 1}</span>
                        <div className="flex gap-1">
                          <button
                            onClick={() => {
                              setEditingCoachId(coach.id);
                              setEditCoachCode(coach.coachCode);
                            }}
                            className="p-1 text-slate-400 hover:text-blue-600"
                            title="Edit coach"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteCoachNode(coach.id)}
                            className="p-1 text-slate-400 hover:text-rose-600"
                            title="Delete coach (detach node)"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {editingCoachId === coach.id ? (
                        <div className="flex items-center gap-1 my-1">
                          <input
                            type="text"
                            value={editCoachCode}
                            onChange={(e) => setEditCoachCode(e.target.value)}
                            className="bg-slate-50 border border-blue-400 rounded px-1.5 py-0.5 text-xs w-full font-bold"
                          />
                          <button
                            onClick={() => handleSaveCoachEdit(coach.id)}
                            className="p-1 bg-blue-600 text-white rounded"
                          >
                            <Check className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <strong className="text-base font-bold text-slate-900 my-1">{coach.coachCode}</strong>
                      )}

                      <span className="text-xs text-slate-500 font-medium">{coach.coachType}</span>

                      {/* Memory & Next Pointer Block */}
                      <div className="mt-3 bg-slate-50 border border-slate-200 rounded-xl p-2 text-[10px] font-mono space-y-1">
                        <div className="flex justify-between text-slate-600">
                          <span>this_addr:</span>
                          <strong className="text-slate-800">{coach.memAddr}</strong>
                        </div>
                        <div className="flex justify-between text-blue-700 font-bold">
                          <span>next_ptr:</span>
                          <span>{coach.nextAddr}</span>
                        </div>
                      </div>
                    </div>

                    {/* Coupling Hook Pointer Arrow */}
                    <div className="flex flex-col items-center justify-center shrink-0">
                      <span className="text-[10px] font-mono text-blue-600 font-bold">coupling</span>
                      <span className="text-blue-600 font-mono font-bold text-2xl">→</span>
                    </div>
                  </React.Fragment>
                ))}

                <div className="bg-slate-200 rounded-xl px-4 py-3 font-mono text-xs font-bold text-slate-600 shrink-0">
                  NULL (End of Train)
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 3. HASH MAP LAB: ACCURATE POLYNOMIAL HASH MATH & BUCKET COLLISION */}
        {selectedTopicId === 'hashmap' && (
          <div className="space-y-6">
            <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4 mb-6">
                <div>
                  <h3 className="text-2xl font-bold text-slate-900">
                    Accurate Polynomial Hash Calculator & Bucket Engine
                  </h3>
                  <p className="text-xs text-slate-500">
                    Computes exact ASCII summation: h(k) = (Σ ASCII[i] × 31ⁿ⁻ⁱ) mod 16.
                  </p>
                </div>
                <div className="bg-blue-50 border border-blue-200 rounded-xl px-3 py-1 text-xs font-mono font-bold text-blue-700">
                  Modulus: 16 Buckets • Total Keys: {hashTable.length}
                </div>
              </div>

              {/* Add Key-Value Controls */}
              <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 mb-6">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-600 mb-1">Enter 10-Digit PNR Key</label>
                  <input
                    type="text"
                    value={hashKeyInput}
                    onChange={(e) => setHashKeyInput(e.target.value)}
                    placeholder="e.g. 9482019482"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 font-mono font-bold"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-600 mb-1">Passenger / Ticket Record</label>
                  <input
                    type="text"
                    value={hashValInput}
                    onChange={(e) => setHashValInput(e.target.value)}
                    placeholder="e.g. Vande Bharat - Seat 1A-2"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 font-medium"
                  />
                </div>
                <div className="flex items-end">
                  <button
                    onClick={handleAddHash}
                    className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs shadow-xs"
                  >
                    Compute & Put(K, V)
                  </button>
                </div>
              </div>

              {/* Live Hash Calculation Inspector & Search */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 mb-6">
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">
                  Live Key Hash Inspector & Direct O(1) Probe
                </label>
                <div className="flex gap-2 mb-4">
                  <input
                    type="text"
                    value={searchHashQuery}
                    onChange={(e) => setSearchHashQuery(e.target.value)}
                    placeholder="Enter PNR to inspect mathematical hash formula and bucket..."
                    className="flex-1 bg-white border border-slate-200 rounded-xl px-4 py-2 text-sm font-mono text-slate-800"
                  />
                  <button
                    onClick={handleSearchHash}
                    className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-xs"
                  >
                    Inspect Hash & Probe
                  </button>
                </div>

                {searchHashOutput && (
                  <div className="bg-white border border-emerald-300 rounded-xl p-4 text-xs space-y-2 animate-in fade-in">
                    <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                      <strong className="text-slate-900 text-sm">
                        Calculated Hash: {searchHashOutput.rawHash} → Target: Bucket #{searchHashOutput.bucketIndex}
                      </strong>
                      <span className="font-mono text-emerald-700 font-bold">
                        Probe Count: {searchHashOutput.probes} ({searchHashOutput.found ? 'Match Found' : 'Empty Probe'})
                      </span>
                    </div>

                    <div className="text-slate-600 font-mono">
                      <strong>Character ASCII Mapping: </strong>
                      {searchHashOutput.asciiBreakdown.map((a, i) => (
                        <span key={i} className="mr-2">
                          '{a.char}'={a.ascii}
                        </span>
                      ))}
                    </div>

                    {searchHashOutput.found && searchHashOutput.entry && (
                      <div className="p-2 bg-emerald-50 rounded-lg text-emerald-950 font-medium">
                        Stored Value: <strong>{searchHashOutput.entry.value}</strong>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Stored Key Entries with Delete Button */}
              <div>
                <span className="text-xs font-bold uppercase text-slate-500 tracking-wider block mb-3">
                  Active Keys in Hash Table (Click Trash to Delete):
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {hashTable.map((h, idx) => (
                    <div
                      key={idx}
                      className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex items-center justify-between"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-blue-700 text-sm">{h.key}</span>
                          <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-blue-100 text-blue-800 font-bold">
                            Bucket #{h.bucketIndex}
                          </span>
                        </div>
                        <span className="text-xs text-slate-600 block mt-0.5">{h.value}</span>
                      </div>

                      <button
                        onClick={() => handleDeleteHash(h.key)}
                        className="p-1.5 text-slate-400 hover:text-rose-600"
                        title="Delete key from table"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <PNRHashVisualizer />
          </div>
        )}

        {/* 4. GRAPH LAB: NORMAL CLEAN MAP WITH GREEN ROUTE ON SEARCH */}
        {selectedTopicId === 'graph' && <RadiumGraphVisualizer />}

        {/* 5. STACK LAB: ACCURATE LIFO ACTIONS & AUDIT ROLLBACK */}
        {selectedTopicId === 'stack' && (
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4 mb-6">
              <div>
                <h3 className="text-2xl font-bold text-slate-900">
                  Accurate Stack (LIFO) Action Rollback Engine
                </h3>
                <p className="text-xs text-slate-500">
                  Last In, First Out audit stack. push() places on TOP; pop() returns the most recent transaction in O(1).
                </p>
              </div>
              <div className="bg-purple-50 border border-purple-200 rounded-xl px-3 py-1 text-xs font-mono font-bold text-purple-700">
                TOP Index: [{stackItems.length > 0 ? stackItems.length - 1 : 0}] • Stack Height: {stackItems.length}
              </div>
            </div>

            {/* Controls */}
            <div className="flex gap-2 mb-6">
              <input
                type="text"
                value={newStackAction}
                onChange={(e) => setNewStackAction(e.target.value)}
                placeholder="Push custom transaction (e.g. 5. Refund Credited to Bank)..."
                className="bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 flex-1 font-medium"
              />
              <button
                onClick={handlePushStack}
                className="px-5 py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl text-xs shadow-xs"
              >
                Push(Action)
              </button>
              <button
                onClick={handlePopStack}
                disabled={stackItems.length === 0}
                className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 disabled:bg-slate-200 text-white font-bold rounded-xl text-xs shadow-xs"
              >
                Pop(Undo Top)
              </button>
            </div>

            {/* Live Log */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 mb-6 flex items-center gap-2 text-xs">
              <span className="px-2 py-0.5 rounded-md bg-purple-100 text-purple-800 font-mono font-bold uppercase shrink-0">
                Stack Log
              </span>
              <span className="text-slate-700 font-mono font-medium leading-relaxed">{stackOpLog}</span>
            </div>

            {/* Visual Stack Array */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 flex flex-col-reverse gap-2.5 items-center min-h-[160px]">
              {stackItems.length === 0 ? (
                <div className="text-center text-slate-400 text-sm py-4">
                  Stack is empty (Underflow state). Push actions above!
                </div>
              ) : (
                stackItems.map((s, idx) => {
                  const isTop = idx === stackItems.length - 1;
                  return (
                    <div
                      key={s.id}
                      className={`w-full max-w-lg p-3.5 rounded-2xl border flex items-center justify-between transition-all ${
                        isTop
                          ? 'bg-purple-50 border-purple-400 text-slate-900 shadow-xs'
                          : 'bg-white border-slate-200 text-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-purple-700">[{idx}]</span>
                        <span className="font-semibold text-sm">{s.action}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-slate-400 font-mono">{s.timestamp}</span>
                        {isTop && (
                          <span className="text-[10px] font-mono font-bold uppercase bg-purple-100 text-purple-800 px-2 py-0.5 rounded">
                            TOP (LIFO)
                          </span>
                        )}
                        <button
                          onClick={() => handleDeleteStackItem(s.id)}
                          className="p-1 text-slate-400 hover:text-rose-600"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* 6. PRIORITY QUEUE LAB: ACCURATE HEAP PROPERTY & WEIGHTED QUOTAS */}
        {selectedTopicId === 'priorityqueue' && (
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4 mb-6">
              <div>
                <h3 className="text-2xl font-bold text-slate-900">
                  Priority Queue Binary Max-Heap Engine
                </h3>
                <p className="text-xs text-slate-500">
                  Elements are sorted by Priority Score. extractMax() immediately serves the highest priority request in O(log N).
                </p>
              </div>
              <div className="bg-amber-50 border border-amber-200 rounded-xl px-3 py-1 text-xs font-mono font-bold text-amber-800">
                Root Element Priority: {heapList[0]?.priority || 0}
              </div>
            </div>

            {/* Controls */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 mb-6">
              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-slate-600 mb-1">Passenger Name</label>
                <input
                  type="text"
                  value={newHeapName}
                  onChange={(e) => setNewHeapName(e.target.value)}
                  placeholder="e.g. Col. Raghavan..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">Priority Weight (1-100)</label>
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={newHeapPriority}
                  onChange={(e) => setNewHeapPriority(parseInt(e.target.value, 10) || 1)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 font-bold"
                />
              </div>

              <div className="flex items-end gap-2">
                <button
                  onClick={handleInsertHeap}
                  className="flex-1 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-xs shadow-xs"
                >
                  Insert Heap O(log N)
                </button>
                <button
                  onClick={handleExtractMaxHeap}
                  disabled={heapList.length === 0}
                  className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-200 text-white font-bold rounded-xl text-xs shadow-xs"
                >
                  Extract Max O(log N)
                </button>
              </div>
            </div>

            {/* Log */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 mb-6 flex items-center gap-2 text-xs">
              <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 font-mono font-bold uppercase shrink-0">
                Heap Engine
              </span>
              <span className="text-slate-700 font-mono font-medium leading-relaxed">{heapOpLog}</span>
            </div>

            {/* Heap List Representation */}
            <div className="space-y-3">
              {heapList.map((hp, idx) => (
                <div
                  key={hp.id}
                  className={`p-3.5 rounded-2xl border flex items-center justify-between transition-all ${
                    idx === 0
                      ? 'bg-amber-50/80 border-amber-400 shadow-xs'
                      : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="w-8 h-8 rounded-xl bg-amber-600 text-white font-mono font-bold text-xs flex items-center justify-center">
                      {hp.priority}
                    </span>
                    <div>
                      <strong className="text-sm text-slate-900 block">{hp.name}</strong>
                      <span className="text-xs text-slate-500 font-medium">Quota: {hp.quota}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {idx === 0 && (
                      <span className="text-[10px] font-mono font-bold uppercase bg-amber-200 text-amber-900 px-2 py-0.5 rounded">
                        HEAP ROOT (MAX)
                      </span>
                    )}
                    <button
                      onClick={() => handleDeleteHeapItem(hp.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 7. BINARY SEARCH LAB: BAR CHART METHOD (FULL INPUTS, POINTERS & OUTPUT ANSWER) */}
        {selectedTopicId === 'binarysearch' && <BarChartSearchVisualizer />}

        {/* 8. SORTING LAB: 3 TYPES (BUBBLE, SELECTION, INSERTION) IN BAR CHART METHOD */}
        {selectedTopicId === 'sorting' && <BarChartSortingVisualizer />}

        {/* ACCESSIBLE VISUALIZERS TABS FOR SEARCHING & SORTING ACROSS LABS */}
        {selectedTopicId !== 'binarysearch' && selectedTopicId !== 'sorting' && (
          <div className="space-y-8 mt-12 pt-8 border-t border-slate-200">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold text-slate-900">
                  Interactive Bar Chart Visualizer Suite
                </h3>
                <p className="text-xs text-slate-500">
                  Switch between Binary Search (Bar Chart Method) and 3 Sorting Algorithms (Bubble, Selection, Insertion).
                </p>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setSelectedTopicId('binarysearch')}
                  className="px-3 py-1.5 bg-blue-50 text-blue-700 hover:bg-blue-100 rounded-xl text-xs font-bold border border-blue-200"
                >
                  Open Binary Search Lab
                </button>
                <button
                  onClick={() => setSelectedTopicId('sorting')}
                  className="px-3 py-1.5 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 rounded-xl text-xs font-bold border border-indigo-200"
                >
                  Open Sorting Lab
                </button>
              </div>
            </div>

            <BarChartSearchVisualizer />
            <BarChartSortingVisualizer />
          </div>
        )}
      </div>
    </div>
  );
};
