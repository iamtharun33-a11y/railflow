import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import {
  Presentation,
  ChevronLeft,
  ChevronRight,
  Train,
  CheckCircle2
} from 'lucide-react';

export const PresentationPage: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      title: 'RailFlow: Where Railway Reservation Meets Data Structures',
      subtitle: 'The Problem & Engineering Vision',
      content: (
        <div className="space-y-4 text-base leading-relaxed text-slate-700">
          <p>
            Traditional DSA courses teach abstract data structures with disconnected toy examples. Meanwhile, real railway reservation systems handle tens of millions of bookings, waitlists, track networks, and cancellations every single day.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
            <div className="bg-slate-50 border border-blue-200 rounded-2xl p-5">
              <strong className="text-blue-700 block text-sm mb-1 font-bold">Authentic System Architecture</strong>
              <p className="text-xs text-slate-500 font-medium">
                No fake accounts or mock data. Real users register, real train seats are locked, and real waiting positions are recalculated transactionally.
              </p>
            </div>
            <div className="bg-slate-50 border border-emerald-200 rounded-2xl p-5">
              <strong className="text-emerald-700 block text-sm mb-1 font-bold">Live DSA Event Engine</strong>
              <p className="text-xs text-slate-500 font-medium">
                Every ticket booking, cancellation, and route search emits structured events driving real-time visual explanations.
              </p>
            </div>
          </div>
        </div>
      )
    },
    {
      title: 'Queue (FIFO) — Waiting List Management',
      subtitle: 'Guaranteed Passenger Fairness & Promotion',
      content: (
        <div className="space-y-4 text-base leading-relaxed text-slate-700">
          <p>
            When a coach reaches full capacity, incoming passengers are enqueued into a strict First-In, First-Out (FIFO) Waiting List.
          </p>
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 font-mono text-xs text-slate-800 space-y-2">
            <div>1. User books full train → enqueue(passenger) → Appended at REAR [O(1)]</div>
            <div>2. Confirmed user cancels ticket → seat freed</div>
            <div>3. Waiting queue checked → dequeue() → Earliest passenger promoted to CONFIRMED [O(1)]</div>
            <div>4. Remaining positions shifted up (WL2 → WL1, WL3 → WL2)</div>
          </div>
          <p className="text-xs text-slate-500 font-medium">
            <strong>Why it matters:</strong> Without a Queue, waitlist processing becomes an arbitrary lottery where early passengers could be cheated.
          </p>
        </div>
      )
    },
    {
      title: 'Hash Map — Instant O(1) PNR Ticket Lookup',
      subtitle: 'High-Throughput Key-Value Direct Addressing',
      content: (
        <div className="space-y-4 text-base leading-relaxed text-slate-700">
          <p>
            With 10 million active bookings in a railway system, scanning row-by-row with Linear Search O(N) would crash database servers during peak holiday rushes.
          </p>
          <div className="bg-slate-50 border border-blue-200 rounded-2xl p-4 text-xs space-y-2">
            <div className="text-blue-700 font-mono font-bold">Polynomial Rolling Hash Formula:</div>
            <div className="font-mono text-slate-900 bg-white p-2 rounded-xl border border-slate-200">
              h(PNR) = (Σ ASCII[i] × 31ⁿ⁻ⁱ) mod 16 → Bucket Index
            </div>
            <p className="text-slate-500 font-medium">
              The 10-digit PNR calculates the exact memory bucket slot immediately, ensuring constant O(1) average lookup time.
            </p>
          </div>
        </div>
      )
    },
    {
      title: 'Graph Network — Clean Route Discovery',
      subtitle: 'Breadth-First Search (BFS) vs Depth-First Search (DFS)',
      content: (
        <div className="space-y-4 text-base leading-relaxed text-slate-700">
          <p>
            Stations are Vertices (V) and physical railway tracks are Edges (E) with distances and travel times.
          </p>
          <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-5 text-xs space-y-3">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-600" />
              <strong className="text-emerald-900 text-sm font-bold">Breadth-First Search (BFS) Optimal Route:</strong>
            </div>
            <p className="text-slate-700 font-medium">
              BFS explores all adjacent junction stations level-by-level. In unweighted railway routing, BFS is mathematically guaranteed to find the route with the fewest station transfers, highlighted on the map in vibrant green.
            </p>
          </div>
        </div>
      )
    },
    {
      title: 'Full-Stack Architecture & Multi-Language Support',
      subtitle: 'Production Clean Stack & AI Integration',
      content: (
        <div className="space-y-4 text-base leading-relaxed text-slate-700">
          <ul className="space-y-2.5 text-xs">
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span><strong>Backend:</strong> Node.js, Express, TypeScript, transactional seat inventory & queue promotion</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span><strong>Frontend:</strong> React 19, Vite, Tailwind CSS, professional white & railway blue styling</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span><strong>Real AI Guide:</strong> Google Gemini 3.8 Flash SDK for real-time multilingual mentorship</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span><strong>Multilingual:</strong> Complete support for English, Tamil (தமிழ்), and Hindi (हिन्दी)</span>
            </li>
          </ul>
        </div>
      )
    }
  ];

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800 py-12 px-4 sm:px-6 lg:px-8 flex flex-col justify-between">
      <div className="max-w-4xl mx-auto w-full">
        {/* Presentation Header */}
        <div className="flex items-center justify-between border-b border-slate-200 pb-4 mb-8">
          <div className="flex items-center gap-2">
            <Presentation className="w-5 h-5 text-blue-600" />
            <span className="font-bold text-sm tracking-wide text-slate-900 uppercase">
              RailFlow Technical Presentation Deck
            </span>
          </div>
          <span className="text-xs text-slate-500 font-mono font-medium">
            Slide {currentSlide + 1} of {slides.length}
          </span>
        </div>

        {/* Slide Canvas */}
        <div className="bg-white border border-slate-200 rounded-3xl p-8 sm:p-12 shadow-xs min-h-[420px] flex flex-col justify-between mb-8 relative">
          <div>
            <span className="text-xs font-mono font-bold uppercase tracking-wider text-blue-700 block mb-1">
              {slides[currentSlide].subtitle}
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mb-6">
              {slides[currentSlide].title}
            </h2>

            <div>{slides[currentSlide].content}</div>
          </div>

          <div className="pt-8 flex items-center justify-between border-t border-slate-100 mt-8">
            <button
              onClick={() => setCurrentSlide((prev) => Math.max(0, prev - 1))}
              disabled={currentSlide === 0}
              className="flex items-center gap-1.5 px-4 py-2 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 text-slate-800 rounded-xl text-xs font-bold transition-all"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Previous</span>
            </button>

            <div className="flex gap-1.5">
              {slides.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentSlide(i)}
                  className={`w-2.5 h-2.5 rounded-full transition-all ${
                    currentSlide === i ? 'bg-blue-600 w-6' : 'bg-slate-200'
                  }`}
                />
              ))}
            </div>

            <button
              onClick={() => setCurrentSlide((prev) => Math.min(slides.length - 1, prev + 1))}
              disabled={currentSlide === slides.length - 1}
              className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
            >
              <span>Next</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
