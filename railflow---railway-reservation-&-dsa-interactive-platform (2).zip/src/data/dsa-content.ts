import { DSATopicContent, GameChallenge } from '../types';

export const DSA_TOPICS: DSATopicContent[] = [
  {
    id: 'queue',
    name: 'Queue (FIFO)',
    shortTag: 'FIFO Protocol',
    timeComplexity: 'O(1) Enqueue & Dequeue',
    spaceComplexity: 'O(N)',
    railwayFeature: 'Waiting List Management & Seat Promotion',
    translations: {
      en: {
        definition: 'A Queue is an ordered collection where elements are added at the rear and removed from the front, strictly following FIFO (First In, First Out).',
        whyUsed: 'In RailFlow, when all confirmed train seats are fully booked, new passengers join the Waiting List. Using a Queue ensures that whoever booked earlier is guaranteed to be promoted first the moment another passenger cancels their ticket.',
        whatHappensIfNotUsed: 'If we do NOT use a Queue, waiting lists become totally unfair and chaotic! Passengers who waited 10 hours could be jumped by someone who joined 5 seconds ago. Cancellations would become an unfair random lottery, causing severe passenger outrage and system integrity failure.',
        railwayAnalogy: 'Think of standing in a physical ticket counter line at the railway station: the first person standing in line gets their ticket first; cutting the line is strictly forbidden!'
      },
      ta: {
        definition: 'Queue என்பது ஒரு வரிசை அமைப்பு. இதில் முதலில் உள்ளே வரும் நபர் முதலில் வெளியே செல்வார் (FIFO - First In, First Out).',
        whyUsed: 'ரயிலில் சீட்டுகள் முடிந்ததும் பயணிகள் Waiting List-ல் சேர்க்கப்படுகிறார்கள். டிக்கெட் ரத்து செய்யப்படும்போது, முதலில் Waiting List-ல் சேர்ந்தவருக்கே முதலில் உறுதிப்படுத்தப்பட்ட சீட் வழங்க Queue பயன்படுகிறது.',
        whatHappensIfNotUsed: 'நாம் Queue பயன்படுத்தாவிட்டால் என்ன ஆகும்? கடுமையான குழப்பம் மற்றும் அநீதி ஏற்படும்! 10 மணி நேரமாக காத்திருக்கும் பயணியை விட்டுவிட்டு, கடைசியாக வந்தவருக்கு சீட் போய்விடும். இதனால் டிக்கெட் முன்பதிவு ஒரு நியாயமற்ற லாட்டரியாக மாறிவிடும்.',
        railwayAnalogy: 'ரயில்வே கவுண்டரில் வரிசையில் நிற்பது போன்றது: வரிசையில் முதலில் நின்றவருக்கே முதலில் டிக்கெட் கிடைக்கும்; குறுக்கே புக முடியாது!'
      },
      hi: {
        definition: 'Queue (पंक्ति) एक ऐसा डेटा स्ट्रक्चर है जो FIFO (First In, First Out) सिद्धांत पर काम करता है—जो पहले आएगा, वह पहले पाएगा।',
        whyUsed: 'RailFlow में जब सभी सीटें भर जाती हैं, तो यात्रियों को Waiting List में डाला जाता है। Queue यह सुनिश्चित करता है कि जब भी कोई टिकट रद्द हो, तो सबसे पहले प्रतीक्षा सूची में आए व्यक्ति को ही सीट मिले।',
        whatHappensIfNotUsed: 'अगर हम Queue का उपयोग नहीं करेंगे तो क्या होगा? पूरी व्यवस्था अराजक और अन्यायपूर्ण हो जाएगी! जो यात्री 5 घंटे से प्रतीक्षा कर रहा है, उसे छोड़कर 2 मिनट पहले आए व्यक्ति को सीट मिल जाएगी।',
        railwayAnalogy: 'रेलवे टिकट खिड़की पर लगी लाइन की तरह: जो पहले कतार में खड़ा होता है, उसे ही पहले टिकट मिलता है।'
      }
    }
  },
  {
    id: 'hashmap',
    name: 'Hash Map (PNR Lookup)',
    shortTag: 'O(1) Direct Key',
    timeComplexity: 'O(1) Average Lookup',
    spaceComplexity: 'O(N)',
    railwayFeature: 'Instant 10-Digit PNR Status Lookup',
    translations: {
      en: {
        definition: 'Hashing is like a smart postal locker system: you give your 10-digit PNR number to a mathematical formula (Hash Function), and it instantly tells the computer the exact Box/Bucket number where your ticket is kept, in just 1 step: O(1) Time!',
        whyUsed: 'In RailFlow, there are millions of passengers. If we search passenger by passenger from #1 to #10,00,000, it would take several minutes. With Hashing, typing your 10-digit PNR calculates the exact box location immediately, giving you instant seat status in 0.001 seconds!',
        whatHappensIfNotUsed: 'If we do NOT use Hashing, the railway computer has to check every single passenger ticket one by one (Linear Search). If 10 lakh people check PNR status at the same time during Tatkal hours, the entire railway server freezes and crashes!',
        railwayAnalogy: 'Railway Station Luggage Cloakroom with 16 numbered shelves: when you deposit luggage, you get a token (PNR). Instead of the station master opening all 10,000 bags to find yours, the formula tells them "Go directly to Shelf #4" and hands you your bag in 3 seconds!'
      },
      ta: {
        definition: 'Hashing என்பது ரயில் நிலைய லக்கேஜ் லாக்கர் (Locker) போன்றது: உங்கள் 10-இலக்க PNR எண்ணை ஒரு எளிய கணக்கு பார்முலாவிடம் கொடுத்தால், அது உங்கள் டிக்கெட் எந்த பெட்டியில் (Bucket) இருக்கிறது என்பதை உடனே O(1) நேரத்தில் கண்டுபிடித்து கொடுத்துவிடும்!',
        whyUsed: 'RailFlow-ல் லட்சக்கணக்கான பயணிகள் டிக்கெட் எடுப்பார்கள். உங்கள் PNR-ஐ 1-வது பயணியிலிருந்து 10,00,000-வது பயணி வரை ஒவ்வொன்றாக தேடாமல், ஒரே நொடியில் உங்கள் சீட் உறுதியானதா (Confirmed) அல்லது வெயிட்டிங் லிஸ்ட்டா என்று உடனே காட்ட Hashing பயன்படுகிறது.',
        whatHappensIfNotUsed: 'நாம் Hashing பயன்படுத்தாவிட்டால் என்ன ஆகும்? ஒவ்வொரு முறையும் லட்சக்கணக்கான டிக்கெட்டுகளையும் வரிசையாக ஒவ்வொன்றாக தேட வேண்டும் (Linear Search). தட்கல் (Tatkal) நேரத்தில் ஒரே நேரத்தில் பல்லாயிரக்கணக்கான மக்கள் PNR பார்க்கும்போது ரயில்வே சர்வர் முடங்கி (Crash) போய்விடும்!',
        railwayAnalogy: 'ரயில் நிலைய லக்கேஜ் அறை (Cloakroom): 16 வரிசை அலமாரிகள் இருக்கும். உங்கள் டோக்கன் (PNR) எண்ணை பார்த்ததும், ஊழியர் நேராக அலமாரி எண் 4-க்கு சென்று உங்கள் பையை உடனே எடுத்து தருவது போன்றது; எல்லா பைகளையும் பிரித்துப் பார்க்க மாட்டார்!'
      },
      hi: {
        definition: 'Hashing रेलवे स्टेशन के लॉकर सिस्टम जैसा है: आपका 10-अंकीय PNR नंबर एक गणितीय फ़ंक्शन में जाता है और सीधे बताता है कि आपकी टिकट किस बॉक्स (Bucket) में रखी है—सिर्फ 1 कदम में: O(1) Time!',
        whyUsed: 'लाखों यात्रियों में से आपकी टिकट को एक-एक करके ढूंढने के बजाय, PNR डालते ही 0.001 सेकंड में कन्फर्म सीट और कोच नंबर स्क्रीन पर दिखाने के लिए हम Hashing का उपयोग करते हैं।',
        whatHappensIfNotUsed: 'अगर हम Hashing का उपयोग नहीं करेंगे, तो कंप्यूटर को लाखों टिकटों को एक-एक करके खोजना पड़ेगा (Linear Search)। इससे तत्काल के समय रेलवे की पूरी वेबसाइट हैंग और क्रैश हो जाएगी!',
        railwayAnalogy: 'रेलवे क्लॉक रूम (Cloakroom): जहाँ 10,000 बैग रखे हैं। आपके टोकन नंबर से मास्टर सीधे अलमारी नंबर 4 पर जाकर आपका बैग तुरंत निकाल देता है, हर बैग खोलकर नहीं देखना पड़ता!'
      }
    }
  },
  {
    id: 'graph',
    name: 'Graph (Routes & BFS/DFS)',
    shortTag: 'Network Topology',
    timeComplexity: 'O(V + E) Traversal',
    spaceComplexity: 'O(V + E)',
    railwayFeature: 'Inter-City Railway Tracks, BFS Shortest Hops & DFS Route Discovery',
    translations: {
      en: {
        definition: 'A Graph is a mathematical network consisting of Vertices (Stations) connected by Edges (Railway Tracks) with distances, travel times, and junctions.',
        whyUsed: 'RailFlow models the entire national railway grid as an interconnected Graph. We run Breadth-First Search (BFS) to display optimal routes in glowing Radium Green (#00FF66) to find the fewest station transfers, and DFS to explore scenic detour paths.',
        whatHappensIfNotUsed: 'If we do NOT use a Graph, computers cannot comprehend how railway junctions connect! We would have to hardcode every single possible combination of stations manually. If a track between Delhi and Mumbai gets blocked, the system would be unable to recalculate alternative detour routes automatically.',
        railwayAnalogy: 'A subway or railway map where cities are colored station dots and train tracks are colorful lines connecting them across the country.'
      },
      ta: {
        definition: 'Graph என்பது ரயில் நிலையங்களை முனைகளாகவும் (Vertices), அவற்றுக்கு இடையேயான ரயில் தண்டவாளங்களை இணைப்புகளாகவும் (Edges) காட்டும் வலைப்பின்னல் அமைப்பு.',
        whyUsed: 'ரயில் நிலையங்களுக்கு இடையே மிகக் குறைந்த தூரத்தையும், குறைவான நிறுத்தங்களையும் கொண்ட பாதையை ரேடியம் பச்சை (Radium Green #00FF66) நிறத்தில் ஒளிரச்செய்து BFS மற்றும் DFS மூலம் கண்டுபிடிக்க Graph பயன்படுகிறது.',
        whatHappensIfNotUsed: 'நாம் Graph பயன்படுத்தாவிட்டால் என்ன ஆகும்? எந்த நிலையத்திற்கு அடுத்து எந்த ரயில் பாதை போகிறது என்பதை கணினியால் புரிந்துகொள்ள முடியாது! ஒரு பாதையில் விபத்து அல்லது தடை ஏற்பட்டால் மாற்று வழியை (detour) கணினியால் கண்டுபிடிக்க முடியாது.',
        railwayAnalogy: 'நமது முழு இந்திய ரயில்வே வரைபடம்: நகரங்கள் புள்ளிகள், தண்டவாளங்கள் கோடுகள்; எந்த வழியில் சுலபமாக செல்லலாம் என்று கணக்கிட உதவும் வரைபடம்!'
      },
      hi: {
        definition: 'Graph एक नेटवर्क संरचना है जहाँ रेलवे स्टेशन Vertices (नोड्स) होते हैं और उनके बीच की रेल पटरियाँ Edges (किनारे) होती हैं।',
        whyUsed: 'स्टेशनों के बीच सबसे तेज़ और कम स्टॉप वाला रास्ता खोजने के लिए हम Graph में BFS चलाते हैं, जो स्क्रीन पर चमकदार रेडियम ग्रीन (#00FF66) में चमकता है।',
        whatHappensIfNotUsed: 'अगर हम Graph का उपयोग नहीं करेंगे तो क्या होगा? कंप्यूटर यह कभी समझ नहीं पाएगा कि कौन सा स्टेशन किससे जुड़ा है! अगर कोई पटरी ख़राब हो जाए तो वैकल्पिक रास्ता खोजना नामुमकिन हो जाएगा।',
        railwayAnalogy: 'रेलवे का रूट मैप—जहाँ हर शहर एक स्टेशन नोड है और पटरियाँ उन्हें जोड़ती हैं।'
      }
    }
  },
  {
    id: 'stack',
    name: 'Stack (LIFO)',
    shortTag: 'LIFO Protocol',
    timeComplexity: 'O(1) Push & Pop',
    spaceComplexity: 'O(N)',
    railwayFeature: 'Ticket Cancellation Audit Log & Undo Actions',
    translations: {
      en: {
        definition: 'A Stack is a linear data structure that follows LIFO (Last In, First Out), where elements are inserted and removed from the same end, called the TOP.',
        whyUsed: 'In RailFlow, every cancellation, payment rollback, and passenger detail modification is pushed onto a Stack. When an auditor or passenger requests an action undo or refund trace, the system pops the most recent action first in O(1) time.',
        whatHappensIfNotUsed: 'If we do NOT use a Stack, maintaining transaction rollback is practically impossible! If a multi-step booking fails midway (e.g. money deducted but seat failed to lock), the system would not know what step occurred last to safely roll back the payment.',
        railwayAnalogy: 'A stack of clean train cafeteria trays: the last clean tray placed on top is the first tray picked up by a hungry passenger!'
      },
      ta: {
        definition: 'Stack என்பது கடைசியாக வைக்கப்பட்ட பொருள் முதலில் வெளியே வரும் (LIFO - Last In, First Out) அடுக்கு அமைப்பு ஆகும்.',
        whyUsed: 'டிக்கெட் ரத்து செய்தல், கட்டணம் திரும்பப் பெறுதல் (Refunds), மற்றும் செய்த செயல்களை மாற்றுதல் (Undo) போன்றவற்றிற்கு Stack பயன்படுகிறது.',
        whatHappensIfNotUsed: 'நாம் Stack பயன்படுத்தாவிட்டால் என்ன ஆகும்? பணம் செலுத்தப்பட்டு சீட் கிடைக்காத போது, கடைசியாக என்ன நடந்தது என்று தெரியாமல் பரிவர்த்தனையை திரும்பப் பெற (Rollback) முடியாது. பயணிகளின் பணம் மாட்டிக்கொள்ளும்!',
        railwayAnalogy: 'ரயில் சிற்றுண்டி கூடத்தில் அடுக்கப்பட்ட தட்டுகள்: கடைசியாக மேலே வைக்கப்பட்ட தட்டே முதலில் எடுக்கப்படும்!'
      },
      hi: {
        definition: 'Stack LIFO (Last In, First Out) के नियम पर चलता है—जो चीज़ सबसे अंत में ऊपर रखी जाती है, वह सबसे पहले निकाली जाती है।',
        whyUsed: 'टिकट रद्द करने के ऑडिट लॉग और पेमेंट असफल होने पर तुरंत पिछली स्थिति में लौटने (Undo/Rollback) के लिए Stack का उपयोग होता है।',
        whatHappensIfNotUsed: 'अगर हम Stack का उपयोग नहीं करेंगे तो क्या होगा? अगर टिकट बुक करते समय बीच में पेमेंट अटक जाए, तो सिस्टम को पता ही नहीं चलेगा कि आखिरी प्रक्रिया क्या थी और रिफंड अटक जाएगा।',
        railwayAnalogy: 'ट्रेन की पैंट्री में रखी थालियों का ढेर: सबसे ऊपर रखी थाली ही सबसे पहले उठाई जाती है!'
      }
    }
  },
  {
    id: 'linkedlist',
    name: 'Linked List (Bogie Chain)',
    shortTag: 'Node Pointer Chain',
    timeComplexity: 'O(1) Insertion at Pointer',
    spaceComplexity: 'O(N)',
    railwayFeature: 'Dynamic Coach (Bogie) Shunting & Passenger Sequencing',
    translations: {
      en: {
        definition: 'A Linked List consists of sequential data nodes where each node stores both its payload and a reference pointer pointing to the next node in line.',
        whyUsed: 'Trains frequently decouple or attach extra coaches (bogies) at major railway junctions. A Linked List allows inserting an extra 3-Tier AC coach into the middle of a 24-coach train in O(1) pointer operations without shifting memory arrays.',
        whatHappensIfNotUsed: 'If we use a fixed static array, adding a coach in the middle requires shifting every single subsequent coach one-by-one (O(N) operation). In digital train composition, this causes memory fragmentation and heavy latency.',
        railwayAnalogy: 'The physical iron coupling hook between train coaches! Coach S1 hooks onto Coach S2, which hooks onto Coach S3. You can unhook S2 and snap in an extra coach in seconds!'
      },
      ta: {
        definition: 'Linked List என்பது ஒவ்வொரு பெட்டியும் அடுத்த பெட்டியை இணைக்கும் கொக்கி (Pointer) போல அடுத்த உறுப்பை சுட்டிக்காட்டும் சங்கிலி அமைப்பு.',
        whyUsed: 'ரயிலில் தேவைக்கேற்ப நடுவில் கூடுதல் பெட்டியை இணைக்க (Shunting) அல்லது கழற்ற Linked List பயன்படுகிறது. சுட்டிக்காட்டி (pointer) முகவரியை மட்டும் மாற்றினால் போதும்.',
        whatHappensIfNotUsed: 'நாம் Linked List பயன்படுத்தாமல் சாதாரண நிலையான Array பயன்படுத்தினால், நடுவில் ஒரு பெட்டியை சேர்க்க அனைத்து பெட்டிகளையும் நகர்த்த வேண்டியிருக்கும் (O(N)), இதனால் கணினியின் வேகம் குறையும்.',
        railwayAnalogy: 'ரயில் பெட்டிகளுக்கு இடையே உள்ள இரும்பு கொக்கி இணைப்பு! S1 பெட்டியின் கொக்கி S2 பெட்டியை இணைக்கிறது.'
      },
      hi: {
        definition: 'Linked List में हर नोड में डेटा और अगले नोड का पॉइंटर (लिंक) होता है, जिससे यह एक लचीली चेन बन जाती है।',
        whyUsed: 'ट्रेन में बीच में अतिरिक्त डिब्बा (Coach/Bogie) जोड़ने या हटाने के लिए यह सबसे बेहतरीन है क्योंकि इसमें सिर्फ पॉइंटर बदलना होता है।',
        whatHappensIfNotUsed: 'अगर हम सामान्य ऐरे (Array) इस्तेमाल करेंगे, तो बीच में एक डिब्बा जोड़ने के लिए बाकी सभी 20 डिब्बों को मेमोरी में खिसकाना पड़ेगा जो बहुत धीमा होता है।',
        railwayAnalogy: 'ट्रेन के डिब्बों के बीच का कपलिंग हुक—हुक खोलो और तुरंत नया डिब्बा जोड़ दो!'
      }
    }
  },
  {
    id: 'priorityqueue',
    name: 'Priority Queue (Heaps)',
    shortTag: 'Priority Heap',
    timeComplexity: 'O(log N) Insert & Extract',
    spaceComplexity: 'O(N)',
    railwayFeature: 'Tatkal, Senior Citizen & Medical Emergency Quotas',
    translations: {
      en: {
        definition: 'A Priority Queue is an advanced data structure where elements have priority levels, and the item with highest priority is served before lower-priority items.',
        whyUsed: 'While general waiting lists use standard FIFO Queues, emergency bookings (medical transit, military movement, senior citizens) possess higher priority weights. RailFlow uses a Min-Heap / Max-Heap to extract the highest priority request in O(log N) time.',
        whatHappensIfNotUsed: 'If we do NOT use a Priority Queue, emergency requests would sit at the very back of a 500-person normal waiting list, unable to be prioritized for life-saving medical transfers.',
        railwayAnalogy: 'An ambulance siren on a railway level crossing: ordinary traffic yields so the emergency vehicle crosses first!'
      },
      ta: {
        definition: 'Priority Queue என்பது முன்னுரிமை அடிப்படையில் (முதியவர்கள், அவசர மருத்துவ உதவி) உள்ள பயணிகளுக்கு முன்னுரிமை கொடுத்து இயங்கும் அமைப்பு.',
        whyUsed: 'சாதாரண வெயிட்டிங் லிஸ்ட்டில் இருந்தாலும், அவசர மருத்துவ உதவி அல்லது ராணுவ பயணிகளுக்கு அதிக முன்னுரிமை வழங்கி டிக்கெட் ஒதுக்க இது பயன்படுகிறது.',
        whatHappensIfNotUsed: 'நாம் Priority Queue பயன்படுத்தாவிட்டால், அவசர சிகிச்சைக்காக செல்லும் ஒரு நோயாளியும் 500 பேர் காத்திருக்கும் பொது வரிசையில்தான் நிற்க வேண்டியிருக்கும்!',
        railwayAnalogy: 'ரயில்வே கேட்டில் ஆம்புலன்ஸ் வரும்போது அதற்கு மட்டும் முன்னுரிமை கொடுத்து உடனே திறந்து விடுவது போன்றது!'
      },
      hi: {
        definition: 'Priority Queue में हर तत्व की एक प्राथमिकता (Priority) होती है, और सबसे अधिक प्राथमिकता वाले काम को पहले निपटाया जाता है।',
        whyUsed: 'आपातकालीन कोटा, वरिष्ठ नागरिक और मेडिकल इमरजेंसी टिकटों को सामान्य कतार से ऊपर प्राथमिकता देने के लिए इसका उपयोग होता है।',
        whatHappensIfNotUsed: 'अगर यह न हो, तो किसी गंभीर रूप से बीमार यात्री को भी 500 लोगों के पीछे सामान्य लाइन में ही धक्के खाने पड़ेंगे।',
        railwayAnalogy: 'ट्रेन के सिग्नल पर वीआईपी या एम्बुलेंस को सबसे पहले ग्रीन सिग्नल देना!'
      }
    }
  },
  {
    id: 'binarysearch',
    name: 'Binary Search (Bar Chart Method)',
    shortTag: 'O(log N) Divide & Conquer',
    timeComplexity: 'O(log N)',
    spaceComplexity: 'O(1)',
    railwayFeature: 'Fast Berth & PNR Interval Lookup via Divide & Conquer Bar Visualizer',
    translations: {
      en: {
        definition: 'Binary Search is an efficient Divide-and-Conquer algorithm that searches for a target value within a sorted array by repeatedly dividing the search interval in half.',
        whyUsed: 'RailFlow organizes millions of train records and seat numbers in sorted order. Instead of checking every single seat one by one, Binary Search cuts the search space in half at every comparison, finding any berth or ticket in just 3 to 5 comparisons!',
        whatHappensIfNotUsed: 'If we do NOT use Binary Search, we are forced to use Linear Search (checking from index 0 to N-1). On 10,000 train berths, Linear Search requires up to 10,000 steps; with Binary Search, it takes only 14 steps! Without it, search queries freeze and time out.',
        railwayAnalogy: 'Like a train ticket examiner looking for Seat 75 in a 100-seat coach: instead of checking Coach 1, 2, 3... they jump straight to the middle (Coach 50), see 75 is higher, and instantly ignore the entire first half of the train!'
      },
      ta: {
        definition: 'Binary Search என்பது வரிசைப்படுத்தப்பட்ட (Sorted) எண்களில், பாதியாக பிரித்து பிரித்து மிக வேகமாக (O(log N)) தேடும் முறை.',
        whyUsed: 'RailFlow-ல் லட்சக்கணக்கான சீட் எண்கள் மற்றும் PNR விபரங்கள் வரிசையாக இருக்கும். ஒவ்வொன்றாக தேடாமல், பாதியாக பிரித்து தேடுவதன் மூலம் 3-4 வினாடிகளில் சரியான சீட்டை கண்டுபிடிக்க முடிகிறது.',
        whatHappensIfNotUsed: 'நாம் Binary Search பயன்படுத்தாவிட்டால் என்ன ஆகும்? முதல் சீட்டிலிருந்து கடைசி சீட் வரை ஒவ்வொன்றாக தேட வேண்டும் (Linear Search). 10,000 சீட்டுகள் இருந்தால் 10,000 முறை பார்க்க வேண்டும்; Binary Search வெறும் 14 முறையிலேயே கண்டுபிடித்துவிடும்!',
        railwayAnalogy: 'ஒரு பெரிய அகராதியில் (Dictionary) ஒரு சொல்லை தேடுவது போன்றது: நடுப்பக்கத்தை பிரித்து, நமக்கு வேண்டிய சொல் எந்த பாதியில் இருக்கிறது என்று பார்த்து தேடுவது!'
      },
      hi: {
        definition: 'Binary Search एक बहुत तेज़ सर्च एल्गोरिदम है जो सॉर्टेड (क्रमबद्ध) सूची को बार-बार आधा करके O(log N) समय में सही मान ढूंढता है।',
        whyUsed: 'RailFlow में लाखों टिकट और सीट नंबर क्रम में होते हैं। एक-एक करके ढूंढने के बजाय, यह हर कदम पर आधी सूची को हटा देता है और कुछ ही पलों में परिणाम देता है।',
        whatHappensIfNotUsed: 'अगर हम Binary Search का उपयोग नहीं करेंगे, तो 10,000 सीटों की जांच के लिए 10,000 बार देखना पड़ेगा, जिससे सर्च बहुत धीमा हो जाएगा।',
        railwayAnalogy: 'जैसे 100 पन्नों की किताब में पेज 75 खोलना हो: आप सीधे बीच में (पेज 50) खोलते हैं और फिर आगे वाले हिस्से में देखते हैं!'
      }
    }
  },
  {
    id: 'sorting',
    name: 'Sorting Algorithms (Selection, Insertion, Bubble, Merge)',
    shortTag: 'Data Ordering Engine',
    timeComplexity: 'O(N²) to O(N log N)',
    spaceComplexity: 'O(1) to O(N)',
    railwayFeature: 'Sorting Passenger Queues by Age, Berth Number & Departure Times',
    translations: {
      en: {
        definition: 'Sorting algorithms rearrange an unordered collection of elements into ascending or descending sequence using comparison and repositioning techniques: Selection Sort, Insertion Sort, Bubble Sort, and Divide-and-Conquer Merge Sort.',
        whyUsed: 'RailFlow uses sorting to arrange passenger boarding lists by coach and berth number, prioritize senior citizens by age, and order daily trains by departure time. Furthermore, fast algorithms like Binary Search strictly REQUIRE the array to be sorted first!',
        whatHappensIfNotUsed: 'If data is unsorted, passengers board the train in complete disarray, jumping over coaches. Fast searching becomes impossible, and station departure display boards would show random chaotic train schedules.',
        railwayAnalogy: 'Organizing train coaches at the railway yard before departure: placing the locomotive at the head, followed by AC coaches in order (A1, A2, B1), and Sleeper coaches in numerical sequence.'
      },
      ta: {
        definition: 'Sorting என்பது கலைந்து கிடக்கும் எண்களையோ தகவல்களையோ ஏறுவரிசையில் சீராக அடுக்க உதவும் முறை: Selection Sort, Insertion Sort, Bubble Sort, மற்றும் Merge Sort.',
        whyUsed: 'ரயிலில் பெட்டிகளை வரிசைப்படுத்தவும், பயணிகளை சீட் எண் அல்லது வயது வாரியாக அடுக்கவும், ரயில் புறப்படும் நேரங்களை வரிசைப்படுத்தவும் Sorting பயன்படுகிறது.',
        whatHappensIfNotUsed: 'நாம் Sorting செய்யாவிட்டால், ரயில்கள் மற்றும் பயணிகளின் விபரங்கள் அலங்கோலமாக இருக்கும். வேகமான தேடல் (Binary Search) செய்ய முடியாது. டிஸ்ப்ளே போர்டில் நேரங்கள் குழப்பமாக தெரியும்!',
        railwayAnalogy: 'ரயில்வே யார்டில் பெட்டிகளை வரிசையாக இணைப்பது: என்ஜின் முதலில், பிறகு 1A, 2A, 3A, SL என வரிசையாக அடுக்கி வைப்பது!'
      },
      hi: {
        definition: 'Sorting एल्गोरिदम अव्यवस्थित डेटा को आरोही क्रम में व्यवस्थित करता है: Selection Sort, Insertion Sort, Bubble Sort, और Merge Sort।',
        whyUsed: 'यात्रियों को उनकी सीट संख्या, वरिष्ठ नागरिकों को उम्र के अनुसार, और ट्रेनों को समय के अनुसार सही क्रम में दिखाने के लिए Sorting आवश्यक है।',
        whatHappensIfNotUsed: 'अगर डेटा सॉर्टेड नहीं होगा, तो कोई भी यात्री सही डिब्बा नहीं ढूंढ पाएगा और बाइनरी सर्च जैसी तेज़ तकनीक काम नहीं कर पाएगी।',
        railwayAnalogy: 'ट्रेन के डिब्बों को सही क्रम में जोड़ना: पहले इंजन, फिर AC कोच, फिर स्लीपर कोच!'
      }
    }
  }
];

export const GAME_CHALLENGES: GameChallenge[] = [
  {
    id: 'ch_1',
    level: 1,
    levelTitle: {
      en: 'Level 1: The Full Train',
      ta: 'நிலை 1: முழு கொள்ளளவு கொண்ட ரயில்',
      hi: 'स्तर 1: पूरी तरह भरी ट्रेन'
    },
    scenario: {
      en: 'The Chennai to Bengaluru Vande Bharat Express has 0 seats left. 5 new passengers want to book tickets. In what order should they be placed to ensure fairness?',
      ta: 'சென்னை - பெங்களூரு வந்தே பாரத் ரயிலில் அனைத்து சீட்டுகளும் முடிந்துவிட்டன. 5 புதிய பயணிகள் காத்திருக்கிறார்கள். யாருக்கு எந்த வரிசையில் முன்னுரிமை தர வேண்டும்?',
      hi: 'चेन्नई से बेंगलुरु वंदे भारत की सभी सीटें भर चुकी हैं। 5 नए यात्री टिकट चाहते हैं। निष्पक्षता के लिए उन्हें किस क्रम में रखना चाहिए?'
    },
    question: {
      en: 'Which Data Structure guarantees First-In First-Out (FIFO) waiting list management?',
      ta: 'முதலில் வருபவருக்கு முதலில் முன்னுரிமை (FIFO) தரும் Data Structure எது?',
      hi: 'कौन सा डेटा स्ट्रक्चर पहले आओ पहले पाओ (FIFO) का पालन करता है?'
    },
    options: [
      {
        id: 'opt_queue',
        label: { en: 'Queue (FIFO)', ta: 'Queue (வரிசை அமைப்பு)', hi: 'Queue (FIFO कतार)' },
        isCorrect: true,
        explanation: {
          en: 'Correct! Queue enqueues passengers at the rear and dequeues them from the front when a seat is freed.',
          ta: 'சரி! Queue முதலில் வந்த பயணியை முன்னணியில் வைத்து நியாயமாக சீட் வழங்குகிறது.',
          hi: 'सही! Queue यह सुनिश्चित करता है कि जो पहले आया उसे पहले सीट मिले।'
        }
      },
      {
        id: 'opt_stack',
        label: { en: 'Stack (LIFO)', ta: 'Stack (அடுக்கு அமைப்பு)', hi: 'Stack (LIFO)' },
        isCorrect: false,
        explanation: {
          en: 'Incorrect. Stack is Last-In First-Out. The newest person would unfairly get the seat!',
          ta: 'தவறு. Stack பயன்படுத்தினால் கடைசியாக வந்தவருக்கு சீட் போய்விடும்!',
          hi: 'गलत। Stack से सबसे अंत में आए व्यक्ति को सीट मिल जाएगी जो अन्याय है।'
        }
      },
      {
        id: 'opt_graph',
        label: { en: 'Graph', ta: 'Graph (வரைபடம்)', hi: 'Graph' },
        isCorrect: false,
        explanation: {
          en: 'Incorrect. Graphs model station routes and tracks, not waiting lists.',
          ta: 'தவறு. Graph ரயில் பாதைகளை கணக்கிட மட்டுமே பயன்படும்.',
          hi: 'गलत। Graph रूट के लिए होता है, वेटिंग लिस्ट के लिए नहीं।'
        }
      }
    ],
    hint: {
      en: 'Think about physical line waiting: First In, First Out.',
      ta: 'கவுண்டர் வரிசையை நினைவில் கொள்ளுங்கள்: முதலில் வருபவர் முதலில்.',
      hi: 'टिकट खिड़की की लाइन याद करें: पहले आओ, पहले पाओ।'
    },
    dsaConcept: 'Queue (FIFO)',
    complexity: 'O(1) Enqueue'
  },
  {
    id: 'ch_2',
    level: 2,
    levelTitle: {
      en: 'Level 2: The Cancelled Seat',
      ta: 'நிலை 2: ரத்து செய்யப்பட்ட சீட்',
      hi: 'स्तर 2: रद्द हुई सीट'
    },
    scenario: {
      en: 'Passenger Anita in Seat 3A-12 cancels her journey. The waiting list has: WL1 (Ramesh), WL2 (Kavita), WL3 (John).',
      ta: 'அனிதா என்ற பயணி தனது சீட்டை ரத்து செய்கிறார். வெயிட்டிங் லிஸ்டில் WL1 (ரமேஷ்), WL2 (கவிதா), WL3 (ஜான்) உள்ளனர்.',
      hi: 'अनीता ने अपनी सीट 3A-12 रद्द कर दी। वेटिंग लिस्ट में हैं: WL1 (रमेश), WL2 (कविता), WL3 (जॉन)।'
    },
    question: {
      en: 'Which queue operation must be executed to promote the earliest waiting passenger to Confirmed?',
      ta: 'முதலாவதாக உள்ள ரமேஷை உறுதிப்படுத்தப்பட்ட சீட்டுக்கு மாற்ற எந்த Queue operation பயன்படும்?',
      hi: 'सबसे पहले प्रतीक्षा कर रहे रमेश को सीट देने के लिए कौन सा ऑपरेशन चलेगा?'
    },
    options: [
      {
        id: 'opt_dequeue',
        label: { en: 'dequeue()', ta: 'dequeue() செயல்பாடு', hi: 'dequeue()' },
        isCorrect: true,
        explanation: {
          en: 'Correct! dequeue() extracts the front element (WL1 - Ramesh) and assigns the newly vacated seat in O(1) time.',
          ta: 'சரி! dequeue() முனையிலிருந்து முதல் நபரை எடுத்து சீட்டை வழங்கும்.',
          hi: 'बिल्कुल सही! dequeue() पहले व्यक्ति (WL1) को निकालकर सीट आवंटित करता है।'
        }
      },
      {
        id: 'opt_enqueue',
        label: { en: 'enqueue()', ta: 'enqueue() செயல்பாடு', hi: 'enqueue()' },
        isCorrect: false,
        explanation: {
          en: 'Incorrect. enqueue() puts a new passenger at the end of the line.',
          ta: 'தவறு. enqueue() புதிய நபரை வரிசையின் கடைசியில் சேர்க்கும்.',
          hi: 'गलत। enqueue() तो नए व्यक्ति को पीछे जोड़ता है।'
        }
      },
      {
        id: 'opt_pop',
        label: { en: 'pop()', ta: 'pop()', hi: 'pop()' },
        isCorrect: false,
        explanation: {
          en: 'Incorrect. pop() belongs to Stack, not Queue.',
          ta: 'தவறு. pop என்பது Stack-ல் உள்ள முறை.',
          hi: 'गलत। pop() तो Stack का हिस्सा है।'
        }
      }
    ],
    hint: {
      en: 'Removing from the front of a Queue is called dequeue.',
      ta: 'வரிசையின் முன் பக்கத்திலிருந்து வெளியேற்றுவது dequeue.',
      hi: 'कतार से पहले व्यक्ति को निकालने को dequeue कहते हैं।'
    },
    dsaConcept: 'Queue Dequeue',
    complexity: 'O(1)'
  },
  {
    id: 'ch_3',
    level: 3,
    levelTitle: {
      en: 'Level 3: Instant PNR Lookup',
      ta: 'நிலை 3: நொடியில் PNR கண்டறிதல்',
      hi: 'स्तर 3: तुरंत PNR सर्च'
    },
    scenario: {
      en: 'A passenger at the station has 1 minute before departure and inputs their 10-digit PNR. 5 million bookings exist in database.',
      ta: 'ரயில் கிளம்ப 1 நிமிடம் இருக்கும்போது பயணி தனது 10-இலக்க PNR எண்ணை தேடுகிறார். டேட்டாபேஸில் 50 லட்சம் டிக்கெட்டுகள் உள்ளன.',
      hi: 'ट्रेन छूटने में 1 मिनट है और यात्री अपना 10-अंकीय PNR डालता है। डेटाबेस में 50 लाख टिकट हैं।'
    },
    question: {
      en: 'Which Data Structure retrieves the ticket in O(1) constant time without scanning all 5 million tickets?',
      ta: 'அனைத்து டிக்கெட்டுகளையும் தேடாமல், O(1) நேரத்தில் உடனடியாக டிக்கெட்டைக் கண்டுபிடிக்கும் அமைப்பு எது?',
      hi: 'कौन सा डेटा स्ट्रक्चर बिना 50 लाख टिकटों को खंगाले O(1) समय में तुरंत टिकट दिखाएगा?'
    },
    options: [
      {
        id: 'opt_hash',
        label: { en: 'Hash Map (Hash Table)', ta: 'Hash Map (ஹாஷ் டேபிள்)', hi: 'Hash Map (हैश मैप)' },
        isCorrect: true,
        explanation: {
          en: 'Correct! Hash Map hashes the 10-digit PNR directly to its storage bucket for instantaneous O(1) average lookup.',
          ta: 'சரி! Hash Map நேரடியாக அந்த PNR இருக்கும் பெட்டியை O(1) நேரத்தில் கண்டுபிடிக்கும்.',
          hi: 'बिल्कुल सही! Hash Map 10-अंकीय PNR को सीधे बकेट एड्रेस में बदलकर तुरंत खोज लेता है।'
        }
      },
      {
        id: 'opt_array',
        label: { en: 'Unsorted Array', ta: 'சாதாரண வரிசை (Array)', hi: 'अनसॉर्टेड ऐरे' },
        isCorrect: false,
        explanation: {
          en: 'Incorrect. Unsorted arrays require O(N) linear scan, checking 5 million items!',
          ta: 'தவறு. சாதாரண Array 50 லட்சம் முறையும் வரிசையாக தேட வேண்டும்.',
          hi: 'गलत। इसमें O(N) समय लगेगा और 50 लाख रिकॉर्ड जांचने पड़ेंगे।'
        }
      }
    ],
    hint: {
      en: 'Think of keys mapping directly to buckets in constant time.',
      ta: 'சாவி போட்டு உடனே திறக்கும் லாக்கரை நினைவில் கொள்ளுங்கள்.',
      hi: 'कुंजी से सीधे मेमोरी बकेट तक O(1) समय में पहुँचना।'
    },
    dsaConcept: 'Hash Map',
    complexity: 'O(1) Average'
  },
  {
    id: 'ch_4',
    level: 4,
    levelTitle: {
      en: 'Level 4: Shortest Route in Radium Green',
      ta: 'நிலை 4: ரேடியம் பச்சை வழிகாட்டல்',
      hi: 'स्तर 4: रेडियम ग्रीन रूट'
    },
    scenario: {
      en: 'RailFlow needs to find the route between New Delhi and Chennai with the minimum number of junction transfers.',
      ta: 'டெல்லி முதல் சென்னை வரை குறைவான ரயில் நிலைய நிறுத்தங்கள் கொண்ட பாதையை கண்டுபிடிக்க வேண்டும்.',
      hi: 'नई दिल्ली से चेन्नई के बीच न्यूनतम स्टॉप वाला रास्ता खोजना है।'
    },
    question: {
      en: 'Which algorithm explores layer-by-layer and is guaranteed to find the shortest hop path in a Graph?',
      ta: 'Graph-ல் மிகக் குறைந்த நிறுத்தங்கள் கொண்ட பாதையைக் கண்டுபிடிக்க எந்த வழிமுறை பயன்படுகிறது?',
      hi: 'Graph में सबसे कम स्टॉप वाला रास्ता खोजने के लिए कौन सा एल्गोरिदम उपयोग होता है?'
    },
    options: [
      {
        id: 'opt_bfs',
        label: { en: 'Breadth-First Search (BFS)', ta: 'BFS (அகல ஆய்வு முறை)', hi: 'BFS (ब्रेड्थ-फर्स्ट सर्च)' },
        isCorrect: true,
        explanation: {
          en: 'Correct! BFS searches station neighbors level by level, guaranteed to find the path with fewest edges (hops). Displayed in glowing Radium Green (#00FF66)!',
          ta: 'சரி! BFS ஒவ்வொரு நிலையமாக அருகிலுள்ள வழிகளை ஆராய்ந்து குறைந்த நிறுத்த பாதையை ரேடியம் பச்சையில் காட்டும்!',
          hi: 'सही! BFS स्तर-दर-स्तर खोज करता है और सबसे कम हॉप्स वाला रास्ता चमकते रेडियम ग्रीन में दिखाता है!'
        }
      },
      {
        id: 'opt_dfs',
        label: { en: 'Depth-First Search (DFS)', ta: 'DFS (ஆழ ஆய்வு முறை)', hi: 'DFS (डेप्थ-फर्स्ट सर्च)' },
        isCorrect: false,
        explanation: {
          en: 'Incorrect. DFS dives deep down one track branch and often finds long detour paths.',
          ta: 'தவறு. DFS ஒரே பாதையில் ஆழமாக சென்று நீண்ட சுத்து பாதையைக் கண்டுபிடிக்கும்.',
          hi: 'गलत। DFS एक ही दिशा में गहराई तक जाता है और लंबा चक्करदार रास्ता खोज सकता है।'
        }
      }
    ],
    hint: {
      en: 'Breadth-First explores neighboring stations first.',
      ta: 'அருகில் உள்ள அனைத்து நிலையங்களையும் முதலில் பார்க்கும் முறை.',
      hi: 'पहले नजदीकी पड़ोसियों की जांच करना।'
    },
    dsaConcept: 'Graph BFS',
    complexity: 'O(V + E)'
  },
  {
    id: 'ch_5',
    level: 5,
    levelTitle: {
      en: 'Level 5: Rollback Cancellation',
      ta: 'நிலை 5: கடைசி செயலை மீளப்பெறுதல்',
      hi: 'स्तर 5: रद्दीकरण और रोलबैक'
    },
    scenario: {
      en: 'A passenger made 3 actions: [1. Searched Train], [2. Added Passenger], [3. Clicked Cancel Ticket]. The auditor wants to inspect the most recent action first.',
      ta: 'பயணி 3 செயல்களை செய்தார். தணிக்கையாளர் கடைசியாக நடந்த செயலை உடனே பார்க்க வேண்டும்.',
      hi: 'यात्री ने 3 काम किए। ऑडिटर को सबसे अंत में हुआ काम सबसे पहले देखना है।'
    },
    question: {
      en: 'Which Data Structure follows LIFO (Last In First Out) for tracking action history?',
      ta: 'கடைசியாக செய்த செயலை முதலில் எடுக்க உதவும் LIFO அமைப்பு எது?',
      hi: 'LIFO (अंतिम इन, पहला आउट) का पालन करने वाला डेटा स्ट्रक्चर कौन सा है?'
    },
    options: [
      {
        id: 'opt_stack',
        label: { en: 'Stack (LIFO)', ta: 'Stack (LIFO)', hi: 'Stack (स्टैक)' },
        isCorrect: true,
        explanation: {
          en: 'Correct! A Stack stores actions such that pop() always retrieves the latest action (top of the stack).',
          ta: 'சரி! Stack-ல் கடைசியாக சேர்க்கப்பட்ட செயலே முதலில் எடுக்கப்படும்.',
          hi: 'सही! Stack में सबसे हालिया गतिविधि शीर्ष (top) पर होती है।'
        }
      },
      {
        id: 'opt_queue',
        label: { en: 'Queue (FIFO)', ta: 'Queue (FIFO)', hi: 'Queue' },
        isCorrect: false,
        explanation: {
          en: 'Incorrect. Queue would retrieve the oldest action (step 1), not the latest!',
          ta: 'தவறு. Queue மிகவும் பழமையான முதல் செயலை மட்டுமே தரும்.',
          hi: 'गलत। Queue सबसे पुराना काम पहले निकालता है।'
        }
      }
    ],
    hint: {
      en: 'Think of undo buttons or browser back buttons.',
      ta: 'கணினியில் Undo செய்வதை நினைவில் கொள்ளுங்கள்.',
      hi: 'ब्राउज़र के बैक बटन या Undo की तरह सोचें।'
    },
    dsaConcept: 'Stack (LIFO)',
    complexity: 'O(1) Pop'
  },
  {
    id: 'ch_6',
    level: 6,
    levelTitle: {
      en: 'Level 6: Railway Algorithm Master',
      ta: 'நிலை 6: ரயில்வே அல்காரிதம் மாஸ்டர்',
      hi: 'स्तर 6: रेलवे एल्गोरिदम मास्टर'
    },
    scenario: {
      en: 'System event: An emergency medical troop needs priority over normal waiting list passengers regardless of who joined first.',
      ta: 'அவசர ராணுவ மருத்துவ குழுவிற்கு சாதாரண வெயிட்டிங் லிஸ்ட்டை விட முன்னுரிமை கொடுத்து சீட் வழங்க வேண்டும்.',
      hi: 'आपातकालीन मेडिकल टीम को सामान्य वेटिंग लिस्ट से पहले प्राथमिकता देनी है।'
    },
    question: {
      en: 'Which Data Structure processes requests by assigned priority weight rather than arrival order?',
      ta: 'வந்த நேரத்தை விட முக்கியத்துவத்தை (Priority) வைத்து டிக்கெட் வழங்கும் அமைப்பு எது?',
      hi: 'कौन सा डेटा स्ट्रक्चर आगमन समय के बजाय प्राथमिकता के आधार पर काम करता है?'
    },
    options: [
      {
        id: 'opt_pq',
        label: { en: 'Priority Queue (Heap)', ta: 'Priority Queue (முன்னுரிமை வரிசை)', hi: 'Priority Queue (प्राथमिकता कतार)' },
        isCorrect: true,
        explanation: {
          en: 'Correct! A Priority Queue (Binary Heap) always extracts the highest priority element in O(log N) time.',
          ta: 'சரி! Priority Queue அவசர தேவைகளுக்கு முன்னுரிமை தந்து சீட் ஒதுக்கும்.',
          hi: 'बिल्कुल सही! Priority Queue हमेशा उच्च प्राथमिकता वाले काम को पहले करता है।'
        }
      },
      {
        id: 'opt_queue',
        label: { en: 'Simple FIFO Queue', ta: 'சாதாரண FIFO Queue', hi: 'सामान्य FIFO Queue' },
        isCorrect: false,
        explanation: {
          en: 'Incorrect. Standard Queue ignores priority and only looks at arrival order.',
          ta: 'தவறு. சாதாரண Queue முன்னுரிமையை கவனிக்காது.',
          hi: 'गलत। सामान्य Queue प्राथमिकता नहीं देखता।'
        }
      }
    ],
    hint: {
      en: 'Look for the structure designed explicitly for weighted priority.',
      ta: 'முன்னுரிமை (Priority) என்ற வார்த்தையை கவனியுங்கள்.',
      hi: 'प्राथमिकता (Priority) शब्द पर ध्यान दें।'
    },
    dsaConcept: 'Priority Queue (Heap)',
    complexity: 'O(log N)'
  }
];
