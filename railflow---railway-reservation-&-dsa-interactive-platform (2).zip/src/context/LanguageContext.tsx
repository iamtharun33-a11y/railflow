import React, { createContext, useContext, useState, useEffect } from 'react';
import { Language } from '../types';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const UI_TRANSLATIONS: Record<string, Record<Language, string>> = {
  // Navigation
  nav_home: { en: 'Home', ta: 'முகப்பு', hi: 'होम' },
  nav_trains: { en: 'Search Trains', ta: 'ரயில்கள்', hi: 'ट्रेन खोजें' },
  nav_tickets: { en: 'My Tickets', ta: 'என் டிக்கெட்டுகள்', hi: 'मेरे टिकट' },
  nav_pnr: { en: 'PNR Status & Hash', ta: 'PNR & ஹாஷ் மேப்', hi: 'PNR स्थिति और हैश' },
  nav_dsa_lab: { en: 'DSA Lab', ta: 'DSA ஆய்வகம்', hi: 'DSA लैब' },
  nav_dsa_game: { en: 'DSA Game', ta: 'DSA விளையாட்டு', hi: 'DSA गेम' },
  nav_simulation: { en: 'Simulation Sandbox', ta: 'மாதிரி அரங்கம்', hi: 'सिमुलेशन सैंडबॉक्स' },
  nav_presentation: { en: 'Presentation Deck', ta: 'விளக்க உரை', hi: 'प्रस्तुति डेक' },
  nav_ai_guide: { en: 'AI Mentor', ta: 'AI வழிகாட்டி', hi: 'AI गाइड' },
  nav_login: { en: 'Log In', ta: 'உள்நுழைய', hi: 'लॉग इन' },
  nav_register: { en: 'Register', ta: 'பதிவு செய்ய', hi: 'रजिस्टर करें' },
  nav_logout: { en: 'Logout', ta: 'வெளியேறு', hi: 'लॉग आउट' },
  nav_dashboard: { en: 'Dashboard', ta: 'டாஷ்போர்டு', hi: 'डैशबोर्ड' },

  // Hero & Taglines
  hero_title_1: { en: 'Reserve Your Journey.', ta: 'உங்கள் பயணத்தை பதிவு செய்யுங்கள்.', hi: 'अपनी यात्रा बुक करें।' },
  hero_title_2: { en: 'Understand the Algorithm.', ta: 'அதன் பின்னுள்ள அல்காரிதத்தை உணருங்கள்.', hi: 'एल्गोरिदम को समझें।' },
  hero_subtitle: {
    en: 'Experience a professional railway reservation system with real-time waiting lists, PNR hash lookups, and interactive Radium Green route graphs.',
    ta: 'உண்மையான ரயில்வே முன்பதிவு முறை, காத்திருப்பு பட்டியல் வரிசை, நேரடி PNR ஹாஷ் மேப் மற்றும் ரேடியம் பச்சை வழிகாட்டல் வரைபடத்துடன் கூடிய முழு தளம்.',
    hi: 'वास्तविक रेलवे आरक्षण, रीयल-टाइम वेटिंग लिस्ट, PNR हैश मैप और चमकदार रेडियम ग्रीन रूट मैप का अनूठा अनुभव।'
  },
  btn_search_trains: { en: 'Search Trains', ta: 'ரயில்களைத் தேடுங்கள்', hi: 'ट्रेनें खोजें' },
  btn_explore_dsa: { en: 'Explore DSA Lab', ta: 'DSA ஆய்வகத்தைப் பார்க்க', hi: 'DSA लैब देखें' },
  btn_play_game: { en: 'Play DSA Game', ta: 'விளையாடி பழகுங்கள்', hi: 'गेम खेलें' },

  // Features
  pnr_search_placeholder: { en: 'Enter 10-Digit PNR (e.g. 2847193821)...', ta: '10-இலக்க PNR எண்ணை உள்ளிடவும்...', hi: '10-अंकीय PNR दर्ज करें...' },
  btn_check_pnr: { en: 'Calculate Hash & Lookup PNR', ta: 'ஹாஷ் கணக்கிட்டு PNR காண்க', hi: 'हैश निकालें और PNR देखें' },
  empty_tickets_title: { en: 'No journeys yet', ta: 'பயணங்கள் எதுவும் இல்லை', hi: 'अभी कोई यात्रा नहीं है' },
  empty_tickets_desc: { en: 'Your journey dashboard is ready. Book your first real ticket to observe Queue and Hash Map operations.', ta: 'உங்கள் டேஷ்போர்டு தயார். Queue மற்றும் Hash Map செயல்பாடுகளைக் காண உங்கள் முதல் டிக்கெட்டைப் பதிவு செய்யுங்கள்.', hi: 'आपका डैशबोर्ड तैयार है। कतार और हैश मैप संचालन देखने के लिए अपनी पहली टिकट बुक करें।' },
  empty_achievements_title: { en: 'No achievements unlocked yet', ta: 'சாதனைகள் எதுவும் இன்னும் திறக்கப்படவில்லை', hi: 'अभी कोई उपलब्धि अनलॉक नहीं हुई है' },
  empty_achievements_desc: { en: 'Complete your first DSA challenge or ticket booking to earn badges and XP.', ta: 'பேட்ஜ்கள் மற்றும் XP பெற உங்கள் முதல் DSA சவாலைத் தொடங்குங்கள்.', hi: 'बैज और XP प्राप्त करने के लिए अपनी पहली चुनौती शुरू करें।' }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('railflow_lang');
    return (saved as Language) || 'en';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('railflow_lang', lang);
  };

  const t = (key: string): string => {
    const translation = UI_TRANSLATIONS[key];
    if (translation && translation[language]) {
      return translation[language];
    }
    return key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) throw new Error('useLanguage must be used within a LanguageProvider');
  return context;
};
