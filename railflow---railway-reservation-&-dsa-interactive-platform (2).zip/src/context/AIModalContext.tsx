import React, { createContext, useContext, useState } from 'react';

interface AIModalContextType {
  isOpen: boolean;
  openAI: (initialPrompt?: string, context?: string) => void;
  closeAI: () => void;
  activePrompt: string;
  activeContext: string;
}

const AIModalContext = createContext<AIModalContextType | undefined>(undefined);

export const AIModalProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [activePrompt, setActivePrompt] = useState('');
  const [activeContext, setActiveContext] = useState('');

  const openAI = (initialPrompt?: string, context?: string) => {
    if (initialPrompt) setActivePrompt(initialPrompt);
    if (context) setActiveContext(context);
    setIsOpen(true);
  };

  const closeAI = () => {
    setIsOpen(false);
  };

  return (
    <AIModalContext.Provider value={{ isOpen, openAI, closeAI, activePrompt, activeContext }}>
      {children}
    </AIModalContext.Provider>
  );
};

export const useAIModal = () => {
  const context = useContext(AIModalContext);
  if (!context) throw new Error('useAIModal must be used within an AIModalProvider');
  return context;
};
