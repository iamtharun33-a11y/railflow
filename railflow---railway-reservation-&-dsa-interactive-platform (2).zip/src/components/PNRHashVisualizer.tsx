import React, { useState, useEffect } from 'react';
import { HashLookupResult, Booking } from '../types';
import { Search, Database, ArrowRight, ShieldCheck, Cpu, AlertCircle, CheckCircle } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface PNRHashVisualizerProps {
  initialPnr?: string;
  onBookingFound?: (booking: Booking | null) => void;
}

export const PNRHashVisualizer: React.FC<PNRHashVisualizerProps> = ({ initialPnr = '', onBookingFound }) => {
  const { language } = useLanguage();
  const [pnrInput, setPnrInput] = useState<string>(initialPnr);
  const [lookupResult, setLookupResult] = useState<HashLookupResult | null>(null);
  const [loading, setLoading] = useState(false);

  // Real-time calculation of polynomial hash
  const calculateLiveHash = (val: string) => {
    const clean = val.trim();
    if (!clean) return { hashVal: 0, bucketIdx: 0, formula: 'h(key) = 0 % 16 = 0' };
    const PRIME = 31;
    let hash = 0;
    for (let i = 0; i < clean.length; i++) {
      hash = (hash * PRIME + clean.charCodeAt(i)) % 1000000007;
    }
    const bucket = Math.abs(hash) % 16;
    return {
      hashVal: Math.abs(hash),
      bucketIdx: bucket,
      formula: `h("${clean}") = (\\sum ASCII \\times 31) \\bmod 16 = Bucket #${bucket}`
    };
  };

  const liveHash = calculateLiveHash(pnrInput);

  const fetchPNRDetails = async (pnrToQuery: string) => {
    if (!pnrToQuery.trim()) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/bookings/pnr/${encodeURIComponent(pnrToQuery.trim())}`);
      const data: HashLookupResult = await res.json();
      setLookupResult(data);
      if (onBookingFound) {
        onBookingFound(data.booking);
      }
    } catch (err) {
      console.error('PNR lookup failed', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (initialPnr) {
      setPnrInput(initialPnr);
      fetchPNRDetails(initialPnr);
    }
  }, [initialPnr]);

  return (
    <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 text-slate-800 shadow-xs relative overflow-hidden">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-100 pb-5 mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200 uppercase tracking-wider">
              Connected Hash Map Engine
            </span>
            <span className="text-xs text-emerald-700 font-mono font-bold">Average O(1) Time</span>
          </div>
          <h3 className="text-2xl font-bold text-slate-900 tracking-tight">
            PNR Status & Real-Time Hash Lookup
          </h3>
          <p className="text-sm text-slate-500">
            {language === 'ta'
              ? 'உங்கள் PNR எண்களை உள்ளிடும்போது, அது எவ்வாறு Hash Table Bucket-ஐக் கணக்கிட்டு டிக்கெட்டை எடுக்கிறது என்பதை நேரடியாகப் பாருங்கள்.'
              : language === 'hi'
              ? 'जैसे ही आप PNR नंबर टाइप करते हैं, देखें कि यह हैश फ़ंक्शन से सीधे बकेट एड्रेस निकालकर O(1) में डेटा कैसे लाता है।'
              : 'As you enter PNR digits, watch the mathematical hash function calculate the exact memory bucket index in real time.'}
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs text-slate-600 font-semibold">
          <Cpu className="w-4 h-4 text-blue-600" />
          <span>Table Size: 16 Buckets</span>
        </div>
      </div>

      {/* Input Field with Live Digit Tracking */}
      <div className="mb-6">
        <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">
          {language === 'ta' ? '10-இலக்க PNR எண்ணை உள்ளிடவும்' : language === 'hi' ? '10-अंकीय PNR नंबर दर्ज करें' : 'Enter 10-Digit PNR Number'}
        </label>
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <input
              type="text"
              value={pnrInput}
              onChange={(e) => {
                const val = e.target.value.replace(/\D/g, '').slice(0, 10);
                setPnrInput(val);
                if (val.length === 10) {
                  fetchPNRDetails(val);
                }
              }}
              placeholder="e.g. 2847193821 (or enter your PNR)"
              className="w-full bg-slate-50 border-2 border-slate-200 focus:border-blue-500 rounded-2xl px-4 py-3.5 text-lg font-mono text-slate-800 placeholder-slate-400 focus:outline-none shadow-2xs font-semibold"
            />
            {pnrInput && (
              <span className="absolute right-3.5 top-3.5 px-2 py-0.5 rounded text-xs font-mono font-bold bg-blue-100 text-blue-800">
                {pnrInput.length}/10 digits
              </span>
            )}
          </div>

          <button
            onClick={() => fetchPNRDetails(pnrInput)}
            disabled={loading || !pnrInput}
            className="flex items-center justify-center gap-2 px-6 py-3.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-400 text-white font-bold rounded-2xl transition-all shadow-sm shadow-blue-600/30 text-sm"
          >
            <Search className="w-4 h-4" />
            <span>{language === 'ta' ? 'ஹாஷ் கணக்கிடு' : language === 'hi' ? 'हैश निकालें' : 'Compute & Lookup'}</span>
          </button>
        </div>
      </div>

      {/* Real-time Hash Formula & Computed Bucket Bar */}
      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 mb-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 text-sm">
          <div>
            <span className="text-xs uppercase font-bold text-slate-500 block mb-0.5">
              Live Input Hash Function:
            </span>
            <div className="font-mono text-blue-700 font-bold text-sm">
              h(k) = (Σ ASCII[i] × 31ⁿ⁻ⁱ) mod 16
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-white border border-slate-200 rounded-xl px-3.5 py-1.5 text-center shadow-2xs">
              <span className="text-[11px] text-slate-500 font-medium block">Polynomial Hash</span>
              <span className="font-mono text-xs text-amber-600 font-bold">{liveHash.hashVal}</span>
            </div>
            <div className="bg-blue-600 text-white rounded-xl px-4 py-1.5 text-center shadow-sm shadow-blue-600/30">
              <span className="text-[10px] text-blue-100 uppercase font-bold block">Target Bucket</span>
              <span className="font-mono text-base font-extrabold">
                Bucket #{liveHash.bucketIdx}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 16-Bucket Hash Table Grid */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
            Hash Table Buckets (Indices 0 - 15)
          </span>
          <span className="text-xs text-slate-500 font-medium">
            Active slot: <strong className="text-blue-700">Bucket #{liveHash.bucketIdx}</strong>
          </span>
        </div>

        <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
          {Array.from({ length: 16 }).map((_, idx) => {
            const isTarget = idx === liveHash.bucketIdx;
            const hasBooking = lookupResult?.hashDetails?.bucketIndex === idx && lookupResult?.booking;

            return (
              <div
                key={idx}
                className={`p-2.5 rounded-xl border text-center transition-all ${
                  isTarget
                    ? 'bg-blue-50 border-blue-500 text-blue-900 shadow-xs ring-2 ring-blue-500/20 scale-105'
                    : 'bg-slate-50 border-slate-200 text-slate-600'
                }`}
              >
                <div className="text-[11px] font-mono text-slate-400 font-bold mb-0.5">#{idx}</div>
                <div
                  className={`text-xs font-bold font-mono ${
                    isTarget ? 'text-blue-700' : 'text-slate-400'
                  }`}
                >
                  {isTarget ? 'TARGET' : 'Slot'}
                </div>
                {hasBooking && (
                  <div className="mt-1 w-2 h-2 rounded-full bg-emerald-500 mx-auto" />
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Lookup Status & Booking Details Result Box */}
      {lookupResult && (
        <div
          className={`rounded-2xl border p-5 transition-all ${
            lookupResult.booking
              ? 'bg-emerald-50/70 border-emerald-400 shadow-xs'
              : 'bg-slate-50 border-slate-200'
          }`}
        >
          <div className="flex items-center justify-between border-b border-slate-200/80 pb-3 mb-4">
            <div className="flex items-center gap-2">
              {lookupResult.booking ? (
                <CheckCircle className="w-5 h-5 text-emerald-600" />
              ) : (
                <AlertCircle className="w-5 h-5 text-amber-500" />
              )}
              <h4 className="text-base font-bold text-slate-900">
                {lookupResult.booking ? 'Ticket Found in Hash Table!' : 'PNR Not Found in Database'}
              </h4>
            </div>

            <span className="text-xs font-mono text-slate-500 font-semibold">
              Probes: <strong className="text-slate-800">{lookupResult.hashDetails.chainDepth}</strong> (O(1))
            </span>
          </div>

          {lookupResult.booking ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div className="space-y-2">
                <div>
                  <span className="text-xs text-slate-500 font-medium block">Train Name & Number</span>
                  <span className="font-bold text-slate-900 text-base">
                    {lookupResult.booking.trainName} ({lookupResult.booking.trainNumber})
                  </span>
                </div>
                <div>
                  <span className="text-xs text-slate-500 font-medium block">Route & Date</span>
                  <span className="text-slate-700 font-medium">
                    {lookupResult.booking.fromStationCode} → {lookupResult.booking.toStationCode} | {lookupResult.booking.journeyDate}
                  </span>
                </div>
                <div>
                  <span className="text-xs text-slate-500 font-medium block">Class</span>
                  <span className="text-blue-700 font-bold">{lookupResult.booking.travelClass}</span>
                </div>
              </div>

              <div className="space-y-2 bg-white rounded-xl p-3 border border-emerald-200 shadow-2xs">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-500 font-medium">Status:</span>
                  <span
                    className={`px-2 py-0.5 rounded text-xs font-bold ${
                      lookupResult.booking.status === 'CONFIRMED'
                        ? 'bg-emerald-100 text-emerald-800'
                        : lookupResult.booking.status === 'WAITING'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {lookupResult.booking.status}
                    {lookupResult.booking.waitingNumber ? ` (WL${lookupResult.booking.waitingNumber})` : ''}
                  </span>
                </div>

                <div>
                  <span className="text-xs text-slate-500 font-medium block mb-1">Passenger(s):</span>
                  {lookupResult.booking.passengers.map((p, i) => (
                    <div key={i} className="text-xs text-slate-700 flex justify-between font-medium">
                      <span>{p.name} ({p.gender}, {p.age})</span>
                      <strong className="text-emerald-700">{p.allocatedSeat || 'Pending'}</strong>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="text-sm text-slate-600">
              <p className="mb-1 font-medium">
                The PNR key <code className="text-blue-700 font-mono font-bold">{lookupResult.hashDetails.pnr}</code> mapped to <strong>Bucket #{lookupResult.hashDetails.bucketIndex}</strong>, but no ticket is stored at this key.
              </p>
              <p className="text-xs text-slate-500">
                Book a train to create a real PNR or test with an active booking!
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
