import React, { useState, useEffect } from 'react';
import { Station, GraphTraversalResponse } from '../types';
import { Compass, Play, RotateCcw, Zap, Sparkles, Navigation, Layers, CheckCircle2, ArrowRight } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface RadiumGraphVisualizerProps {
  onRouteSelected?: (startCode: string, endCode: string) => void;
}

export const RadiumGraphVisualizer: React.FC<RadiumGraphVisualizerProps> = ({ onRouteSelected }) => {
  const { language } = useLanguage();
  const [stations, setStations] = useState<Station[]>([]);
  const [startStationId, setStartStationId] = useState<string>('st_ndls');
  const [targetStationId, setTargetStationId] = useState<string>('st_mas');
  const [algorithm, setAlgorithm] = useState<'bfs' | 'dfs'>('bfs');
  const [traversalData, setTraversalData] = useState<GraphTraversalResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);

  // Pre-configured railway tracks (Edges)
  const trackEdges = [
    { from: 'st_ndls', to: 'st_adi', km: 930 },
    { from: 'st_adi', to: 'st_bct', km: 490 },
    { from: 'st_ndls', to: 'st_bct', km: 1380 },
    { from: 'st_ndls', to: 'st_pnbe', km: 1000 },
    { from: 'st_pnbe', to: 'st_hwh', km: 530 },
    { from: 'st_ndls', to: 'st_sc', km: 1660 },
    { from: 'st_sc', to: 'st_mas', km: 700 },
    { from: 'st_sc', to: 'st_sbc', km: 620 },
    { from: 'st_mas', to: 'st_sbc', km: 360 },
    { from: 'st_hwh', to: 'st_sc', km: 1540 },
    { from: 'st_hwh', to: 'st_sbc', km: 1950 },
    { from: 'st_mas', to: 'st_cbe', km: 500 },
    { from: 'st_cbe', to: 'st_mdu', km: 220 },
    { from: 'st_mas', to: 'st_mdu', km: 490 }
  ];

  useEffect(() => {
    fetch('/api/stations')
      .then((res) => res.json())
      .then((data) => {
        if (data.stations) {
          setStations(data.stations);
        }
      })
      .catch((err) => console.error(err));
  }, []);

  const runTraversal = async (algo = algorithm, start = startStationId, target = targetStationId) => {
    setLoading(true);
    setHasSearched(true);
    try {
      const res = await fetch('/api/graph/traverse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          algorithm: algo,
          fromStationId: start,
          toStationId: target
        })
      });
      const data: GraphTraversalResponse = await res.json();
      setTraversalData(data);

      if (onRouteSelected) {
        const s1 = stations.find((s) => s.id === start);
        const s2 = stations.find((s) => s.id === target);
        if (s1 && s2) {
          onRouteSelected(s1.code, s2.code);
        }
      }
    } catch (e) {
      console.error('Traversal failed', e);
    } finally {
      setLoading(false);
    }
  };

  const pathStationIds = new Set(hasSearched && traversalData?.path ? traversalData.path : []);

  const isEdgeInPath = (u: string, v: string) => {
    if (!hasSearched || !traversalData?.path) return false;
    const p = traversalData.path;
    for (let i = 0; i < p.length - 1; i++) {
      if ((p[i] === u && p[i + 1] === v) || (p[i] === v && p[i + 1] === u)) {
        return true;
      }
    }
    return false;
  };

  const getStationPos = (id: string) => {
    const st = stations.find((s) => s.id === id);
    if (!st) return { x: 50, y: 50 };
    return { x: st.x, y: st.y };
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 text-slate-800 shadow-sm overflow-hidden">
      {/* Header */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 border-b border-slate-100 pb-5 mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200 uppercase tracking-wider">
              <Navigation className="w-3.5 h-3.5 text-blue-600" />
              Railway Network Topology
            </span>
            <span className="text-xs text-slate-500 font-mono">Graph: O(V + E)</span>
          </div>
          <h3 className="text-2xl font-bold text-slate-900 tracking-tight">
            Station Network & Easy Route Finder
          </h3>
          <p className="text-sm text-slate-500 mt-0.5">
            {language === 'ta'
              ? 'சாதாரண வரைபடத்தில் தேடுங்கள்; Search அழுத்தியதும் எளிய பாதை மட்டும் பச்சை நிறத்தில் ஒளிரும்!'
              : language === 'hi'
              ? 'साधारण रूट मैप; Search पर क्लिक करने पर सबसे आसान रास्ता हरे रंग में चमकेगा!'
              : 'Clean railway network. Click Search to highlight only the optimal easy route in vibrant green!'}
          </p>
        </div>

        {/* Algorithm mode switcher */}
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-slate-100 border border-slate-200 rounded-xl p-1 text-xs">
            <button
              onClick={() => {
                setAlgorithm('bfs');
                if (hasSearched) runTraversal('bfs');
              }}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                algorithm === 'bfs'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              BFS (Fewest Hops)
            </button>
            <button
              onClick={() => {
                setAlgorithm('dfs');
                if (hasSearched) runTraversal('dfs');
              }}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                algorithm === 'dfs'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              DFS (Deep Explore)
            </button>
          </div>
        </div>
      </div>

      {/* Selectors Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 bg-slate-50 border border-slate-200 rounded-2xl p-4 mb-6">
        <div className="sm:col-span-5">
          <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">
            Source Station (Vertex U)
          </label>
          <select
            value={startStationId}
            onChange={(e) => setStartStationId(e.target.value)}
            className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2.5 text-sm text-slate-800 focus:outline-none focus:border-blue-500 shadow-2xs font-medium"
          >
            {stations.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name} ({s.code}) - {s.state}
              </option>
            ))}
          </select>
        </div>

        <div className="sm:col-span-5">
          <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">
            Destination Station (Vertex V)
          </label>
          <select
            value={targetStationId}
            onChange={(e) => setTargetStationId(e.target.value)}
            className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2.5 text-sm text-slate-800 focus:outline-none focus:border-blue-500 shadow-2xs font-medium"
          >
            {stations.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name} ({s.code}) - {s.state}
              </option>
            ))}
          </select>
        </div>

        <div className="sm:col-span-2 flex items-end">
          <button
            onClick={() => runTraversal()}
            disabled={loading}
            className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white font-bold rounded-xl text-sm transition-all shadow-sm shadow-blue-600/30 flex items-center justify-center gap-1.5"
          >
            {loading ? <RotateCcw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4 fill-current" />}
            <span>Find Route</span>
          </button>
        </div>
      </div>

      {/* Normal Clean SVG Railway Topology Map */}
      <div className="relative w-full h-80 sm:h-96 bg-slate-50/80 rounded-2xl border border-slate-200 overflow-hidden mb-6 flex items-center justify-center">
        {/* Subtle grid pattern */}
        <div
          className="absolute inset-0 opacity-40"
          style={{
            backgroundImage:
              'linear-gradient(to right, #E2E8F0 1px, transparent 1px), linear-gradient(to bottom, #E2E8F0 1px, transparent 1px)',
            backgroundSize: '28px 28px'
          }}
        />

        <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          {/* Railway Tracks (Normal gray by default; vibrant green ONLY when in optimal path) */}
          {trackEdges.map((edge, idx) => {
            const p1 = getStationPos(edge.from);
            const p2 = getStationPos(edge.to);
            const isInPath = isEdgeInPath(edge.from, edge.to);

            return (
              <g key={`edge-${idx}`}>
                {/* Normal track */}
                <line
                  x1={p1.x}
                  y1={p1.y}
                  x2={p2.x}
                  y2={p2.y}
                  stroke={isInPath ? '#16A34A' : '#CBD5E1'}
                  strokeWidth={isInPath ? 2.2 : 1}
                  strokeDasharray={isInPath ? 'none' : '2,2'}
                />

                {/* Vibrant green glow for optimal route path */}
                {isInPath && (
                  <line
                    x1={p1.x}
                    y1={p1.y}
                    x2={p2.x}
                    y2={p2.y}
                    stroke="#22C55E"
                    strokeWidth={2.8}
                    strokeLinecap="round"
                    className="drop-shadow-[0_0_8px_#22C55E]"
                  />
                )}
              </g>
            );
          })}

          {/* Station Vertices */}
          {stations.map((station) => {
            const isStart = station.id === startStationId;
            const isTarget = station.id === targetStationId;
            const isInPath = pathStationIds.has(station.id);

            let fillColor = '#FFFFFF';
            let strokeColor = '#64748B';
            let radius = 2.4;

            if (isInPath) {
              fillColor = '#16A34A';
              strokeColor = '#15803D';
              radius = 3.6;
            } else if (isStart || isTarget) {
              fillColor = '#2563EB';
              strokeColor = '#1D4ED8';
              radius = 3.2;
            }

            return (
              <g
                key={station.id}
                className="cursor-pointer transition-transform hover:scale-125"
                onClick={() => {
                  if (startStationId !== station.id) {
                    setTargetStationId(station.id);
                  }
                }}
              >
                {/* Green pulse ring if on optimal route */}
                {isInPath && (
                  <circle
                    cx={station.x}
                    cy={station.y}
                    r={radius + 3}
                    fill="none"
                    stroke="#22C55E"
                    strokeWidth="0.8"
                    opacity="0.6"
                    className="animate-ping"
                  />
                )}

                <circle
                  cx={station.x}
                  cy={station.y}
                  r={radius}
                  fill={fillColor}
                  stroke={strokeColor}
                  strokeWidth="1.2"
                  className={isInPath ? 'drop-shadow-[0_0_6px_#22C55E]' : 'drop-shadow-xs'}
                />

                {/* Station Code Label */}
                <text
                  x={station.x}
                  y={station.y - 4}
                  textAnchor="middle"
                  fill={isInPath ? '#15803D' : '#334155'}
                  fontSize="3.2"
                  fontWeight={isInPath ? 'bold' : '600'}
                >
                  {station.code}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Normal clean map legend */}
        <div className="absolute bottom-3 left-3 bg-white/90 backdrop-blur-xs border border-slate-200 rounded-xl p-2.5 text-xs flex flex-wrap gap-3 items-center shadow-xs">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-emerald-600" />
            <span className="text-slate-700 font-semibold">Easy Green Route</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-blue-600" />
            <span className="text-slate-600">Selected Station</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-slate-300 border border-slate-400" />
            <span className="text-slate-500">Normal Vertex</span>
          </div>
        </div>
      </div>

      {/* Optimal Green Route Display Card (Shown once user searches) */}
      {hasSearched && traversalData && (
        <div className="bg-emerald-50 border-2 border-emerald-500 rounded-2xl p-5 shadow-xs transition-all animate-in fade-in">
          <div className="flex items-center justify-between gap-3 border-b border-emerald-200 pb-3 mb-4">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-emerald-600 text-white shadow-xs">
                <CheckCircle2 className="w-5 h-5" />
              </span>
              <div>
                <span className="text-[11px] font-mono uppercase tracking-wider text-emerald-800 font-bold">
                  OPTIMAL ROUTE FOUND
                </span>
                <h4 className="text-lg font-bold text-emerald-950">
                  Easy Route: {traversalData.pathStations[0]?.name} → {traversalData.pathStations[traversalData.pathStations.length - 1]?.name}
                </h4>
              </div>
            </div>

            <div className="text-right">
              <span className="text-xs text-emerald-700 font-medium block">Fewest Transfers</span>
              <span className="text-xl font-bold text-emerald-800 font-mono">
                {traversalData.pathStations.length} Stations ({traversalData.pathStations.length - 1} Hops)
              </span>
            </div>
          </div>

          {/* Green Station Sequence Badges */}
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 block mb-2">
              Optimal Station Route Path:
            </span>
            <div className="flex flex-wrap items-center gap-2">
              {traversalData.pathStations.map((st, i) => (
                <React.Fragment key={st.id}>
                  <div className="flex items-center gap-1.5 bg-white border border-emerald-300 rounded-xl px-3.5 py-2 shadow-xs">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                    <span className="font-bold text-slate-800 text-sm">{st.name}</span>
                    <span className="text-xs font-mono text-emerald-700 font-bold">({st.code})</span>
                  </div>
                  {i < traversalData.pathStations.length - 1 && (
                    <ArrowRight className="w-4 h-4 text-emerald-600 shrink-0" />
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
