import React, { useState, useEffect, useRef } from 'react';
import { useAIModal } from '../context/AIModalContext';
import { useLanguage } from '../context/LanguageContext';
import { Bot, X, Send, Sparkles, User, ListFilter, Hash, Route } from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

export const AIGuideDrawer: React.FC = () => {
  const { isOpen, closeAI, activePrompt, activeContext } = useAIModal();
  const { language } = useLanguage();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initialize welcome message
  useEffect(() => {
    const welcomeText =
      language === 'ta'
        ? 'வணக்கம்! நான் உங்கள் RailFlow AI வழிகாட்டி. ரயில் முன்பதிவு, காத்திருப்பு பட்டியல் Queue, PNR Hash Map மற்றும் வழிகாட்டல் வரைபடம் பற்றி உங்களுக்கு எதில் உதவி வேண்டும்?'
        : language === 'hi'
        ? 'नमस्ते! मैं आपका RailFlow AI मेंटर हूँ। रेलवे आरक्षण प्रणाली, वेटिंग लिस्ट Queue, PNR Hash Map और रूट मैप के बारे में कोई भी प्रश्न पूछें!'
        : 'Hello! I am your RailFlow AI Guide. Ask me anything about how this website works, how to book tickets, PNR Hash Map, waiting list Queues, or route graphs!';

    setMessages([
      {
        id: 'msg_welcome',
        sender: 'assistant',
        text: welcomeText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  }, [language]);

  // Handle triggered prompts from other components
  useEffect(() => {
    if (activePrompt && isOpen) {
      sendMessage(activePrompt, activeContext);
    }
  }, [activePrompt, isOpen]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const sendMessage = async (promptToSend: string, context?: string) => {
    if (!promptToSend.trim() || loading) return;

    const userMsg: ChatMessage = {
      id: 'msg_' + Date.now(),
      sender: 'user',
      text: promptToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/ai/guide', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: promptToSend,
          language,
          context: context || activeContext
        })
      });

      const data = await res.json();
      const aiReply = data.reply || 'I am ready to help you explore railway algorithms!';

      const assistantMsg: ChatMessage = {
        id: 'msg_' + (Date.now() + 1),
        sender: 'assistant',
        text: aiReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: 'msg_err_' + Date.now(),
          sender: 'assistant',
          text: 'Sorry, I encountered a temporary connection issue. Please try again.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const samplePrompts = [
    {
      icon: ListFilter,
      label: language === 'ta' ? 'வெயிட்டிங் லிஸ்ட் Queue எப்படி இயங்குகிறது?' : language === 'hi' ? 'वेटिंग लिस्ट Queue कैसे काम करती है?' : 'How does Waiting List Queue work?',
      prompt: 'Explain how RailFlow uses a FIFO Queue to manage waiting list promotion when a ticket is cancelled.'
    },
    {
      icon: Hash,
      label: language === 'ta' ? 'PNR Hash Map ஏன் O(1) நேரம் எடுக்கிறது?' : language === 'hi' ? 'PNR Hash Map O(1) समय क्यों लेता है?' : 'Why is PNR lookup O(1) in Hash Map?',
      prompt: 'How does RailFlow calculate the polynomial hash for 10-digit PNR and why is it O(1) time?'
    },
    {
      icon: Route,
      label: language === 'ta' ? 'எளிய ரயில் பாதையை எப்படி கண்டுபிடிப்பது?' : language === 'hi' ? 'आसान रूट कैसे खोजें?' : 'How does BFS find optimal route in green?',
      prompt: 'How does BFS find the optimal route in green with fewest station hops in RailFlow?'
    }
  ];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/40 backdrop-blur-2xs transition-opacity">
      <div className="w-full sm:w-[480px] h-full bg-white border-l border-slate-200 flex flex-col shadow-2xl animate-in slide-in-from-right duration-300">
        {/* Drawer Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-sm shadow-blue-600/30">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-bold text-slate-900 text-base">RailFlow AI Guide</h3>
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              </div>
              <span className="text-xs text-blue-700 font-mono font-medium">Gemini 3.8 Flash Engine</span>
            </div>
          </div>

          <button
            onClick={closeAI}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-800 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Preset Prompt Chips */}
        <div className="p-3 bg-slate-50/70 border-b border-slate-100 flex gap-2 overflow-x-auto no-scrollbar">
          {samplePrompts.map((p, i) => (
            <button
              key={i}
              onClick={() => sendMessage(p.prompt)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white hover:bg-blue-50 hover:border-blue-300 border border-slate-200 text-xs text-slate-700 whitespace-nowrap transition-all shadow-2xs font-medium"
            >
              <p.icon className="w-3.5 h-3.5 text-blue-600" />
              <span>{p.label}</span>
            </button>
          ))}
        </div>

        {/* Messages Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-[#F8FAFC]">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.sender === 'assistant' && (
                <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-blue-600 text-white font-medium rounded-tr-none shadow-xs'
                    : 'bg-white text-slate-800 rounded-tl-none border border-slate-200 shadow-2xs font-normal'
                }`}
              >
                <div className="whitespace-pre-line">{msg.text}</div>
                <div
                  className={`text-[10px] mt-1.5 text-right font-mono ${
                    msg.sender === 'user' ? 'text-blue-100' : 'text-slate-400'
                  }`}
                >
                  {msg.timestamp}
                </div>
              </div>

              {msg.sender === 'user' && (
                <div className="w-8 h-8 rounded-lg bg-slate-200 text-slate-700 flex items-center justify-center shrink-0 mt-0.5">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex gap-3 items-center text-sm text-slate-500 pl-2">
              <Bot className="w-5 h-5 text-blue-600 animate-spin" />
              <span>Thinking with Gemini 3.8 Flash...</span>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Footer */}
        <div className="p-4 border-t border-slate-200 bg-white">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              sendMessage(input);
            }}
            className="flex gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={
                language === 'ta'
                  ? 'கேள்விகளை கேளுங்கள் (e.g. Queue vs Stack)...'
                  : language === 'hi'
                  ? 'सवाल पूछें (e.g. PNR Hash Map)...'
                  : 'Ask about Railway algorithms, Queues, Graphs...'
              }
              className="flex-1 bg-slate-50 border border-slate-200 focus:border-blue-600 rounded-xl px-4 py-2.5 text-sm text-slate-800 placeholder-slate-400 focus:outline-none"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="p-2.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 text-white rounded-xl transition-all shadow-xs"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
