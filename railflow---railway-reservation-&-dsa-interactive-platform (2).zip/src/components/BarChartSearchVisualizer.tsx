import React, { useState, useEffect, useRef } from 'react';
import { Search, Play, Pause, RotateCcw, ChevronRight, CheckCircle2, XCircle, ArrowRight, Zap, Info, Plus, Trash2 } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export const BarChartSearchVisualizer: React.FC = () => {
  const { language } = useLanguage();

  // Array values & search target
  const [arrayInput, setArrayInput] = useState<string>('15, 28, 35, 42, 56, 68, 79, 91, 105');
  const [targetInput, setTargetInput] = useState<number>(68);
  const [array, setArray] = useState<number[]>([15, 28, 35, 42, 56, 68, 79, 91, 105]);
  const [searchMethod, setSearchMethod] = useState<'binary' | 'linear'>('binary');
  const [singleValInput, setSingleValInput] = useState<string>('');

  // Binary search pointer states
  const [low, setLow] = useState<number | null>(null);
  const [high, setHigh] = useState<number | null>(null);
  const [mid, setMid] = useState<number | null>(null);
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [steps, setSteps] = useState<Array<{
    low: number;
    high: number;
    mid: number;
    midVal: number;
    status: 'less' | 'greater' | 'found' | 'not_found';
    description: string;
  }>>([]);

  // Linear search states
  const [linearIndex, setLinearIndex] = useState<number | null>(null);
  const [linearSteps, setLinearSteps] = useState<Array<{
    index: number;
    val: number;
    status: 'match' | 'no_match';
    description: string;
  }>>([]);

  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [speedMs, setSpeedMs] = useState<number>(850);
  const [searchResult, setSearchResult] = useState<{
    found: boolean;
    index: number;
    totalProbes: number;
    message: string;
  } | null>(null);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Parse user input into sorted array
  const handleUpdateArray = () => {
    const parsed = arrayInput
      .split(',')
      .map((s) => parseInt(s.trim(), 10))
      .filter((n) => !isNaN(n));

    if (parsed.length === 0) return;

    // For binary search, must be sorted
    const sorted = [...parsed].sort((a, b) => a - b);
    setArray(sorted);
    setArrayInput(sorted.join(', '));
    resetSearch(sorted);
  };

  const handleAddSingleNumber = () => {
    const val = parseInt(singleValInput.trim(), 10);
    if (isNaN(val)) return;
    const sorted = [...array, val].sort((a, b) => a - b);
    setArray(sorted);
    setArrayInput(sorted.join(', '));
    setSingleValInput('');
    resetSearch(sorted);
  };

  const handleDeleteSingleNumber = (indexToDelete: number) => {
    if (array.length <= 1) return;
    const filtered = array.filter((_, idx) => idx !== indexToDelete);
    setArray(filtered);
    setArrayInput(filtered.join(', '));
    resetSearch(filtered);
  };

  const resetSearch = (currentArr = array) => {
    if (timerRef.current) clearInterval(timerRef.current);
    setIsPlaying(false);
    setLow(null);
    setHigh(null);
    setMid(null);
    setLinearIndex(null);
    setCurrentStep(0);
    setSearchResult(null);

    // Precalculate Binary Search steps
    const bSteps: typeof steps = [];
    let l = 0;
    let r = currentArr.length - 1;
    let found = false;

    while (l <= r) {
      const m = Math.floor((l + r) / 2);
      const val = currentArr[m];

      if (val === targetInput) {
        bSteps.push({
          low: l,
          high: r,
          mid: m,
          midVal: val,
          status: 'found',
          description: `arr[mid=${m}] = ${val} == ${targetInput} → Target Found in ${bSteps.length + 1} comparison(s)!`
        });
        found = true;
        break;
      } else if (val < targetInput) {
        bSteps.push({
          low: l,
          high: r,
          mid: m,
          midVal: val,
          status: 'less',
          description: `arr[mid=${m}] = ${val} < ${targetInput} → Target is in RIGHT half. Set low = mid + 1 = ${m + 1}`
        });
        l = m + 1;
      } else {
        bSteps.push({
          low: l,
          high: r,
          mid: m,
          midVal: val,
          status: 'greater',
          description: `arr[mid=${m}] = ${val} > ${targetInput} → Target is in LEFT half. Set high = mid - 1 = ${m - 1}`
        });
        r = m - 1;
      }
    }

    if (!found) {
      bSteps.push({
        low: l,
        high: r,
        mid: Math.floor((l + r) / 2),
        midVal: -1,
        status: 'not_found',
        description: `low (${l}) > high (${r}) → Search range exhausted. Target ${targetInput} is NOT in array.`
      });
    }

    setSteps(bSteps);

    // Precalculate Linear Search steps
    const lSteps: typeof linearSteps = [];
    let lFound = false;
    for (let i = 0; i < currentArr.length; i++) {
      if (currentArr[i] === targetInput) {
        lSteps.push({
          index: i,
          val: currentArr[i],
          status: 'match',
          description: `Checking index [${i}] = ${currentArr[i]} == ${targetInput} → Target Found!`
        });
        lFound = true;
        break;
      } else {
        lSteps.push({
          index: i,
          val: currentArr[i],
          status: 'no_match',
          description: `Checking index [${i}] = ${currentArr[i]} != ${targetInput} → Next element`
        });
      }
    }
    setLinearSteps(lSteps);
  };

  useEffect(() => {
    resetSearch();
  }, [array, targetInput, searchMethod]);

  // Execute a single step by index
  const executeStep = (stepIndex: number) => {
    if (searchMethod === 'binary') {
      if (stepIndex < steps.length) {
        const step = steps[stepIndex];
        setLow(step.low);
        setHigh(step.high);
        setMid(step.mid);
        setCurrentStep(stepIndex + 1);

        if (step.status === 'found') {
          setSearchResult({
            found: true,
            index: step.mid,
            totalProbes: stepIndex + 1,
            message: `Target ${targetInput} discovered at Array Index [${step.mid}] in only ${stepIndex + 1} comparison(s)! (O(log N))`
          });
          setIsPlaying(false);
        } else if (step.status === 'not_found') {
          setSearchResult({
            found: false,
            index: -1,
            totalProbes: stepIndex + 1,
            message: `Target ${targetInput} not found after ${stepIndex + 1} comparison(s). Range exhausted.`
          });
          setIsPlaying(false);
        }
      } else {
        setIsPlaying(false);
      }
    } else {
      if (stepIndex < linearSteps.length) {
        const step = linearSteps[stepIndex];
        setLinearIndex(step.index);
        setCurrentStep(stepIndex + 1);

        if (step.status === 'match') {
          setSearchResult({
            found: true,
            index: step.index,
            totalProbes: stepIndex + 1,
            message: `Target ${targetInput} found at Index [${step.index}] after ${stepIndex + 1} probe(s).`
          });
          setIsPlaying(false);
        } else if (stepIndex + 1 >= linearSteps.length) {
          setSearchResult({
            found: false,
            index: -1,
            totalProbes: linearSteps.length,
            message: `Target ${targetInput} not found in array after scanning all ${linearSteps.length} elements.`
          });
          setIsPlaying(false);
        }
      } else {
        setIsPlaying(false);
      }
    }
  };

  const handleNextStep = () => {
    executeStep(currentStep);
  };

  // Start Auto Search Flow from beginning
  const handleStartAutoSearch = () => {
    const total = searchMethod === 'binary' ? steps.length : linearSteps.length;
    if (currentStep >= total || searchResult) {
      resetSearch();
      setTimeout(() => {
        setIsPlaying(true);
      }, 50);
    } else {
      setIsPlaying(true);
    }
  };

  // Auto search loop timer
  useEffect(() => {
    if (isPlaying) {
      timerRef.current = setInterval(() => {
        setCurrentStep((prev) => {
          const maxSteps = searchMethod === 'binary' ? steps.length : linearSteps.length;
          if (prev < maxSteps) {
            executeStep(prev);
            return prev;
          } else {
            setIsPlaying(false);
            return prev;
          }
        });
      }, speedMs);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, speedMs, steps, linearSteps, searchMethod, targetInput]);

  // Instant Answer Calculator
  const handleInstantAnswer = () => {
    if (searchMethod === 'binary') {
      const lastStep = steps[steps.length - 1];
      if (lastStep) {
        setLow(lastStep.low);
        setHigh(lastStep.high);
        setMid(lastStep.mid);
        setCurrentStep(steps.length);
        if (lastStep.status === 'found') {
          setSearchResult({
            found: true,
            index: lastStep.mid,
            totalProbes: steps.length,
            message: `Full Binary Search Answer: Target ${targetInput} located at Index [${lastStep.mid}] in ${steps.length} iteration(s) (O(log N)).`
          });
        } else {
          setSearchResult({
            found: false,
            index: -1,
            totalProbes: steps.length,
            message: `Full Binary Search Answer: Target ${targetInput} not found in array (Probes: ${steps.length}).`
          });
        }
      }
    } else {
      const lastStep = linearSteps[linearSteps.length - 1];
      if (lastStep) {
        setLinearIndex(lastStep.index);
        setCurrentStep(linearSteps.length);
        setSearchResult({
          found: lastStep.status === 'match',
          index: lastStep.status === 'match' ? lastStep.index : -1,
          totalProbes: linearSteps.length,
          message: lastStep.status === 'match'
            ? `Target ${targetInput} found at Index [${lastStep.index}] after scanning ${linearSteps.length} elements.`
            : `Target ${targetInput} not found in array after ${linearSteps.length} comparisons.`
        });
      }
    }
  };

  const maxValue = Math.max(...array, 100);

  return (
    <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-xs text-slate-800">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-5 mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-3 py-0.5 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200 uppercase tracking-wider">
              Bar Chart Method
            </span>
            <span className="text-xs text-emerald-700 font-mono font-bold">
              {searchMethod === 'binary' ? 'O(log N) Time' : 'O(N) Time'}
            </span>
          </div>
          <h3 className="text-2xl font-bold text-slate-900 tracking-tight">
            {searchMethod === 'binary' ? 'Binary Search in Bar Chart Method' : 'Linear Search in Bar Chart Method'}
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Watch bars eliminate by half at each step with live pointers (Low, Mid, High), exact math, and complete answer output.
          </p>
        </div>

        {/* Method Switcher */}
        <div className="flex items-center bg-slate-100 border border-slate-200 rounded-xl p-1 text-xs">
          <button
            onClick={() => setSearchMethod('binary')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
              searchMethod === 'binary'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Binary Search (O(log N))
          </button>
          <button
            onClick={() => setSearchMethod('linear')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
              searchMethod === 'linear'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Linear Search (O(N))
          </button>
        </div>
      </div>

      {/* Inputs Form */}
      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 mb-6 space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
          <div className="sm:col-span-5">
            <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
              Array Values (Comma-Separated)
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={arrayInput}
                onChange={(e) => setArrayInput(e.target.value)}
                className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm font-mono font-bold text-slate-800"
              />
              <button
                onClick={handleUpdateArray}
                className="px-3 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl text-xs shrink-0"
              >
                Set
              </button>
            </div>
          </div>

          <div className="sm:col-span-4">
            <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
              Add Single Number
            </label>
            <div className="flex gap-2">
              <input
                type="number"
                value={singleValInput}
                onChange={(e) => setSingleValInput(e.target.value)}
                placeholder="e.g. 50"
                className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm font-mono font-bold text-slate-800"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleAddSingleNumber();
                }}
              />
              <button
                onClick={handleAddSingleNumber}
                className="flex items-center gap-1 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add</span>
              </button>
            </div>
          </div>

          <div className="sm:col-span-3">
            <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
              Search Target
            </label>
            <input
              type="number"
              value={targetInput}
              onChange={(e) => setTargetInput(parseInt(e.target.value, 10) || 0)}
              className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm font-mono font-bold text-slate-800"
            />
          </div>
        </div>

        {/* Real-time Editable/Deletable Array Elements Chips */}
        <div className="pt-2 border-t border-slate-200/60 flex flex-wrap items-center gap-2">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider mr-1">
            Current Array ({array.length} items):
          </span>
          {array.map((val, idx) => (
            <span
              key={idx}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-xs font-mono font-bold text-slate-800 shadow-2xs hover:border-slate-300"
            >
              <span>{val}</span>
              <button
                onClick={() => handleDeleteSingleNumber(idx)}
                className="text-slate-400 hover:text-rose-600 transition-colors"
                title={`Delete ${val}`}
              >
                <Trash2 className="w-3 h-3" />
              </button>
            </span>
          ))}
        </div>
      </div>

      {/* Control Buttons & Auto Search Flow Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6 bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
        <div className="flex flex-wrap items-center gap-2">
          {/* Main Auto Search Flow Button */}
          <button
            onClick={handleStartAutoSearch}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-extrabold text-xs shadow-md transition-all ${
              isPlaying
                ? 'bg-amber-500 hover:bg-amber-600 text-white shadow-amber-500/20 animate-pulse'
                : 'bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-700 hover:from-blue-700 hover:to-indigo-700 text-white shadow-blue-600/30 hover:scale-102'
            }`}
          >
            {isPlaying ? (
              <>
                <Pause className="w-4 h-4 fill-current" />
                <span>Pause Auto Flow</span>
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 fill-current text-amber-300" />
                <span>⚡ Run Auto Search Flow</span>
              </>
            )}
          </button>

          <button
            onClick={handleNextStep}
            disabled={
              (searchMethod === 'binary' && currentStep >= steps.length) ||
              (searchMethod === 'linear' && currentStep >= linearSteps.length) ||
              isPlaying
            }
            className="flex items-center gap-1.5 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 disabled:bg-slate-50 disabled:text-slate-400 text-slate-800 font-bold rounded-xl text-xs"
          >
            <ChevronRight className="w-4 h-4" />
            <span>Next Step ({currentStep}/{searchMethod === 'binary' ? steps.length : linearSteps.length})</span>
          </button>

          <button
            onClick={() => resetSearch()}
            className="flex items-center gap-1.5 px-3 py-2 text-slate-500 hover:text-slate-800 font-bold text-xs"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
        </div>

        {/* Speed Controls & Full Answer */}
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-slate-100 rounded-xl p-1 text-xs">
            <span className="text-[10px] font-bold text-slate-500 px-1.5 uppercase">Speed:</span>
            {[
              { label: '0.5x', ms: 1400 },
              { label: '1x', ms: 850 },
              { label: '2x', ms: 400 }
            ].map((spd) => (
              <button
                key={spd.label}
                onClick={() => setSpeedMs(spd.ms)}
                className={`px-2 py-1 rounded-lg text-xs font-bold transition-all ${
                  speedMs === spd.ms ? 'bg-white text-blue-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {spd.label}
              </button>
            ))}
          </div>

          <button
            onClick={handleInstantAnswer}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-xs"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Instant Answer</span>
          </button>
        </div>
      </div>

      {/* ========================================================
          BAR CHART VISUALIZATION
          ======================================================== */}
      <div className="bg-slate-50/80 border border-slate-200 rounded-2xl p-6 mb-6">
        <div className="flex items-center justify-between mb-4 text-xs font-semibold text-slate-500">
          <span>Height represents value • Colors indicate pointers</span>
          <div className="flex items-center gap-3">
            {searchMethod === 'binary' ? (
              <>
                <div className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />
                  <span>Low / High Pointers</span>
                </div>
                <div className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  <span>Mid (Active Probe)</span>
                </div>
                <div className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-300" />
                  <span>Eliminated Half</span>
                </div>
              </>
            ) : (
              <div className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />
                <span>Current Scanner Bar</span>
              </div>
            )}
          </div>
        </div>

        {/* Vertical Bars */}
        <div className="h-56 sm:h-64 flex items-end justify-center gap-2 sm:gap-3 border-b-2 border-slate-300 pb-2">
          {array.map((val, idx) => {
            const barHeightPct = Math.max(15, Math.round((val / maxValue) * 100));

            let barColor = 'bg-blue-100 border-blue-300 text-blue-900';
            let isEliminated = false;
            let isMid = false;
            let isLow = false;
            let isHigh = false;

            if (searchMethod === 'binary' && low !== null && high !== null) {
              if (idx < low || idx > high) {
                isEliminated = true;
                barColor = 'bg-slate-200/70 border-slate-300 text-slate-400 opacity-40';
              } else if (idx === mid) {
                isMid = true;
                if (val === targetInput) {
                  barColor = 'bg-emerald-500 border-emerald-600 text-white shadow-md shadow-emerald-500/30';
                } else {
                  barColor = 'bg-amber-400 border-amber-500 text-amber-950 font-extrabold';
                }
              } else {
                barColor = 'bg-blue-500 border-blue-600 text-white';
              }

              if (idx === low) isLow = true;
              if (idx === high) isHigh = true;
            } else if (searchMethod === 'linear' && linearIndex !== null) {
              if (idx === linearIndex) {
                if (val === targetInput) {
                  barColor = 'bg-emerald-500 border-emerald-600 text-white shadow-md';
                } else {
                  barColor = 'bg-amber-400 border-amber-500 text-amber-950';
                }
              } else if (idx < linearIndex) {
                barColor = 'bg-slate-200 border-slate-300 text-slate-400';
              }
            }

            return (
              <div key={idx} className="flex-1 max-w-[54px] flex flex-col items-center">
                {/* Value on top of bar */}
                <span className={`text-[11px] font-mono font-bold mb-1 ${isMid ? 'text-amber-800' : 'text-slate-700'}`}>
                  {val}
                </span>

                {/* Animated Bar */}
                <div
                  className={`w-full rounded-t-xl border transition-all duration-300 flex items-center justify-center ${barColor}`}
                  style={{ height: `${barHeightPct}%` }}
                >
                  {isMid && (
                    <span className="text-[10px] font-bold font-mono uppercase rotate-[-90deg] sm:rotate-0">
                      MID
                    </span>
                  )}
                </div>

                {/* Index label below axis */}
                <div className="text-center mt-1.5">
                  <span className="text-[10px] font-mono text-slate-500 block font-semibold">
                    [{idx}]
                  </span>

                  {/* Pointer markers */}
                  <div className="h-4 flex items-center justify-center">
                    {searchMethod === 'binary' && (
                      <>
                        {isLow && !isHigh && <span className="text-[9px] font-bold text-blue-700 font-mono">L</span>}
                        {isHigh && !isLow && <span className="text-[9px] font-bold text-purple-700 font-mono">H</span>}
                        {isLow && isHigh && <span className="text-[9px] font-bold text-indigo-700 font-mono">L=H</span>}
                      </>
                    )}
                    {searchMethod === 'linear' && linearIndex === idx && (
                      <span className="text-[9px] font-bold text-blue-700 font-mono">▲</span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Step Explanation & Live Calculation Log */}
      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 mb-6">
        <div className="flex items-center justify-between mb-2 text-xs font-bold text-slate-600">
          <span>STEP-BY-STEP CALCULATION:</span>
          {searchMethod === 'binary' && low !== null && high !== null && mid !== null && (
            <span className="font-mono text-blue-700">
              Formula: mid = ⌊({low} + {high}) / 2⌋ = {mid} (Value: {array[mid]})
            </span>
          )}
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-3 text-xs font-mono text-slate-800 leading-relaxed">
          {currentStep === 0 ? (
            <span className="text-slate-400">Click "Next Step" or "Show Full Answer" to start the bar chart search.</span>
          ) : searchMethod === 'binary' ? (
            steps[currentStep - 1]?.description || 'Step executed.'
          ) : (
            linearSteps[currentStep - 1]?.description || 'Step executed.'
          )}
        </div>
      </div>

      {/* ========================================================
          FULL ANSWER & OUTPUT BOX (EXACT USER REQUIREMENT)
          ======================================================== */}
      {searchResult && (
        <div
          className={`rounded-2xl border-2 p-5 animate-in fade-in ${
            searchResult.found
              ? 'bg-emerald-50 border-emerald-400 text-emerald-950 shadow-xs'
              : 'bg-rose-50 border-rose-300 text-rose-950'
          }`}
        >
          <div className="flex items-center justify-between border-b border-emerald-200/80 pb-3 mb-3">
            <div className="flex items-center gap-2">
              {searchResult.found ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
              ) : (
                <XCircle className="w-5 h-5 text-rose-600" />
              )}
              <h4 className="font-bold text-base">
                {searchResult.found ? 'Target Found Successfully!' : 'Target Not In Array'}
              </h4>
            </div>

            <span className="text-xs font-mono font-bold bg-white px-2.5 py-1 rounded-lg border border-emerald-200">
              Total Iterations / Probes: {searchResult.totalProbes}
            </span>
          </div>

          <p className="text-sm font-semibold mb-3 leading-relaxed">
            {searchResult.message}
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
            <div className="bg-white p-2.5 rounded-xl border border-emerald-200">
              <span className="text-slate-500 block text-[10px]">SEARCHED VALUE</span>
              <strong className="text-slate-900 text-sm">{targetInput}</strong>
            </div>
            <div className="bg-white p-2.5 rounded-xl border border-emerald-200">
              <span className="text-slate-500 block text-[10px]">FOUND AT INDEX</span>
              <strong className="text-emerald-700 text-sm">
                {searchResult.found ? `Index [${searchResult.index}]` : 'None'}
              </strong>
            </div>
            <div className="bg-white p-2.5 rounded-xl border border-emerald-200">
              <span className="text-slate-500 block text-[10px]">ALGORITHM EFFICIENCY</span>
              <strong className="text-blue-700 text-sm">
                {searchMethod === 'binary' ? `O(log ${array.length}) ≈ ${Math.ceil(Math.log2(array.length))} Steps` : `O(${array.length}) Steps`}
              </strong>
            </div>
            <div className="bg-white p-2.5 rounded-xl border border-emerald-200">
              <span className="text-slate-500 block text-[10px]">ARRAY SIZE N</span>
              <strong className="text-slate-900 text-sm">{array.length} Elements</strong>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
