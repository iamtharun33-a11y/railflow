import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { useAIModal } from '../context/AIModalContext';
import { Train, Bot, Globe, User, LogOut, Ticket, Award, Menu, X, Sparkles } from 'lucide-react';
import { Language } from '../types';

interface NavbarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPath, onNavigate }) => {
  const { user, logout } = useAuth();
  const { language, setLanguage, t } = useLanguage();
  const { openAI } = useAIModal();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [langDropdownOpen, setLangDropdownOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const navLinks = [
    { path: '/', label: t('nav_home') },
    { path: '/barchart', label: '📊 Bar Chart Lab' },
    { path: '/dsa-lab', label: t('nav_dsa_lab') },
    { path: '/trains', label: t('nav_trains') },
    { path: '/pnr', label: t('nav_pnr') },
    { path: '/dsa-game', label: t('nav_dsa_game') },
    { path: '/simulation', label: t('nav_simulation') },
    { path: '/presentation', label: t('nav_presentation') }
  ];

  const handleLanguageSelect = (lang: Language) => {
    setLanguage(lang);
    setLangDropdownOpen(false);
  };

  return (
    <nav className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 text-slate-800 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div
            onClick={() => onNavigate('/')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-700 to-indigo-600 flex items-center justify-center shadow-md shadow-blue-700/20 group-hover:scale-105 transition-transform text-white">
              <Train className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-xl tracking-tight text-blue-900">RAILFLOW</span>
                <span className="text-[10px] uppercase font-bold bg-blue-50 text-blue-700 border border-blue-200 px-1.5 py-0.5 rounded tracking-wider">
                  DSA Platform
                </span>
              </div>
              <span className="text-[11px] text-slate-500 block -mt-0.5 font-medium">
                Reserve. Understand. Master.
              </span>
            </div>
          </div>

          {/* Desktop Nav Links */}
          <div className="hidden lg:flex items-center space-x-1">
            {navLinks.map((link) => {
              const isActive = currentPath === link.path;
              return (
                <button
                  key={link.path}
                  onClick={() => onNavigate(link.path)}
                  className={`px-3 py-1.5 rounded-lg text-sm font-semibold transition-all ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-sm shadow-blue-600/30'
                      : 'text-slate-600 hover:text-blue-700 hover:bg-slate-100'
                  }`}
                >
                  {link.label}
                </button>
              );
            })}
          </div>

          {/* Right Controls: AI Mentor, Language, Auth */}
          <div className="hidden sm:flex items-center space-x-3">
            {/* Real AI Mentor Button */}
            <button
              onClick={() => openAI()}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 border border-blue-200 text-blue-700 hover:text-blue-800 text-xs font-bold transition-all shadow-xs"
            >
              <Sparkles className="w-3.5 h-3.5 text-blue-600 animate-spin" />
              <span>{t('nav_ai_guide')}</span>
            </button>

            {/* Language Selector */}
            <div className="relative">
              <button
                onClick={() => setLangDropdownOpen(!langDropdownOpen)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 text-xs font-medium text-slate-700"
              >
                <Globe className="w-3.5 h-3.5 text-slate-500" />
                <span>
                  {language === 'en' ? 'English' : language === 'ta' ? 'தமிழ்' : 'हिन्दी'}
                </span>
              </button>

              {langDropdownOpen && (
                <div className="absolute right-0 mt-2 w-36 bg-white border border-slate-200 rounded-xl shadow-lg py-1 z-50 animate-in fade-in zoom-in-95">
                  <button
                    onClick={() => handleLanguageSelect('en')}
                    className={`w-full text-left px-3 py-1.5 text-xs ${
                      language === 'en' ? 'bg-blue-50 text-blue-700 font-bold' : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    English
                  </button>
                  <button
                    onClick={() => handleLanguageSelect('ta')}
                    className={`w-full text-left px-3 py-1.5 text-xs ${
                      language === 'ta' ? 'bg-blue-50 text-blue-700 font-bold' : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    தமிழ் (Tamil)
                  </button>
                  <button
                    onClick={() => handleLanguageSelect('hi')}
                    className={`w-full text-left px-3 py-1.5 text-xs ${
                      language === 'hi' ? 'bg-blue-50 text-blue-700 font-bold' : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    हिन्दी (Hindi)
                  </button>
                </div>
              )}
            </div>

            {/* Auth Section */}
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center gap-2 pl-2 pr-3 py-1 rounded-xl bg-slate-50 border border-slate-200 hover:border-slate-300 transition-colors"
                >
                  <div className="w-7 h-7 rounded-lg bg-blue-600 text-white font-bold flex items-center justify-center text-xs">
                    {user.name.charAt(0).toUpperCase()}
                  </div>
                  <div className="text-left text-xs">
                    <span className="font-semibold text-slate-800 block truncate max-w-[100px]">
                      {user.name}
                    </span>
                    <span className="text-[10px] text-emerald-600 font-mono font-bold">
                      Lv.{user.level} • {user.xp} XP
                    </span>
                  </div>
                </button>

                {userDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-white border border-slate-200 rounded-xl shadow-lg py-1 z-50 text-xs animate-in fade-in zoom-in-95">
                    <div className="px-3 py-2 border-b border-slate-100">
                      <span className="text-slate-500 block text-[11px]">Logged in as</span>
                      <strong className="text-slate-800 truncate block">{user.email}</strong>
                    </div>
                    <button
                      onClick={() => {
                        onNavigate('/dashboard');
                        setUserDropdownOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                    >
                      <User className="w-3.5 h-3.5 text-blue-600" />
                      <span>{t('nav_dashboard')}</span>
                    </button>
                    <button
                      onClick={() => {
                        onNavigate('/my-tickets');
                        setUserDropdownOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                    >
                      <Ticket className="w-3.5 h-3.5 text-emerald-600" />
                      <span>{t('nav_tickets')}</span>
                    </button>
                    <button
                      onClick={() => {
                        logout();
                        setUserDropdownOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 text-red-600 hover:bg-red-50 flex items-center gap-2 border-t border-slate-100"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>{t('nav_logout')}</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => onNavigate('/login')}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-blue-700 transition-colors"
                >
                  {t('nav_login')}
                </button>
                <button
                  onClick={() => onNavigate('/register')}
                  className="px-3.5 py-1.5 text-xs font-bold rounded-lg bg-blue-600 hover:bg-blue-700 text-white shadow-sm shadow-blue-600/30 transition-all"
                >
                  {t('nav_register')}
                </button>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center gap-2 lg:hidden">
            <button
              onClick={() => openAI()}
              className="p-2 rounded-lg bg-blue-50 text-blue-700 border border-blue-200"
            >
              <Bot className="w-4 h-4" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-3">
          <div className="grid grid-cols-2 gap-2">
            {navLinks.map((link) => (
              <button
                key={link.path}
                onClick={() => {
                  onNavigate(link.path);
                  setMobileMenuOpen(false);
                }}
                className={`text-left px-3 py-2 rounded-lg text-xs font-semibold ${
                  currentPath === link.path ? 'bg-blue-600 text-white' : 'text-slate-700 bg-slate-50'
                }`}
              >
                {link.label}
              </button>
            ))}
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-slate-200">
            <div className="flex gap-2">
              {(['en', 'ta', 'hi'] as Language[]).map((l) => (
                <button
                  key={l}
                  onClick={() => handleLanguageSelect(l)}
                  className={`px-2 py-1 rounded text-xs ${
                    language === l ? 'bg-blue-600 text-white font-bold' : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {l === 'en' ? 'EN' : l === 'ta' ? 'தமிழ்' : 'हिन्दी'}
                </button>
              ))}
            </div>

            {user ? (
              <button
                onClick={() => {
                  logout();
                  setMobileMenuOpen(false);
                }}
                className="text-xs text-red-600 font-semibold"
              >
                {t('nav_logout')}
              </button>
            ) : (
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    onNavigate('/login');
                    setMobileMenuOpen(false);
                  }}
                  className="px-3 py-1 text-xs text-slate-700"
                >
                  {t('nav_login')}
                </button>
                <button
                  onClick={() => {
                    onNavigate('/register');
                    setMobileMenuOpen(false);
                  }}
                  className="px-3 py-1 bg-blue-600 text-white rounded text-xs font-bold"
                >
                  {t('nav_register')}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};
