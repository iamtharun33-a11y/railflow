import React from 'react';
import { Train, ShieldCheck } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export const Footer: React.FC<{ onNavigate: (path: string) => void }> = ({ onNavigate }) => {
  const { language } = useLanguage();

  return (
    <footer className="bg-white border-t border-slate-200 text-slate-600 text-sm py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand Info */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white">
                <Train className="w-4 h-4" />
              </div>
              <span className="font-extrabold text-blue-900 text-lg tracking-tight">RAILFLOW</span>
            </div>
            <p className="text-slate-800 font-semibold mb-1">Reserve. Understand. Master DSA.</p>
            <p className="text-xs text-slate-500 max-w-md leading-relaxed">
              {language === 'ta'
                ? 'உண்மையான ரயில்வே முன்பதிவு அமைப்புடன், காத்திருப்பு பட்டியல் Queue, PNR Hash Map மற்றும் வழிகாட்டல் வரைபட அல்காரிதங்களை எளிமையாகக் கற்றுத்தரும் தளம்.'
                : language === 'hi'
                ? 'वास्तविक रेलवे आरक्षण प्रणाली के साथ-साथ Queue वेटिंग लिस्ट, PNR Hash Map और ग्राफ एल्गोरिदम सिखाने वाला आधुनिक प्लेटफॉर्म।'
                : 'A high-performance railway reservation and waiting-list platform built to visually demonstrate Queue, Hash Map, Graph BFS/DFS, and Stack algorithms.'}
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-xs uppercase font-bold text-slate-900 tracking-wider mb-3">Railway Flow</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onNavigate('/trains')} className="hover:text-blue-700 transition-colors">
                  Search & Book Trains
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/pnr')} className="hover:text-blue-700 transition-colors">
                  PNR Status & Hash Map
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/my-tickets')} className="hover:text-blue-700 transition-colors">
                  My Tickets & Cancellations
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/simulation')} className="hover:text-blue-700 transition-colors">
                  Waiting Queue Sandbox
                </button>
              </li>
            </ul>
          </div>

          {/* DSA & Academics */}
          <div>
            <h4 className="text-xs uppercase font-bold text-slate-900 tracking-wider mb-3">DSA Learning</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onNavigate('/dsa-lab')} className="hover:text-blue-700 transition-colors">
                  Interactive DSA Lab
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/dsa-game')} className="hover:text-blue-700 transition-colors">
                  Railway Algorithm Game
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/presentation')} className="hover:text-blue-700 transition-colors">
                  Presentation Mode
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/dashboard')} className="hover:text-blue-700 transition-colors">
                  XP & Achievements
                </button>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-200 pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-3">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Clean Architecture: Real data driven • No fake accounts • Pure algorithm execution</span>
          </div>
          <div className="font-mono text-slate-500">
            RailFlow © 2026 • Powered by Gemini 3.8 Flash
          </div>
        </div>
      </div>
    </footer>
  );
};
