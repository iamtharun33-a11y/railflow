import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  ChevronRight,
  CheckCircle2,
  Zap,
  Plus,
  Trash2,
  Code2,
  Copy,
  Check,
  Sparkles,
  BarChart3,
  Layers,
  ArrowRight
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export type SortType = 'selection' | 'insertion' | 'bubble' | 'merge';

interface SortStep {
  array: number[];
  comparingIndices: number[];
  swappedIndices: number[];
  minIndex?: number;
  insertedIndex?: number;
  mergeRange?: [number, number];
  description: string;
  comparisons: number;
  swaps: number;
  algorithmLine?: string;
}

export const BarChartSortingVisualizer: React.FC = () => {
  const { language } = useLanguage();

  // Array values & sort type
  const [arrayInput, setArrayInput] = useState<string>('54, 26, 93, 17, 77, 31, 44, 55, 20');
  const [array, setArray] = useState<number[]>([54, 26, 93, 17, 77, 31, 44, 55, 20]);
  const [sortType, setSortType] = useState<SortType>('selection');
  const [singleValInput, setSingleValInput] = useState<string>('');

  // Execution states
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [steps, setSteps] = useState<SortStep[]>([]);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [speedMs, setSpeedMs] = useState<number>(750);
  const [isSorted, setIsSorted] = useState<boolean>(false);
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Generate steps based on algorithm
  const generateSteps = (initialArr: number[], type: SortType): SortStep[] => {
    const list: SortStep[] = [];
    const arr = [...initialArr];
    let comparisons = 0;
    let swaps = 0;

    // Initial state
    list.push({
      array: [...arr],
      comparingIndices: [],
      swappedIndices: [],
      description: `Initial state with ${arr.length} numbers. Ready to start ${type.toUpperCase()} SORT.`,
      comparisons: 0,
      swaps: 0,
      algorithmLine: 'start'
    });

    if (type === 'selection') {
      const n = arr.length;
      for (let i = 0; i < n - 1; i++) {
        let minIdx = i;

        list.push({
          array: [...arr],
          comparingIndices: [i],
          swappedIndices: [],
          minIndex: minIdx,
          description: `Pass #${i + 1}: Assume element at index [${i}] (${arr[i]}) is the current minimum.`,
          comparisons,
          swaps,
          algorithmLine: 'min_idx = i'
        });

        for (let j = i + 1; j < n; j++) {
          comparisons++;
          const isNewMin = arr[j] < arr[minIdx];

          list.push({
            array: [...arr],
            comparingIndices: [minIdx, j],
            swappedIndices: [],
            minIndex: minIdx,
            description: `Comparing candidate min arr[${minIdx}]=${arr[minIdx]} with arr[${j}]=${arr[j]}.${
              isNewMin ? ` Found smaller element! Updated minimum index to [${j}] (${arr[j]}).` : ''
            }`,
            comparisons,
            swaps,
            algorithmLine: isNewMin ? 'if arr[j] < arr[min_idx]: min_idx = j' : 'for j from i+1 to n'
          });

          if (isNewMin) {
            minIdx = j;
          }
        }

        if (minIdx !== i) {
          swaps++;
          const temp = arr[i];
          arr[i] = arr[minIdx];
          arr[minIdx] = temp;

          list.push({
            array: [...arr],
            comparingIndices: [],
            swappedIndices: [i, minIdx],
            minIndex: i,
            description: `Swapped minimum element ${arr[i]} into sorted position [${i}] with ${arr[minIdx]}.`,
            comparisons,
            swaps,
            algorithmLine: 'swap(arr[i], arr[min_idx])'
          });
        }
      }
    } else if (type === 'insertion') {
      const n = arr.length;
      for (let i = 1; i < n; i++) {
        const key = arr[i];
        let j = i - 1;

        list.push({
          array: [...arr],
          comparingIndices: [i],
          swappedIndices: [],
          insertedIndex: i,
          description: `Selecting key = ${key} at index [${i}]. Preparing to insert into sorted sub-array [0..${i - 1}].`,
          comparisons,
          swaps,
          algorithmLine: 'key = arr[i]'
        });

        while (j >= 0) {
          comparisons++;
          if (arr[j] > key) {
            swaps++;
            arr[j + 1] = arr[j];

            list.push({
              array: [...arr],
              comparingIndices: [j, j + 1],
              swappedIndices: [j, j + 1],
              insertedIndex: j,
              description: `arr[${j}]=${arr[j + 1]} > key (${key}) → Shifted ${arr[j + 1]} to the right (index [${j + 1}]).`,
              comparisons,
              swaps,
              algorithmLine: 'arr[j + 1] = arr[j]'
            });
            j--;
          } else {
            list.push({
              array: [...arr],
              comparingIndices: [j],
              swappedIndices: [],
              insertedIndex: j + 1,
              description: `arr[${j}]=${arr[j]} <= key (${key}) → Found insertion position at index [${j + 1}].`,
              comparisons,
              swaps,
              algorithmLine: 'break'
            });
            break;
          }
        }
        arr[j + 1] = key;

        list.push({
          array: [...arr],
          comparingIndices: [],
          swappedIndices: [j + 1],
          insertedIndex: j + 1,
          description: `Inserted key ${key} into position [${j + 1}]. Sub-array [0..${i}] is sorted.`,
          comparisons,
          swaps,
          algorithmLine: 'arr[j + 1] = key'
        });
      }
    } else if (type === 'bubble') {
      const n = arr.length;
      for (let i = 0; i < n - 1; i++) {
        for (let j = 0; j < n - i - 1; j++) {
          comparisons++;
          const shouldSwap = arr[j] > arr[j + 1];

          list.push({
            array: [...arr],
            comparingIndices: [j, j + 1],
            swappedIndices: [],
            description: `Comparing adjacent elements: arr[${j}]=${arr[j]} and arr[${j + 1}]=${arr[j + 1]}. ${
              shouldSwap ? 'Left > Right → Swap needed!' : 'In correct order.'
            }`,
            comparisons,
            swaps,
            algorithmLine: 'if arr[j] > arr[j+1]:'
          });

          if (shouldSwap) {
            swaps++;
            const temp = arr[j];
            arr[j] = arr[j + 1];
            arr[j + 1] = temp;

            list.push({
              array: [...arr],
              comparingIndices: [],
              swappedIndices: [j, j + 1],
              description: `Swapped arr[${j}] and arr[${j + 1}]. Larger value bubbles rightward.`,
              comparisons,
              swaps,
              algorithmLine: 'swap(arr[j], arr[j+1])'
            });
          }
        }
      }
    } else if (type === 'merge') {
      // Merge Sort simulation
      const mergeSortHelper = (l: number, r: number) => {
        if (l >= r) return;
        const m = Math.floor((l + r) / 2);

        list.push({
          array: [...arr],
          comparingIndices: [l, r],
          swappedIndices: [],
          mergeRange: [l, r],
          description: `Divide step: Splitting sub-array [${l}..${r}] at midpoint ${m} into Left [${l}..${m}] and Right [${m + 1}..${r}].`,
          comparisons,
          swaps,
          algorithmLine: 'mid = (l + r) / 2'
        });

        mergeSortHelper(l, m);
        mergeSortHelper(m + 1, r);

        // Merge sub-arrays
        const leftArr = arr.slice(l, m + 1);
        const rightArr = arr.slice(m + 1, r + 1);
        let i = 0;
        let j = 0;
        let k = l;

        while (i < leftArr.length && j < rightArr.length) {
          comparisons++;
          list.push({
            array: [...arr],
            comparingIndices: [l + i, m + 1 + j],
            swappedIndices: [],
            mergeRange: [l, r],
            description: `Merge comparison: Left ${leftArr[i]} vs Right ${rightArr[j]}. Smallest will be placed at index [${k}].`,
            comparisons,
            swaps,
            algorithmLine: 'if left[i] <= right[j]:'
          });

          if (leftArr[i] <= rightArr[j]) {
            arr[k] = leftArr[i];
            i++;
          } else {
            arr[k] = rightArr[j];
            j++;
            swaps++;
          }

          list.push({
            array: [...arr],
            comparingIndices: [],
            swappedIndices: [k],
            mergeRange: [l, r],
            description: `Merged value ${arr[k]} into position [${k}].`,
            comparisons,
            swaps,
            algorithmLine: 'arr[k] = merged_value'
          });
          k++;
        }

        while (i < leftArr.length) {
          arr[k] = leftArr[i];
          list.push({
            array: [...arr],
            comparingIndices: [],
            swappedIndices: [k],
            mergeRange: [l, r],
            description: `Copied remaining Left element ${leftArr[i]} to index [${k}].`,
            comparisons,
            swaps,
            algorithmLine: 'arr[k] = left[i]'
          });
          i++;
          k++;
        }

        while (j < rightArr.length) {
          arr[k] = rightArr[j];
          list.push({
            array: [...arr],
            comparingIndices: [],
            swappedIndices: [k],
            mergeRange: [l, r],
            description: `Copied remaining Right element ${rightArr[j]} to index [${k}].`,
            comparisons,
            swaps,
            algorithmLine: 'arr[k] = right[j]'
          });
          j++;
          k++;
        }
      };

      mergeSortHelper(0, arr.length - 1);
    }

    // Final sorted state
    list.push({
      array: [...arr],
      comparingIndices: [],
      swappedIndices: [],
      description: `All elements are fully sorted in ascending order! Total Comparisons: ${comparisons}, Total Swaps/Operations: ${swaps}.`,
      comparisons,
      swaps,
      algorithmLine: 'sorted_complete'
    });

    return list;
  };

  const resetWithArray = (newArr: number[], type: SortType = sortType) => {
    if (timerRef.current) clearInterval(timerRef.current);
    setIsPlaying(false);
    setIsSorted(false);
    setCurrentStepIndex(0);
    const newSteps = generateSteps(newArr, type);
    setSteps(newSteps);
  };

  useEffect(() => {
    resetWithArray(array, sortType);
  }, [sortType]);

  const handleUpdateArray = () => {
    const parsed = arrayInput
      .split(',')
      .map((s) => parseInt(s.trim(), 10))
      .filter((n) => !isNaN(n));

    if (parsed.length === 0) return;
    setArray(parsed);
    setArrayInput(parsed.join(', '));
    resetWithArray(parsed, sortType);
  };

  const handleAddSingleNumber = () => {
    const val = parseInt(singleValInput.trim(), 10);
    if (isNaN(val)) return;
    const updated = [...array, val];
    setArray(updated);
    setArrayInput(updated.join(', '));
    setSingleValInput('');
    resetWithArray(updated, sortType);
  };

  const handleDeleteNumber = (idx: number) => {
    if (array.length <= 2) return;
    const updated = array.filter((_, i) => i !== idx);
    setArray(updated);
    setArrayInput(updated.join(', '));
    resetWithArray(updated, sortType);
  };

  // Next Step execution
  const handleNextStep = () => {
    if (currentStepIndex < steps.length - 1) {
      const nextIdx = currentStepIndex + 1;
      setCurrentStepIndex(nextIdx);
      if (nextIdx === steps.length - 1) {
        setIsSorted(true);
        setIsPlaying(false);
      }
    }
  };

  // Start Auto Sorting Flow
  const handleStartAutoSort = () => {
    if (currentStepIndex >= steps.length - 1 || isSorted) {
      resetWithArray(array, sortType);
      setTimeout(() => {
        setIsPlaying(true);
      }, 50);
    } else {
      setIsPlaying(!isPlaying);
    }
  };

  // Auto-play timer
  useEffect(() => {
    if (isPlaying) {
      timerRef.current = setInterval(() => {
        setCurrentStepIndex((prev) => {
          if (prev < steps.length - 1) {
            const next = prev + 1;
            if (next === steps.length - 1) {
              setIsSorted(true);
              setIsPlaying(false);
            }
            return next;
          } else {
            setIsPlaying(false);
            setIsSorted(true);
            return prev;
          }
        });
      }, speedMs);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, speedMs, steps]);

  // Instant Sort to End (Shows Full Answer & Complete Algorithm)
  const handleInstantSort = () => {
    if (steps.length > 0) {
      setCurrentStepIndex(steps.length - 1);
      setIsSorted(true);
      setIsPlaying(false);
    }
  };

  const currentStep = steps[currentStepIndex] || {
    array,
    comparingIndices: [],
    swappedIndices: [],
    description: 'Ready to sort.',
    comparisons: 0,
    swaps: 0
  };

  const displayArray = currentStep.array;
  const maxValue = Math.max(...displayArray, 100);

  // Algorithm Source Code Map
  const algorithmCodes: Record<SortType, { title: string; time: string; space: string; code: string }> = {
    selection: {
      title: 'Selection Sort Algorithm',
      time: 'O(N²) Comparisons, O(N) Swaps',
      space: 'O(1) Auxiliary Space',
      code: `function selectionSort(arr: number[]): number[] {
  const n = arr.length;
  for (let i = 0; i < n - 1; i++) {
    let minIdx = i;
    for (let j = i + 1; j < n; j++) {
      if (arr[j] < arr[minIdx]) {
        minIdx = j; // Found new candidate minimum
      }
    }
    if (minIdx !== i) {
      [arr[i], arr[minIdx]] = [arr[minIdx], arr[i]]; // Swap into position
    }
  }
  return arr;
}`
    },
    insertion: {
      title: 'Insertion Sort Algorithm',
      time: 'O(N²) Worst/Average, O(N) Best',
      space: 'O(1) Auxiliary Space',
      code: `function insertionSort(arr: number[]): number[] {
  const n = arr.length;
  for (let i = 1; i < n; i++) {
    const key = arr[i];
    let j = i - 1;
    // Shift elements greater than key to the right
    while (j >= 0 && arr[j] > key) {
      arr[j + 1] = arr[j];
      j--;
    }
    arr[j + 1] = key; // Insert key in sorted sub-array
  }
  return arr;
}`
    },
    bubble: {
      title: 'Bubble Sort Algorithm',
      time: 'O(N²) Comparisons & Swaps',
      space: 'O(1) Auxiliary Space',
      code: `function bubbleSort(arr: number[]): number[] {
  const n = arr.length;
  for (let i = 0; i < n - 1; i++) {
    for (let j = 0; j < n - i - 1; j++) {
      if (arr[j] > arr[j + 1]) {
        // Swap adjacent elements in wrong order
        const temp = arr[j];
        arr[j] = arr[j + 1];
        arr[j + 1] = temp;
      }
    }
  }
  return arr;
}`
    },
    merge: {
      title: 'Merge Sort Algorithm (Divide & Conquer)',
      time: 'O(N log N) Guaranteed',
      space: 'O(N) Auxiliary Space',
      code: `function mergeSort(arr: number[]): number[] {
  if (arr.length <= 1) return arr;
  const mid = Math.floor(arr.length / 2);
  const left = mergeSort(arr.slice(0, mid));
  const right = mergeSort(arr.slice(mid));
  return merge(left, right);
}

function merge(left: number[], right: number[]): number[] {
  const result: number[] = [];
  let i = 0, j = 0;
  while (i < left.length && j < right.length) {
    if (left[i] <= right[j]) result.push(left[i++]);
    else result.push(right[j++]);
  }
  return result.concat(left.slice(i)).concat(right.slice(j));
}`
    }
  };

  const currentAlgo = algorithmCodes[sortType];

  const handleCopyCode = () => {
    navigator.clipboard.writeText(currentAlgo.code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-xs text-slate-800">
      {/* Title & Algorithm Type Switcher */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-100 pb-5 mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="px-3 py-0.5 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200 uppercase tracking-wider flex items-center gap-1.5">
              <BarChart3 className="w-3.5 h-3.5" />
              Big Bar Chart Auto Sorting Suite
            </span>
            <span className="text-xs text-emerald-700 font-mono font-bold">
              {currentAlgo.time} • {currentAlgo.space}
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            {currentAlgo.title}
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Watch the bar chart auto-sort step-by-step with real-time comparisons, swaps, and the live algorithm code running below.
          </p>
        </div>

        {/* 4 Sorting Algorithm Tabs */}
        <div className="flex flex-wrap items-center bg-slate-100 border border-slate-200 rounded-2xl p-1.5 text-xs gap-1">
          <button
            onClick={() => setSortType('selection')}
            className={`px-3.5 py-2 rounded-xl font-extrabold transition-all ${
              sortType === 'selection' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            1. Selection Sort
          </button>
          <button
            onClick={() => setSortType('insertion')}
            className={`px-3.5 py-2 rounded-xl font-extrabold transition-all ${
              sortType === 'insertion' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            2. Insertion Sort
          </button>
          <button
            onClick={() => setSortType('bubble')}
            className={`px-3.5 py-2 rounded-xl font-extrabold transition-all ${
              sortType === 'bubble' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            3. Bubble Sort
          </button>
          <button
            onClick={() => setSortType('merge')}
            className={`px-3.5 py-2 rounded-xl font-extrabold transition-all ${
              sortType === 'merge' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            4. Merge Sort
          </button>
        </div>
      </div>

      {/* Inputs Form */}
      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 mb-6 space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
          <div className="sm:col-span-7">
            <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
              Custom Array Values (Comma-Separated)
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={arrayInput}
                onChange={(e) => setArrayInput(e.target.value)}
                className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm font-mono font-bold text-slate-800"
              />
              <button
                onClick={handleUpdateArray}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl text-xs shrink-0"
              >
                Set Array
              </button>
            </div>
          </div>

          <div className="sm:col-span-5">
            <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
              Add Single Number
            </label>
            <div className="flex gap-2">
              <input
                type="number"
                value={singleValInput}
                onChange={(e) => setSingleValInput(e.target.value)}
                placeholder="e.g. 68"
                className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm font-mono font-bold text-slate-800"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleAddSingleNumber();
                }}
              />
              <button
                onClick={handleAddSingleNumber}
                className="flex items-center gap-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add</span>
              </button>
            </div>
          </div>
        </div>

        {/* Real-time Editable/Deletable Array Elements Chips */}
        <div className="pt-2 border-t border-slate-200/60 flex flex-wrap items-center gap-2">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider mr-1">
            Current Elements ({array.length}):
          </span>
          {array.map((val, idx) => (
            <span
              key={idx}
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-white border border-slate-200 text-xs font-mono font-bold text-slate-800 shadow-2xs hover:border-slate-300"
            >
              <span>{val}</span>
              <button
                onClick={() => handleDeleteNumber(idx)}
                className="text-slate-400 hover:text-rose-600 transition-colors"
                title={`Delete ${val}`}
              >
                <Trash2 className="w-3 h-3" />
              </button>
            </span>
          ))}
        </div>
      </div>

      {/* Control Buttons & Speed Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6 bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
        <div className="flex flex-wrap items-center gap-2">
          {/* Main Auto Sort Flow Button */}
          <button
            onClick={handleStartAutoSort}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-extrabold text-xs shadow-md transition-all ${
              isPlaying
                ? 'bg-amber-500 hover:bg-amber-600 text-white shadow-amber-500/20 animate-pulse'
                : 'bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-700 hover:from-blue-700 hover:to-indigo-700 text-white shadow-blue-600/30 hover:scale-102'
            }`}
          >
            {isPlaying ? (
              <>
                <Pause className="w-4 h-4 fill-current" />
                <span>Pause Auto Sort</span>
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 fill-current text-amber-300" />
                <span>⚡ Run Auto Sorting Flow</span>
              </>
            )}
          </button>

          <button
            onClick={handleNextStep}
            disabled={currentStepIndex >= steps.length - 1 || isPlaying}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 disabled:bg-slate-50 disabled:text-slate-400 text-slate-800 font-bold rounded-xl text-xs"
          >
            <ChevronRight className="w-4 h-4" />
            <span>Next Step ({currentStepIndex}/{Math.max(0, steps.length - 1)})</span>
          </button>

          <button
            onClick={() => resetWithArray(array, sortType)}
            className="flex items-center gap-1.5 px-3 py-2 text-slate-500 hover:text-slate-800 font-bold text-xs"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
        </div>

        {/* Speed & Instant Sort */}
        <div className="flex items-center gap-3">
          <div className="flex items-center bg-slate-100 rounded-xl p-1 text-xs">
            <span className="text-[10px] font-bold text-slate-500 px-1.5 uppercase">Speed:</span>
            {[
              { label: '0.5x', ms: 1200 },
              { label: '1x', ms: 750 },
              { label: '2x', ms: 350 }
            ].map((spd) => (
              <button
                key={spd.label}
                onClick={() => setSpeedMs(spd.ms)}
                className={`px-2 py-1 rounded-lg text-xs font-bold transition-all ${
                  speedMs === spd.ms ? 'bg-white text-blue-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {spd.label}
              </button>
            ))}
          </div>

          <button
            onClick={handleInstantSort}
            className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl text-xs shadow-md shadow-emerald-600/30 transition-all hover:scale-102"
          >
            <Zap className="w-4 h-4 fill-current text-amber-300" />
            <span>⚡ Instant Sort (Show Full Answer & Code)</span>
          </button>
        </div>
      </div>

      {/* ========================================================
          BIG BAR CHART (TALL, WIDE & HIGH VISIBILITY: h-80 sm:h-96)
          ======================================================== */}
      <div className="bg-slate-50/90 border-2 border-slate-200 rounded-3xl p-6 sm:p-8 mb-6 relative overflow-hidden">
        {/* Subtle grid pattern */}
        <div
          className="absolute inset-0 opacity-40 pointer-events-none"
          style={{
            backgroundImage:
              'linear-gradient(to right, #E2E8F0 1px, transparent 1px), linear-gradient(to bottom, #E2E8F0 1px, transparent 1px)',
            backgroundSize: '32px 32px'
          }}
        />

        {/* Legend */}
        <div className="flex flex-wrap items-center justify-between gap-3 mb-6 text-xs font-semibold text-slate-600 relative z-10">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800">Big Bar Height = Value</span>
            <span className="text-slate-400">•</span>
            <span className="text-slate-500">Live Dynamic Color Tracking</span>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-amber-400 border border-amber-500" />
              <span>Comparing</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-rose-500 border border-rose-600" />
              <span>Swapped / Shifted</span>
            </div>
            {sortType === 'selection' && (
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded bg-purple-500 border border-purple-600" />
                <span>Min Candidate</span>
              </div>
            )}
            {sortType === 'insertion' && (
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded bg-indigo-500 border border-indigo-600" />
                <span>Active Key</span>
              </div>
            )}
            {sortType === 'merge' && (
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded bg-cyan-500 border border-cyan-600" />
                <span>Merge Window</span>
              </div>
            )}
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-emerald-500 border border-emerald-600" />
              <span>Sorted</span>
            </div>
          </div>
        </div>

        {/* BIG TALL BAR CHART BARS: h-80 sm:h-96 (Over 380px Tall!) */}
        <div className="h-80 sm:h-96 flex items-end justify-center gap-2 sm:gap-4 border-b-2 border-slate-300 pb-2 relative z-10 px-2">
          {displayArray.map((val, idx) => {
            const barHeightPct = Math.max(18, Math.round((val / maxValue) * 100));

            const isComparing = currentStep.comparingIndices.includes(idx);
            const isSwapped = currentStep.swappedIndices.includes(idx);
            const isMin = currentStep.minIndex === idx;
            const isInserted = currentStep.insertedIndex === idx;
            const isInMerge = currentStep.mergeRange && idx >= currentStep.mergeRange[0] && idx <= currentStep.mergeRange[1];

            let barBg = 'bg-gradient-to-t from-blue-600 to-blue-500 border-blue-700 text-white';
            let labelBadge = '';

            if (isSorted) {
              barBg = 'bg-gradient-to-t from-emerald-600 to-emerald-400 border-emerald-700 text-white shadow-md shadow-emerald-500/20';
              labelBadge = '✓';
            } else if (isSwapped) {
              barBg = 'bg-gradient-to-t from-rose-600 to-rose-400 border-rose-700 text-white shadow-lg shadow-rose-500/30 animate-bounce';
              labelBadge = 'SWAP';
            } else if (isComparing) {
              barBg = 'bg-gradient-to-t from-amber-500 to-amber-300 border-amber-600 text-amber-950 font-extrabold shadow-md';
              labelBadge = 'COMP';
            } else if (isMin) {
              barBg = 'bg-gradient-to-t from-purple-600 to-purple-400 border-purple-700 text-white shadow-md';
              labelBadge = 'MIN';
            } else if (isInserted) {
              barBg = 'bg-gradient-to-t from-indigo-600 to-indigo-400 border-indigo-700 text-white shadow-md';
              labelBadge = 'KEY';
            } else if (isInMerge) {
              barBg = 'bg-gradient-to-t from-cyan-600 to-cyan-400 border-cyan-700 text-white';
            }

            return (
              <div key={idx} className="flex-1 max-w-[68px] flex flex-col items-center h-full justify-end">
                {/* Number Value on Top of Bar in Large Visible Font */}
                <span
                  className={`text-xs sm:text-sm font-mono font-extrabold mb-1.5 transition-all ${
                    isComparing || isSwapped ? 'text-amber-800 scale-110' : 'text-slate-800'
                  }`}
                >
                  {val}
                </span>

                {/* Big Animated Bar */}
                <div
                  className={`w-full rounded-t-2xl border-2 transition-all duration-300 flex flex-col items-center justify-between py-2 ${barBg}`}
                  style={{ height: `${barHeightPct}%`, minHeight: '38px' }}
                >
                  {labelBadge ? (
                    <span className="text-[10px] sm:text-xs font-black font-mono tracking-tighter uppercase">
                      {labelBadge}
                    </span>
                  ) : (
                    <span />
                  )}
                  <span className="text-[10px] font-mono opacity-80">{val}</span>
                </div>

                {/* Index label below Axis */}
                <div className="text-center mt-2">
                  <span className="text-[10px] sm:text-xs font-mono text-slate-500 block font-bold">
                    [{idx}]
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Live Metrics Overlay */}
        <div className="mt-4 pt-3 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
          <div className="flex items-center gap-4">
            <span className="text-slate-600">
              Total Comparisons: <strong className="text-blue-700 text-sm font-bold">{currentStep.comparisons}</strong>
            </span>
            <span className="text-slate-600">
              Total Swaps / Shifts: <strong className="text-emerald-700 text-sm font-bold">{currentStep.swaps}</strong>
            </span>
          </div>

          <span className="font-bold text-slate-700 bg-white px-3 py-1 rounded-lg border border-slate-200">
            Array Size N = {displayArray.length}
          </span>
        </div>
      </div>

      {/* Step Description Narration */}
      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 mb-6">
        <div className="flex items-center justify-between mb-2 text-xs font-bold text-slate-600">
          <span>STEP {currentStepIndex} OF {Math.max(0, steps.length - 1)} NARRATION:</span>
          <span className="font-mono text-blue-700 font-bold uppercase">
            Active: {sortType} sort
          </span>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-3.5 text-xs sm:text-sm font-mono text-slate-800 leading-relaxed font-semibold">
          {currentStep.description}
        </div>
      </div>

      {/* ========================================================
          ALGORITHM CODE & PSEUDOCODE DISPLAY BELOW THE CHART
          ======================================================== */}
      <div className="bg-slate-900 text-slate-100 rounded-2xl p-5 mb-6 shadow-sm border border-slate-800">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
          <div className="flex items-center gap-2">
            <Code2 className="w-4 h-4 text-blue-400" />
            <h4 className="font-mono font-bold text-xs uppercase text-blue-400 tracking-wider">
              {currentAlgo.title} • Algorithm Implementation
            </h4>
          </div>

          <button
            onClick={handleCopyCode}
            className="flex items-center gap-1 text-[11px] font-mono font-bold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 px-3 py-1 rounded-lg transition-colors"
          >
            {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedCode ? 'Copied!' : 'Copy Code'}</span>
          </button>
        </div>

        <pre className="font-mono text-xs sm:text-sm text-slate-200 overflow-x-auto leading-relaxed p-2 no-scrollbar">
          <code>{currentAlgo.code}</code>
        </pre>
      </div>

      {/* ========================================================
          FULL ANSWER BOX (CLICKED INSTANT SORT OR SORTED COMPLETE)
          ======================================================== */}
      {isSorted && (
        <div className="rounded-3xl border-2 border-emerald-400 bg-emerald-50/90 p-6 sm:p-8 animate-in fade-in shadow-xs text-emerald-950">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-emerald-200 pb-4 mb-4 gap-2">
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-6 h-6 text-emerald-600" />
              <h3 className="font-extrabold text-lg sm:text-xl">
                {currentAlgo.title.toUpperCase()} — FULL ANSWER & VERIFICATION
              </h3>
            </div>

            <span className="text-xs font-mono font-bold bg-white text-emerald-800 px-3 py-1 rounded-lg border border-emerald-300 self-start sm:self-auto">
              Completed in {steps.length - 1} Steps
            </span>
          </div>

          <p className="text-sm font-semibold mb-5 leading-relaxed text-slate-800">
            The array has been verified and fully sorted in ascending order. Every number has settled into its correct index position!
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs font-mono mb-6">
            <div className="bg-white p-3.5 rounded-2xl border border-emerald-200 shadow-2xs">
              <span className="text-slate-500 block text-[10px] uppercase font-bold">TOTAL COMPARISONS</span>
              <strong className="text-slate-900 text-base">{currentStep.comparisons}</strong>
            </div>

            <div className="bg-white p-3.5 rounded-2xl border border-emerald-200 shadow-2xs">
              <span className="text-slate-500 block text-[10px] uppercase font-bold">TOTAL SWAPS / SHIFTS</span>
              <strong className="text-emerald-700 text-base">{currentStep.swaps}</strong>
            </div>

            <div className="bg-white p-3.5 rounded-2xl border border-emerald-200 shadow-2xs">
              <span className="text-slate-500 block text-[10px] uppercase font-bold">TIME COMPLEXITY</span>
              <strong className="text-blue-700 text-base">{currentAlgo.time.split(' ')[0]}</strong>
            </div>

            <div className="bg-white p-3.5 rounded-2xl border border-emerald-200 shadow-2xs">
              <span className="text-slate-500 block text-[10px] uppercase font-bold">SPACE COMPLEXITY</span>
              <strong className="text-slate-900 text-base">{currentAlgo.space.split(' ')[0]}</strong>
            </div>
          </div>

          {/* Initial vs Final Array */}
          <div className="bg-white border border-emerald-200 rounded-2xl p-4 space-y-2 font-mono text-xs">
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-500 w-28 shrink-0">Original Input:</span>
              <span className="text-slate-700 font-semibold bg-slate-100 px-2 py-0.5 rounded">
                [{array.join(', ')}]
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-emerald-800 w-28 shrink-0">Sorted Result:</span>
              <span className="text-emerald-900 font-extrabold bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded">
                [{displayArray.join(', ')}]
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
