export type Language = 'en' | 'ta' | 'hi';

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
  preferredLanguage: Language;
  xp: number;
  level: number;
  createdAt: string;
}

export interface Station {
  id: string;
  name: string;
  code: string;
  city: string;
  state: string;
  x: number;
  y: number;
}

export interface TrainClassConfig {
  type: '1A' | '2A' | '3A' | 'SL';
  name: string;
  totalSeats: number;
  fare: number;
  availableSeats?: number;
  bookedSeats?: number;
  isWaitingList?: boolean;
  waitingCount?: number;
}

export interface Train {
  id: string;
  trainNumber: string;
  name: string;
  sourceStationId: string;
  destinationStationId: string;
  intermediateStations: string[];
  departureTime: string;
  arrivalTime: string;
  duration: string;
  runsOn: string[];
  classes: TrainClassConfig[];
  classAvailabilities?: TrainClassConfig[];
}

export interface Passenger {
  name: string;
  age: number;
  gender: 'M' | 'F' | 'O';
  berthPreference?: string;
  allocatedSeat?: string;
  allocatedBerth?: string;
}

export interface Booking {
  id: string;
  pnr: string;
  userId: string;
  userEmail: string;
  userName: string;
  trainId: string;
  trainNumber: string;
  trainName: string;
  fromStationCode: string;
  toStationCode: string;
  journeyDate: string;
  travelClass: '1A' | '2A' | '3A' | 'SL';
  passengers: Passenger[];
  status: 'CONFIRMED' | 'CANCELLED' | 'WAITING';
  waitingNumber?: number;
  totalFare: number;
  createdAt: string;
  cancellationDate?: string;
}

export interface DSAEvent {
  id: string;
  type: 'QUEUE_ENQUEUE' | 'QUEUE_DEQUEUE' | 'HASH_LOOKUP' | 'GRAPH_PATHFIND' | 'STACK_PUSH' | 'STACK_POP' | 'PRIORITY_PROCESS' | 'SEAT_ALLOCATED' | 'SEAT_RELEASED';
  title: string;
  operation: string;
  principle: string;
  complexity: string;
  spaceComplexity: string;
  railwayUse: string;
  details: string;
  timestamp: string;
  meta?: any;
}

export interface HashLookupResult {
  booking: Booking | null;
  hashDetails: {
    pnr: string;
    numBuckets: number;
    bucketIndex: number;
    hashFunctionFormula: string;
    rawHashValue: number;
    chainDepth: number;
    lookupComplexity: string;
    isMatch: boolean;
    allBuckets: { index: number; count: number; activePnr?: string }[];
  };
  dsaEvent: DSAEvent;
}

export interface GraphTraversalResponse {
  algorithm: 'bfs' | 'dfs';
  startStation: Station;
  targetStation: Station | null;
  visitedOrder: string[];
  visitedStations: Station[];
  path: string[];
  pathStations: Station[];
  steps: { current: string; queueState?: string[]; stackState?: string[]; exploredEdges: [string, string][] }[];
  radiumHighlightColor: string;
}

export interface DSATopicContent {
  id: string;
  name: string;
  shortTag: string;
  timeComplexity: string;
  spaceComplexity: string;
  railwayFeature: string;
  // Multilingual explanations
  translations: {
    [key in Language]: {
      definition: string;
      whyUsed: string;
      whatHappensIfNotUsed: string;
      railwayAnalogy: string;
    };
  };
}

export interface GameChallenge {
  id: string;
  level: number;
  levelTitle: { [key in Language]: string };
  scenario: { [key in Language]: string };
  question: { [key in Language]: string };
  options: {
    id: string;
    label: { [key in Language]: string };
    isCorrect: boolean;
    explanation: { [key in Language]: string };
  }[];
  hint: { [key in Language]: string };
  dsaConcept: string;
  complexity: string;
}
