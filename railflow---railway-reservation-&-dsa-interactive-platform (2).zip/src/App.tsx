/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AuthProvider } from './context/AuthContext';
import { LanguageProvider } from './context/LanguageContext';
import { AIModalProvider, useAIModal } from './context/AIModalContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { AIGuideDrawer } from './components/AIGuideDrawer';

import { HomePage } from './pages/HomePage';
import { TrainsPage } from './pages/TrainsPage';
import { BookPage } from './pages/BookPage';
import { MyTicketsPage } from './pages/MyTicketsPage';
import { PNRStatusPage } from './pages/PNRStatusPage';
import { DSALabPage } from './pages/DSALabPage';
import { BarChartLabPage } from './pages/BarChartLabPage';
import { DSAGamePage } from './pages/DSAGamePage';
import { SimulationPage } from './pages/SimulationPage';
import { PresentationPage } from './pages/PresentationPage';
import { DashboardPage } from './pages/DashboardPage';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { Bot, Sparkles } from 'lucide-react';

const FloatingAILauncher: React.FC = () => {
  const { openAI, isOpen } = useAIModal();

  if (isOpen) return null;

  return (
    <button
      onClick={() => openAI()}
      className="fixed bottom-6 right-6 z-40 flex items-center gap-2.5 px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-2xl shadow-lg shadow-blue-600/30 hover:scale-105 transition-all group border border-blue-400"
      aria-label="Open RailFlow AI Guide"
    >
      <div className="relative">
        <Bot className="w-5 h-5 text-white" />
        <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
        <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400" />
      </div>
      <span className="text-xs tracking-wide">AI Guide & Mentor</span>
      <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-spin" />
    </button>
  );
};

function MainAppContent() {
  const [currentPath, setCurrentPath] = useState<string>(() => {
    return window.location.pathname || '/';
  });
  const [navState, setNavState] = useState<any>(null);

  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (path: string, state?: any) => {
    setCurrentPath(path);
    setNavState(state || null);
    window.history.pushState(state || {}, '', path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderPage = () => {
    switch (currentPath) {
      case '/':
        return <HomePage onNavigate={navigate} />;
      case '/trains':
        return <TrainsPage onNavigate={navigate} />;
      case '/book':
        return (
          <BookPage
            train={navState?.train}
            journeyDate={navState?.journeyDate}
            travelClass={navState?.travelClass}
            selectedClassConfig={navState?.selectedClassConfig}
            onNavigate={navigate}
          />
        );
      case '/my-tickets':
        return <MyTicketsPage onNavigate={navigate} />;
      case '/pnr':
        return <PNRStatusPage initialPnr={navState?.pnr} onNavigate={navigate} />;
      case '/dsa-lab':
        return <DSALabPage />;
      case '/barchart':
      case '/barchart-lab':
        return <BarChartLabPage onNavigate={navigate} />;
      case '/dsa-game':
        return <DSAGamePage onNavigate={navigate} />;
      case '/simulation':
        return <SimulationPage />;
      case '/presentation':
        return <PresentationPage />;
      case '/dashboard':
        return <DashboardPage onNavigate={navigate} />;
      case '/login':
        return <LoginPage onNavigate={navigate} />;
      case '/register':
        return <RegisterPage onNavigate={navigate} />;
      default:
        return <HomePage onNavigate={navigate} />;
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#F8FAFC] text-slate-800 selection:bg-blue-600 selection:text-white">
      <Navbar currentPath={currentPath} onNavigate={navigate} />
      <main className="flex-1">{renderPage()}</main>
      <Footer onNavigate={navigate} />
      <AIGuideDrawer />
      <FloatingAILauncher />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <LanguageProvider>
        <AIModalProvider>
          <MainAppContent />
        </AIModalProvider>
      </LanguageProvider>
    </AuthProvider>
  );
}
