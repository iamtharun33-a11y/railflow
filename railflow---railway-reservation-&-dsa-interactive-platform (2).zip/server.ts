import express, { Request, Response, NextFunction } from 'express';
import cookieParser from 'cookie-parser';
import crypto from 'crypto';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { db } from './server/db.js';
import { RailwayGraph } from './server/dsa-engine.js';

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());
app.use(cookieParser('railflow-secret-signing-key'));

// Initialize Gemini Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build'
    }
  }
});

// Build In-memory Railway Graph for Graph Lab & Route calculations
const railwayGraph = new RailwayGraph();
const stations = db.getStations();
stations.forEach((s) => {
  railwayGraph.addNode({ id: s.id, name: s.name, code: s.code, x: s.x, y: s.y });
});

// Add realistic railway connections between hubs
const edges: [string, string, number, number][] = [
  ['st_ndls', 'st_adi', 930, 720],
  ['st_adi', 'st_bct', 490, 360],
  ['st_ndls', 'st_bct', 1380, 940],
  ['st_ndls', 'st_pnbe', 1000, 740],
  ['st_pnbe', 'st_hwh', 530, 480],
  ['st_ndls', 'st_sc', 1660, 1320],
  ['st_sc', 'st_mas', 700, 660],
  ['st_sc', 'st_sbc', 620, 600],
  ['st_mas', 'st_sbc', 360, 265],
  ['st_hwh', 'st_sc', 1540, 1400],
  ['st_hwh', 'st_sbc', 1950, 1745],
  ['st_mas', 'st_cbe', 500, 420],
  ['st_cbe', 'st_mdu', 220, 200],
  ['st_mas', 'st_mdu', 490, 460]
];
edges.forEach(([u, v, dist, dur]) => {
  railwayGraph.addEdge(u, v, dist, dur, true);
});

// --- Password Hashing Utilities ---
function hashPassword(password: string): string {
  const salt = 'railflow_salt_2026';
  return crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
}

// --- Auth Middleware ---
interface AuthenticatedRequest extends Request {
  user?: ReturnType<typeof db.findUserById>;
}

function authMiddleware(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  let token = req.cookies?.railflow_token;

  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.substring(7);
  }

  if (token) {
    const user = db.findUserById(token);
    if (user) {
      req.user = user;
    }
  }
  next();
}

app.use(authMiddleware);

// ==========================================
// API ROUTES
// ==========================================

// --- Auth Routes ---
app.post('/api/auth/register', (req: Request, res: Response) => {
  try {
    const { name, email, password, confirmPassword, preferredLanguage } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Please provide all required fields' });
    }
    if (password !== confirmPassword) {
      return res.status(400).json({ error: 'Passwords do not match' });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }

    const existing = db.findUserByEmail(email);
    if (existing) {
      return res.status(400).json({ error: 'An account with this email already exists' });
    }

    const passwordHash = hashPassword(password);
    const user = db.createUser({
      name: name.trim(),
      email: email.trim().toLowerCase(),
      passwordHash,
      role: 'user',
      preferredLanguage: preferredLanguage || 'en'
    });

    res.cookie('railflow_token', user.id, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000
    });

    const { passwordHash: _, ...safeUser } = user;
    return res.json({ user: safeUser, token: user.id });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Registration failed' });
  }
});

app.post('/api/auth/login', (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    const user = db.findUserByEmail(email);
    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const hashed = hashPassword(password);
    if (user.passwordHash !== hashed) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    res.cookie('railflow_token', user.id, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000
    });

    const { passwordHash: _, ...safeUser } = user;
    return res.json({ user: safeUser, token: user.id });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Login failed' });
  }
});

app.get('/api/auth/me', (req: AuthenticatedRequest, res: Response) => {
  if (!req.user) {
    return res.json({ user: null });
  }
  const { passwordHash: _, ...safeUser } = req.user;
  const achievements = db.getUserAchievements(req.user.id);
  const stats = db.getUserGameStats(req.user.id);
  return res.json({ user: safeUser, achievements, stats });
});

app.post('/api/auth/logout', (req: Request, res: Response) => {
  res.clearCookie('railflow_token');
  return res.json({ success: true });
});

app.put('/api/auth/profile', (req: AuthenticatedRequest, res: Response) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  const { name, preferredLanguage } = req.body;
  const updated = db.updateUserProfile(req.user.id, {
    ...(name ? { name: name.trim() } : {}),
    ...(preferredLanguage ? { preferredLanguage } : {})
  });
  if (!updated) return res.status(404).json({ error: 'User not found' });
  const { passwordHash: _, ...safeUser } = updated;
  return res.json({ user: safeUser });
});

// --- Station & Train Routes ---
app.get('/api/stations', (req: Request, res: Response) => {
  return res.json({ stations: db.getStations() });
});

app.get('/api/trains', (req: Request, res: Response) => {
  const { from, to, date } = req.query;
  const trains = db.getTrains(from as string, to as string);

  // Compute availability for each train if date provided
  const journeyDate = (date as string) || new Date().toISOString().split('T')[0];
  const enhancedTrains = trains.map((t) => {
    const classAvailabilities = t.classes.map((cls) => {
      try {
        const avail = db.getSeatAvailability(t.id, journeyDate, cls.type);
        return {
          classType: cls.type,
          className: cls.name,
          fare: cls.fare,
          totalSeats: avail.totalSeats,
          availableSeats: avail.availableSeats,
          bookedSeats: avail.bookedSeats,
          isWaitingList: avail.isWaitingList,
          waitingCount: avail.currentWaitingCount
        };
      } catch (e) {
        return {
          classType: cls.type,
          className: cls.name,
          fare: cls.fare,
          totalSeats: cls.totalSeats,
          availableSeats: cls.totalSeats,
          bookedSeats: 0,
          isWaitingList: false,
          waitingCount: 0
        };
      }
    });

    return {
      ...t,
      classAvailabilities
    };
  });

  return res.json({ trains: enhancedTrains });
});

app.get('/api/trains/:id', (req: Request, res: Response) => {
  const train = db.getTrainById(req.params.id);
  if (!train) return res.status(404).json({ error: 'Train not found' });
  const date = (req.query.date as string) || new Date().toISOString().split('T')[0];

  const classAvailabilities = train.classes.map((cls) => {
    const avail = db.getSeatAvailability(train.id, date, cls.type);
    return {
      ...cls,
      ...avail
    };
  });

  return res.json({ train: { ...train, classAvailabilities } });
});

// --- Bookings & Real Waiting List Enqueue ---
app.post('/api/bookings', (req: AuthenticatedRequest, res: Response) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Please login or register to book a ticket' });
  }

  try {
    const { trainId, journeyDate, travelClass, passengers } = req.body;
    if (!trainId || !journeyDate || !travelClass || !passengers || passengers.length === 0) {
      return res.status(400).json({ error: 'Missing required booking details' });
    }

    const result = db.createBooking({
      userId: req.user.id,
      trainId,
      journeyDate,
      travelClass,
      passengers
    });

    return res.status(201).json(result);
  } catch (err: any) {
    return res.status(400).json({ error: err.message || 'Booking failed' });
  }
});

app.get('/api/bookings/my', (req: AuthenticatedRequest, res: Response) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  const bookings = db.getUserBookings(req.user.id);
  return res.json({ bookings });
});

// --- PNR Status with Real Hash Map Lookup & Bucket Details ---
app.get('/api/bookings/pnr/:pnr', (req: Request, res: Response) => {
  const pnr = req.params.pnr;
  if (!pnr) {
    return res.status(400).json({ error: 'PNR number required' });
  }

  const lookupResult = db.getBookingByPNR(pnr);
  return res.json(lookupResult);
});

// --- Cancellation with Real FIFO Queue Dequeue & Promotion ---
app.post('/api/bookings/:id/cancel', (req: AuthenticatedRequest, res: Response) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    const bookingId = req.params.id;
    const result = db.cancelBooking(bookingId, req.user.id);
    return res.json(result);
  } catch (err: any) {
    return res.status(400).json({ error: err.message || 'Cancellation failed' });
  }
});

// --- Graph Traversal (BFS & DFS) with Radium Green Traversal Highlights ---
app.post('/api/graph/traverse', (req: Request, res: Response) => {
  const { algorithm, fromStationId, toStationId } = req.body;
  const startId = fromStationId || 'st_ndls';
  const targetId = toStationId || undefined;

  let result;
  if (algorithm === 'dfs') {
    result = railwayGraph.dfs(startId, targetId);
  } else {
    result = railwayGraph.bfs(startId, targetId);
  }

  // Map station details
  const visitedStations = result.visitedOrder.map((id) => db.getStations().find((s) => s.id === id));
  const pathStations = result.path.map((id) => db.getStations().find((s) => s.id === id));

  return res.json({
    algorithm: algorithm || 'bfs',
    startStation: db.getStations().find((s) => s.id === startId),
    targetStation: targetId ? db.getStations().find((s) => s.id === targetId) : null,
    visitedOrder: result.visitedOrder,
    visitedStations,
    path: result.path,
    pathStations,
    steps: result.steps,
    radiumHighlightColor: result.radiumHighlightColor // Radium Green: '#00FF66'
  });
});

// --- System DSA Events Stream ---
app.get('/api/dsa/events', (req: Request, res: Response) => {
  const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 25;
  const events = db.getDSAEvents(limit);
  return res.json({ events });
});

// --- Game Challenge Submission & XP ---
app.post('/api/game/submit', (req: AuthenticatedRequest, res: Response) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Please login to track score and achievements' });
  }

  const { level, challengeId, selectedOption, isCorrect, score, xpEarned, language } = req.body;
  const result = db.recordGameAttempt({
    userId: req.user.id,
    level,
    challengeId,
    selectedOption,
    isCorrect,
    score,
    xpEarned: isCorrect ? xpEarned || 100 : 0,
    language: language || req.user.preferredLanguage || 'en'
  });

  return res.json(result);
});

// --- Admin System Metrics (Real Data Only) ---
app.get('/api/admin/metrics', (req: AuthenticatedRequest, res: Response) => {
  const metrics = db.getSystemMetrics();
  return res.json({ metrics });
});

// ==========================================
// REAL GEMINI AI GUIDE & MENTOR (gemini-3.8-flash)
// ==========================================
app.post('/api/ai/guide', async (req: Request, res: Response) => {
  const { prompt, language = 'en', context } = req.body;

  if (!prompt || typeof prompt !== 'string') {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  const langInstruction =
    language === 'ta'
      ? 'Respond primarily in natural, helpful Tamil (தமிழ்) mixed with standard technical English keywords (like Queue, FIFO, Hash Map, BFS, Radium Green) for high clarity.'
      : language === 'hi'
      ? 'Respond primarily in natural, clear Hindi (हिन्दी) mixed with standard technical English keywords (Queue, FIFO, Hash Map, Graph) for high clarity.'
      : 'Respond in concise, highly encouraging, crystal clear English.';

  const systemInstruction = `You are "RailFlow AI Mentor", the intelligent railway reservation and Data Structures & Algorithms (DSA) guide built inside RailFlow.
Your mission is to guide users to understand how railway reservation systems (waiting lists, PNR lookups, shortest routes, ticket cancellations) are powered by real data structures:
- Queue (FIFO): Waiting list management, enqueue when full, dequeue and promotion on cancellation.
- Hash Map: Instant O(1) PNR ticket lookup via polynomial hashing and bucket chaining.
- Graph (BFS/DFS): Railway routes, station vertices, track edges, illuminated with glowing Radium Green BFS shortest hops and DFS deep exploration.
- Stack (LIFO): Cancellation and undo action history.
- Priority Queue: VIP / Tatkal quota emergency processing.
- Binary Search (Bar Chart Method): O(log N) divide-and-conquer interval searching with low/mid/high pointers and half elimination.
- Sorting Algorithms: Bubble Sort (adjacent swaps), Selection Sort (finding minimums), and Insertion Sort (in-place sub-array positioning) in Bar Chart visualization.
- Linked List (Coach Chain): Shunting dynamic train coaches at Start (Head), Middle (between coaches), and Last (Tail) with pointer reassignments.

Rules:
1. ${langInstruction}
2. Explain clearly with real railway analogies.
3. Be friendly, accurate, and educational.
4. Keep answers focused, engaging, and under 250 words unless asked for an in-depth breakdown.`;

  try {
    const aiResponse = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `Context: ${context || 'User exploring RailFlow reservation & DSA platform'}\nUser Question: ${prompt}`,
      config: {
        systemInstruction,
        temperature: 0.7
      }
    });

    return res.json({
      reply: aiResponse.text || 'I am ready to help you explore railway algorithms!',
      model: 'gemini-3.8-flash'
    });
  } catch (error: any) {
    console.error('Gemini AI Guide error:', error);
    // Graceful helpful fallback if API key or network has temporary hiccup
    let fallbackReply = `I am your RailFlow AI Guide! In RailFlow:
1. Waiting List = Queue (FIFO: First-In-First-Out).
2. PNR Status = Hash Map (average O(1) lookup).
3. Railway Route = Graph (Breadth-First Search illuminated in glowing Radium Green to find fewest station hops).
4. Cancellation = Stack (LIFO: Last-In-First-Out).`;

    if (language === 'ta') {
      fallbackReply = `வணக்கம்! நான் உங்கள் RailFlow AI Guide. 
1. Waiting List = Queue (FIFO - முதலில் வருபவருக்கு முன்னுரிமை).
2. PNR Status = Hash Map (நேரடி O(1) lookup).
3. Railway Route = Graph (Radium Green ஒளிரும் BFS மூலம் குறைவான நிறுத்தங்கள் கொண்ட பாதையைக் கண்டுபிடிக்கும்).
4. Cancellation = Stack (LIFO).`;
    }

    return res.json({
      reply: fallbackReply,
      model: 'fallback-rules'
    });
  }
});

// ==========================================
// VITE DEV MIDDLEWARE / STATIC ASSETS
// ==========================================
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(process.cwd(), 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(process.cwd(), 'dist/index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚂 RailFlow Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
