/**
 * Real Data Structure Implementations used across RailFlow simulations and educational labs
 */

// 1. Queue (FIFO) - Waiting List Management
export class Queue<T> {
  private items: T[] = [];

  enqueue(item: T): void {
    this.items.push(item);
  }

  dequeue(): T | undefined {
    return this.items.shift();
  }

  peek(): T | undefined {
    return this.items[0];
  }

  isEmpty(): boolean {
    return this.items.length === 0;
  }

  size(): number {
    return this.items.length;
  }

  clear(): void {
    this.items = [];
  }

  toArray(): T[] {
    return [...this.items];
  }
}

// 2. Stack (LIFO) - Cancellation & Undo Action History
export class Stack<T> {
  private items: T[] = [];

  push(item: T): void {
    this.items.push(item);
  }

  pop(): T | undefined {
    return this.items.pop();
  }

  peek(): T | undefined {
    return this.items[this.items.length - 1];
  }

  isEmpty(): boolean {
    return this.items.length === 0;
  }

  size(): number {
    return this.items.length;
  }

  clear(): void {
    this.items = [];
  }

  toArray(): T[] {
    return [...this.items].reverse();
  }
}

// 3. Linked List - Dynamic Passenger Coach Sequencing
export class ListNode<T> {
  value: T;
  next: ListNode<T> | null = null;

  constructor(value: T) {
    this.value = value;
  }
}

export class LinkedList<T> {
  head: ListNode<T> | null = null;
  private count = 0;

  insertEnd(value: T): void {
    const node = new ListNode(value);
    if (!this.head) {
      this.head = node;
    } else {
      let curr = this.head;
      while (curr.next) {
        curr = curr.next;
      }
      curr.next = node;
    }
    this.count++;
  }

  insertFront(value: T): void {
    const node = new ListNode(value);
    node.next = this.head;
    this.head = node;
    this.count++;
  }

  delete(predicate: (val: T) => boolean): boolean {
    if (!this.head) return false;
    if (predicate(this.head.value)) {
      this.head = this.head.next;
      this.count--;
      return true;
    }
    let curr = this.head;
    while (curr.next && !predicate(curr.next.value)) {
      curr = curr.next;
    }
    if (curr.next) {
      curr.next = curr.next.next;
      this.count--;
      return true;
    }
    return false;
  }

  toArray(): T[] {
    const arr: T[] = [];
    let curr = this.head;
    while (curr) {
      arr.push(curr.value);
      curr = curr.next;
    }
    return arr;
  }

  size(): number {
    return this.count;
  }
}

// 4. Hash Map - Instant O(1) PNR Ticket Lookup
export class HashMap<K extends string | number, V> {
  private buckets: Array<Array<{ key: K; value: V }>>;
  private capacity: number;
  private size = 0;

  constructor(capacity = 16) {
    this.capacity = capacity;
    this.buckets = Array.from({ length: capacity }, () => []);
  }

  private hash(key: K): number {
    const str = String(key);
    let hashVal = 0;
    const PRIME = 31;
    for (let i = 0; i < str.length; i++) {
      hashVal = (hashVal * PRIME + str.charCodeAt(i)) % 1000000007;
    }
    return Math.abs(hashVal) % this.capacity;
  }

  put(key: K, value: V): { bucketIndex: number; chainLength: number } {
    const idx = this.hash(key);
    const bucket = this.buckets[idx];
    const existing = bucket.find((entry) => entry.key === key);
    if (existing) {
      existing.value = value;
    } else {
      bucket.push({ key, value });
      this.size++;
    }
    return { bucketIndex: idx, chainLength: bucket.length };
  }

  get(key: K): { value: V | undefined; bucketIndex: number; probes: number } {
    const idx = this.hash(key);
    const bucket = this.buckets[idx];
    let probes = 0;
    for (const item of bucket) {
      probes++;
      if (item.key === key) {
        return { value: item.value, bucketIndex: idx, probes };
      }
    }
    return { value: undefined, bucketIndex: idx, probes };
  }

  getDistribution(): { bucketIndex: number; count: number; keys: K[] }[] {
    return this.buckets.map((b, idx) => ({
      bucketIndex: idx,
      count: b.length,
      keys: b.map((item) => item.key)
    }));
  }
}

// 5. Graph - Railway Network Routes with Radium Green BFS & DFS
export interface GraphNode {
  id: string;
  name: string;
  code: string;
  x: number;
  y: number;
}

export interface GraphEdge {
  from: string;
  to: string;
  distanceKm: number;
  durationMins: number;
}

export class RailwayGraph {
  nodes: Map<string, GraphNode> = new Map();
  adjacencyList: Map<string, Array<{ to: string; distance: number; duration: number }>> = new Map();

  addNode(node: GraphNode): void {
    this.nodes.set(node.id, node);
    if (!this.adjacencyList.has(node.id)) {
      this.adjacencyList.set(node.id, []);
    }
  }

  addEdge(from: string, to: string, distance: number, duration: number, bidirectional = true): void {
    if (!this.adjacencyList.has(from)) this.adjacencyList.set(from, []);
    if (!this.adjacencyList.has(to)) this.adjacencyList.set(to, []);

    this.adjacencyList.get(from)!.push({ to, distance, duration });
    if (bidirectional) {
      this.adjacencyList.get(to)!.push({ to: from, distance, duration });
    }
  }

  // Breadth-First Search (BFS): Finds fewest station hops
  bfs(startId: string, targetId?: string): {
    visitedOrder: string[];
    path: string[];
    steps: { current: string; queueState: string[]; exploredEdges: [string, string][] }[];
    radiumHighlightColor: string;
  } {
    const visited = new Set<string>();
    const queue: string[] = [startId];
    const parent = new Map<string, string>();
    const visitedOrder: string[] = [];
    const steps: { current: string; queueState: string[]; exploredEdges: [string, string][] }[] = [];
    const exploredEdges: [string, string][] = [];

    visited.add(startId);

    while (queue.length > 0) {
      const current = queue.shift()!;
      visitedOrder.push(current);

      steps.push({
        current,
        queueState: [...queue],
        exploredEdges: [...exploredEdges]
      });

      if (targetId && current === targetId) break;

      const neighbors = this.adjacencyList.get(current) || [];
      for (const n of neighbors) {
        if (!visited.has(n.to)) {
          visited.add(n.to);
          parent.set(n.to, current);
          exploredEdges.push([current, n.to]);
          queue.push(n.to);
        }
      }
    }

    // Reconstruct path
    const path: string[] = [];
    if (targetId && visited.has(targetId)) {
      let curr: string | undefined = targetId;
      while (curr) {
        path.unshift(curr);
        curr = parent.get(curr);
      }
    }

    return {
      visitedOrder,
      path: path.length > 0 ? path : visitedOrder,
      steps,
      radiumHighlightColor: '#00FF66' // Radium neon green specified in user requirement
    };
  }

  // Depth-First Search (DFS): Deep railway branch exploration
  dfs(startId: string, targetId?: string): {
    visitedOrder: string[];
    path: string[];
    steps: { current: string; stackState: string[]; exploredEdges: [string, string][] }[];
    radiumHighlightColor: string;
  } {
    const visited = new Set<string>();
    const stack: string[] = [startId];
    const parent = new Map<string, string>();
    const visitedOrder: string[] = [];
    const steps: { current: string; stackState: string[]; exploredEdges: [string, string][] }[] = [];
    const exploredEdges: [string, string][] = [];

    while (stack.length > 0) {
      const current = stack.pop()!;
      if (!visited.has(current)) {
        visited.add(current);
        visitedOrder.push(current);

        steps.push({
          current,
          stackState: [...stack],
          exploredEdges: [...exploredEdges]
        });

        if (targetId && current === targetId) break;

        const neighbors = this.adjacencyList.get(current) || [];
        for (const n of neighbors) {
          if (!visited.has(n.to)) {
            parent.set(n.to, current);
            exploredEdges.push([current, n.to]);
            stack.push(n.to);
          }
        }
      }
    }

    const path: string[] = [];
    if (targetId && visited.has(targetId)) {
      let curr: string | undefined = targetId;
      while (curr) {
        path.unshift(curr);
        curr = parent.get(curr);
      }
    }

    return {
      visitedOrder,
      path: path.length > 0 ? path : visitedOrder,
      steps,
      radiumHighlightColor: '#00FF66' // Radium neon green
    };
  }
}
