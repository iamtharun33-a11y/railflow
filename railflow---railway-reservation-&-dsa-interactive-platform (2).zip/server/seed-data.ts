export interface Station {
  id: string;
  name: string;
  code: string;
  city: string;
  state: string;
  x: number; // for 2D railway network visualizer (0-100 scale)
  y: number;
}

export interface TrainClassConfig {
  type: '1A' | '2A' | '3A' | 'SL';
  name: string;
  totalSeats: number;
  fare: number;
}

export interface Train {
  id: string;
  trainNumber: string;
  name: string;
  sourceStationId: string;
  destinationStationId: string;
  intermediateStations: string[]; // station IDs in order
  departureTime: string;
  arrivalTime: string;
  duration: string;
  runsOn: string[];
  classes: TrainClassConfig[];
}

export const INITIAL_STATIONS: Station[] = [
  { id: 'st_ndls', name: 'New Delhi', code: 'NDLS', city: 'Delhi', state: 'Delhi', x: 42, y: 18 },
  { id: 'st_bct', name: 'Mumbai Central', code: 'BCT', city: 'Mumbai', state: 'Maharashtra', x: 22, y: 62 },
  { id: 'st_mas', name: 'Chennai Central', code: 'MAS', city: 'Chennai', state: 'Tamil Nadu', x: 55, y: 84 },
  { id: 'st_sbc', name: 'KSR Bengaluru', code: 'SBC', city: 'Bengaluru', state: 'Karnataka', x: 45, y: 86 },
  { id: 'st_hwh', name: 'Howrah Junction', code: 'HWH', city: 'Kolkata', state: 'West Bengal', x: 80, y: 44 },
  { id: 'st_sc', name: 'Secunderabad', code: 'SC', city: 'Hyderabad', state: 'Telangana', x: 48, y: 64 },
  { id: 'st_pnbe', name: 'Patna Junction', code: 'PNBE', city: 'Patna', state: 'Bihar', x: 68, y: 35 },
  { id: 'st_adi', name: 'Ahmedabad Junction', code: 'ADI', city: 'Ahmedabad', state: 'Gujarat', x: 25, y: 45 },
  { id: 'st_cbe', name: 'Coimbatore Junction', code: 'CBE', city: 'Coimbatore', state: 'Tamil Nadu', x: 43, y: 92 },
  { id: 'st_mdu', name: 'Madurai Junction', code: 'MDU', city: 'Madurai', state: 'Tamil Nadu', x: 47, y: 95 }
];

export const INITIAL_TRAINS: Train[] = [
  {
    id: 'tr_20607',
    trainNumber: '20607',
    name: 'Vande Bharat Express',
    sourceStationId: 'st_mas',
    destinationStationId: 'st_sbc',
    intermediateStations: ['st_mas', 'st_sbc'],
    departureTime: '05:50',
    arrivalTime: '10:15',
    duration: '4h 25m',
    runsOn: ['Mon', 'Tue', 'Wed', 'Fri', 'Sat', 'Sun'],
    classes: [
      { type: '1A', name: 'Executive Chair (EC)', totalSeats: 8, fare: 1950 },
      { type: '3A', name: 'AC Chair (CC)', totalSeats: 16, fare: 995 }
    ]
  },
  {
    id: 'tr_12952',
    trainNumber: '12952',
    name: 'Mumbai Rajdhani Express',
    sourceStationId: 'st_ndls',
    destinationStationId: 'st_bct',
    intermediateStations: ['st_ndls', 'st_adi', 'st_bct'],
    departureTime: '16:55',
    arrivalTime: '08:35',
    duration: '15h 40m',
    runsOn: ['Daily'],
    classes: [
      { type: '1A', name: 'AC First Class', totalSeats: 6, fare: 4750 },
      { type: '2A', name: 'AC 2-Tier', totalSeats: 12, fare: 2890 },
      { type: '3A', name: 'AC 3-Tier', totalSeats: 18, fare: 2050 }
    ]
  },
  {
    id: 'tr_12622',
    trainNumber: '12622',
    name: 'Tamil Nadu Superfast Express',
    sourceStationId: 'st_ndls',
    destinationStationId: 'st_mas',
    intermediateStations: ['st_ndls', 'st_sc', 'st_mas'],
    departureTime: '21:05',
    arrivalTime: '06:15',
    duration: '33h 10m',
    runsOn: ['Daily'],
    classes: [
      { type: '2A', name: 'AC 2-Tier', totalSeats: 10, fare: 3250 },
      { type: '3A', name: 'AC 3-Tier', totalSeats: 18, fare: 2250 },
      { type: 'SL', name: 'Sleeper Class', totalSeats: 24, fare: 860 }
    ]
  },
  {
    id: 'tr_12245',
    trainNumber: '12245',
    name: 'Howrah - SMVT Duronto Express',
    sourceStationId: 'st_hwh',
    destinationStationId: 'st_sbc',
    intermediateStations: ['st_hwh', 'st_sc', 'st_sbc'],
    departureTime: '10:50',
    arrivalTime: '15:55',
    duration: '29h 05m',
    runsOn: ['Tue', 'Wed', 'Fri', 'Sun'],
    classes: [
      { type: '2A', name: 'AC 2-Tier', totalSeats: 10, fare: 3420 },
      { type: '3A', name: 'AC 3-Tier', totalSeats: 18, fare: 2380 },
      { type: 'SL', name: 'Sleeper Class', totalSeats: 20, fare: 910 }
    ]
  },
  {
    id: 'tr_12635',
    trainNumber: '12635',
    name: 'Vaigai Superfast Express',
    sourceStationId: 'st_mas',
    destinationStationId: 'st_mdu',
    intermediateStations: ['st_mas', 'st_cbe', 'st_mdu'],
    departureTime: '13:50',
    arrivalTime: '21:30',
    duration: '7h 40m',
    runsOn: ['Daily'],
    classes: [
      { type: '3A', name: 'AC Chair (CC)', totalSeats: 14, fare: 720 },
      { type: 'SL', name: 'Second Sitting (2S)', totalSeats: 28, fare: 210 }
    ]
  },
  {
    id: 'tr_12301',
    trainNumber: '12301',
    name: 'Kolkata Rajdhani Express',
    sourceStationId: 'st_hwh',
    destinationStationId: 'st_ndls',
    intermediateStations: ['st_hwh', 'st_pnbe', 'st_ndls'],
    departureTime: '16:50',
    arrivalTime: '10:05',
    duration: '17h 15m',
    runsOn: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    classes: [
      { type: '1A', name: 'AC First Class', totalSeats: 6, fare: 4890 },
      { type: '2A', name: 'AC 2-Tier', totalSeats: 12, fare: 2980 },
      { type: '3A', name: 'AC 3-Tier', totalSeats: 20, fare: 2110 }
    ]
  }
];
