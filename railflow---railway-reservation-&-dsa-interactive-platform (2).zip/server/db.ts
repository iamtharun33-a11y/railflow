import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { INITIAL_STATIONS, INITIAL_TRAINS, Station, Train } from './seed-data.js';

export interface User {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  role: 'user' | 'admin';
  preferredLanguage: 'en' | 'ta' | 'hi';
  xp: number;
  level: number;
  createdAt: string;
}

export interface Passenger {
  name: string;
  age: number;
  gender: 'M' | 'F' | 'O';
  berthPreference?: string;
  allocatedSeat?: string;
  allocatedBerth?: string;
}

export interface Booking {
  id: string;
  pnr: string;
  userId: string;
  userEmail: string;
  userName: string;
  trainId: string;
  trainNumber: string;
  trainName: string;
  fromStationCode: string;
  toStationCode: string;
  journeyDate: string;
  travelClass: '1A' | '2A' | '3A' | 'SL';
  passengers: Passenger[];
  status: 'CONFIRMED' | 'CANCELLED' | 'WAITING';
  waitingNumber?: number; // e.g. 1 for WL1
  totalFare: number;
  createdAt: string;
  cancellationDate?: string;
}

export interface WaitingListEntry {
  id: string;
  bookingId: string;
  pnr: string;
  trainId: string;
  journeyDate: string;
  travelClass: string;
  position: number;
  passengerNames: string[];
  createdAt: string;
}

export interface DSAEvent {
  id: string;
  type: 'QUEUE_ENQUEUE' | 'QUEUE_DEQUEUE' | 'HASH_LOOKUP' | 'GRAPH_PATHFIND' | 'STACK_PUSH' | 'STACK_POP' | 'PRIORITY_PROCESS' | 'SEAT_ALLOCATED' | 'SEAT_RELEASED';
  title: string;
  operation: string;
  principle: string;
  complexity: string;
  spaceComplexity: string;
  railwayUse: string;
  details: string;
  timestamp: string;
  meta?: any;
}

export interface UserAchievement {
  id: string;
  userId: string;
  achievementId: string;
  unlockedAt: string;
}

export interface GameAttempt {
  id: string;
  userId: string;
  level: number;
  challengeId: string;
  selectedOption: string;
  isCorrect: boolean;
  score: number;
  xpEarned: number;
  timestamp: string;
  language: string;
}

interface DatabaseSchema {
  users: User[];
  stations: Station[];
  trains: Train[];
  bookings: Booking[];
  waitingList: WaitingListEntry[];
  dsaEvents: DSAEvent[];
  achievements: UserAchievement[];
  gameAttempts: GameAttempt[];
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.resolve(DATA_DIR, 'railflow-db.json');

class DatabaseService {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.loadDatabase();
  }

  private loadDatabase(): DatabaseSchema {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }

    if (fs.existsSync(DB_FILE)) {
      try {
        const fileContent = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(fileContent);
        // Ensure stations and trains exist
        if (!parsed.stations || parsed.stations.length === 0) {
          parsed.stations = INITIAL_STATIONS;
        }
        if (!parsed.trains || parsed.trains.length === 0) {
          parsed.trains = INITIAL_TRAINS;
        }
        return parsed;
      } catch (e) {
        console.error('Failed to parse database file, re-initializing', e);
      }
    }

    // Default clean state: ZERO fake users, ZERO fake bookings, ZERO fake tickets
    const defaultData: DatabaseSchema = {
      users: [],
      stations: INITIAL_STATIONS,
      trains: INITIAL_TRAINS,
      bookings: [],
      waitingList: [],
      dsaEvents: [
        {
          id: 'ev_init',
          type: 'QUEUE_ENQUEUE',
          title: 'RailFlow Queue Engine Initialized',
          operation: 'Queue Init (FIFO)',
          principle: 'First In First Out Waiting Protocol',
          complexity: 'O(1)',
          spaceComplexity: 'O(N)',
          railwayUse: 'Waiting list fairness & ticket order preservation',
          details: 'Initial algorithm engine started with clean state.',
          timestamp: new Date().toISOString()
        }
      ],
      achievements: [],
      gameAttempts: []
    };

    this.saveData(defaultData);
    return defaultData;
  }

  private saveData(dataToSave?: DatabaseSchema) {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(DB_FILE, JSON.stringify(dataToSave || this.data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to persist database file', err);
    }
  }

  // --- Users & Auth ---
  public findUserByEmail(email: string): User | undefined {
    return this.data.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  }

  public findUserById(id: string): User | undefined {
    return this.data.users.find((u) => u.id === id);
  }

  public createUser(user: Omit<User, 'id' | 'createdAt' | 'xp' | 'level'>): User {
    const newUser: User = {
      id: 'usr_' + crypto.randomUUID(),
      ...user,
      xp: 0,
      level: 1,
      createdAt: new Date().toISOString()
    };
    this.data.users.push(newUser);
    this.saveData();
    return newUser;
  }

  public updateUserProfile(userId: string, updates: Partial<User>): User | undefined {
    const user = this.findUserById(userId);
    if (!user) return undefined;
    Object.assign(user, updates);
    this.saveData();
    return user;
  }

  public addXP(userId: string, xpToAdd: number): { user: User; leveledUp: boolean } {
    const user = this.findUserById(userId);
    if (!user) throw new Error('User not found');
    const oldLevel = user.level;
    user.xp += xpToAdd;
    // Level formula: Level = floor(XP / 250) + 1
    const newLevel = Math.floor(user.xp / 250) + 1;
    const leveledUp = newLevel > oldLevel;
    user.level = newLevel;

    // Check achievement for first XP
    if (user.xp >= 100) {
      this.unlockAchievement(userId, 'first_challenge');
    }
    if (user.level >= 3) {
      this.unlockAchievement(userId, 'level_3_reached');
    }

    this.saveData();
    return { user, leveledUp };
  }

  // --- Stations & Trains ---
  public getStations(): Station[] {
    return this.data.stations;
  }

  public getTrains(fromCode?: string, toCode?: string): Train[] {
    let list = this.data.trains;
    if (fromCode && toCode) {
      const fromSt = this.data.stations.find((s) => s.code.toUpperCase() === fromCode.toUpperCase());
      const toSt = this.data.stations.find((s) => s.code.toUpperCase() === toCode.toUpperCase());
      if (fromSt && toSt) {
        list = list.filter((t) => {
          const fromIdx = t.intermediateStations.indexOf(fromSt.id);
          const toIdx = t.intermediateStations.indexOf(toSt.id);
          return fromIdx !== -1 && toIdx !== -1 && fromIdx < toIdx;
        });
      }
    }
    return list;
  }

  public getTrainById(id: string): Train | undefined {
    return this.data.trains.find((t) => t.id === id);
  }

  // --- Real Seat Inventory & Availability Computation ---
  public getSeatAvailability(trainId: string, travelDate: string, travelClass: '1A' | '2A' | '3A' | 'SL') {
    const train = this.getTrainById(trainId);
    if (!train) throw new Error('Train not found');
    const classConfig = train.classes.find((c) => c.type === travelClass);
    if (!classConfig) throw new Error(`Class ${travelClass} not configured for this train`);

    // Get active confirmed bookings for this train, date, class
    const confirmedBookings = this.data.bookings.filter(
      (b) => b.trainId === trainId && b.journeyDate === travelDate && b.travelClass === travelClass && b.status === 'CONFIRMED'
    );

    const bookedSeatCount = confirmedBookings.reduce((sum, b) => sum + b.passengers.length, 0);
    const availableSeats = Math.max(0, classConfig.totalSeats - bookedSeatCount);

    // Get current waiting list count
    const waitingEntries = this.data.waitingList.filter(
      (w) => w.trainId === trainId && w.journeyDate === travelDate && w.travelClass === travelClass
    );
    const waitingCount = waitingEntries.reduce((sum, w) => sum + w.passengerNames.length, 0);

    return {
      totalSeats: classConfig.totalSeats,
      bookedSeats: bookedSeatCount,
      availableSeats,
      isWaitingList: availableSeats <= 0,
      currentWaitingCount: waitingCount,
      fare: classConfig.fare
    };
  }

  // --- Real 10-Digit PNR Generator ---
  private generateUniquePNR(): string {
    let pnr = '';
    let exists = true;
    while (exists) {
      // 10 digits starting with 2-9
      const firstDigit = Math.floor(Math.random() * 8) + 2;
      const rest = Math.floor(Math.random() * 900000000) + 100000000;
      pnr = `${firstDigit}${rest}`;
      exists = this.data.bookings.some((b) => b.pnr === pnr);
    }
    return pnr;
  }

  // --- Real Booking Flow & Waiting List Enqueue ---
  public createBooking(params: {
    userId: string;
    trainId: string;
    journeyDate: string;
    travelClass: '1A' | '2A' | '3A' | 'SL';
    passengers: { name: string; age: number; gender: 'M' | 'F' | 'O'; berthPreference?: string }[];
  }): { booking: Booking; dsaEvent: DSAEvent } {
    const user = this.findUserById(params.userId);
    if (!user) throw new Error('User not found');
    const train = this.getTrainById(params.trainId);
    if (!train) throw new Error('Train not found');
    const classConfig = train.classes.find((c) => c.type === params.travelClass);
    if (!classConfig) throw new Error('Invalid class');

    const fromStation = this.data.stations.find((s) => s.id === train.sourceStationId);
    const toStation = this.data.stations.find((s) => s.id === train.destinationStationId);

    const availability = this.getSeatAvailability(params.trainId, params.journeyDate, params.travelClass);
    const pnr = this.generateUniquePNR();
    const now = new Date().toISOString();

    const isConfirmed = availability.availableSeats >= params.passengers.length;
    let waitingNumber: number | undefined;
    let finalPassengers: Passenger[] = [];

    let dsaEvent: DSAEvent;

    if (isConfirmed) {
      // Allocate real seats
      const bookedBookings = this.data.bookings.filter(
        (b) => b.trainId === params.trainId && b.journeyDate === params.journeyDate && b.travelClass === params.travelClass && b.status === 'CONFIRMED'
      );
      const usedSeatNumbers = new Set<number>();
      bookedBookings.forEach((b) => {
        b.passengers.forEach((p) => {
          if (p.allocatedSeat) {
            const num = parseInt(p.allocatedSeat.replace(/\D/g, ''), 10);
            if (!isNaN(num)) usedSeatNumbers.add(num);
          }
        });
      });

      const berths = ['Lower', 'Middle', 'Upper', 'Side Lower', 'Side Upper', 'Window'];
      let nextSeat = 1;
      finalPassengers = params.passengers.map((p, idx) => {
        while (usedSeatNumbers.has(nextSeat)) {
          nextSeat++;
        }
        usedSeatNumbers.add(nextSeat);
        const berth = p.berthPreference || berths[(nextSeat - 1) % berths.length];
        return {
          ...p,
          allocatedSeat: `${params.travelClass}-${nextSeat}`,
          allocatedBerth: berth
        };
      });

      dsaEvent = {
        id: 'ev_' + crypto.randomUUID(),
        type: 'SEAT_ALLOCATED',
        title: `Seat Allocated for PNR ${pnr}`,
        operation: 'Array Index Allocation O(1)',
        principle: 'Direct Indexed Memory Slot',
        complexity: 'O(1)',
        spaceComplexity: 'O(1)',
        railwayUse: 'Assigning physical berth slots directly to confirmed passengers',
        details: `Confirmed ${params.passengers.length} seat(s) in Coach ${params.travelClass}. Berths: ${finalPassengers.map((p) => p.allocatedSeat).join(', ')}.`,
        timestamp: now,
        meta: { pnr, seats: finalPassengers.map((p) => p.allocatedSeat) }
      };
    } else {
      // Capacity reached -> ENQUEUE to Real Waiting List (FIFO Queue)
      const existingWaitings = this.data.waitingList.filter(
        (w) => w.trainId === params.trainId && w.journeyDate === params.journeyDate && w.travelClass === params.travelClass
      );
      const currentHighestPos = existingWaitings.length > 0 ? Math.max(...existingWaitings.map((w) => w.position)) : 0;
      waitingNumber = currentHighestPos + 1;

      finalPassengers = params.passengers.map((p) => ({
        ...p,
        allocatedSeat: `WL-${waitingNumber}`,
        allocatedBerth: 'Waiting List'
      }));

      // Add to waiting list collection
      const wlEntry: WaitingListEntry = {
        id: 'wl_' + crypto.randomUUID(),
        bookingId: '', // set after booking creation
        pnr,
        trainId: params.trainId,
        journeyDate: params.journeyDate,
        travelClass: params.travelClass,
        position: waitingNumber,
        passengerNames: params.passengers.map((p) => p.name),
        createdAt: now
      };

      dsaEvent = {
        id: 'ev_' + crypto.randomUUID(),
        type: 'QUEUE_ENQUEUE',
        title: `Passenger Joined Waiting List (WL${waitingNumber})`,
        operation: 'enqueue(passenger)',
        principle: 'FIFO — First In, First Out',
        complexity: 'O(1)',
        spaceComplexity: 'O(N)',
        railwayUse: 'Waiting list queue: New waiting passengers are strictly placed at the rear of the line',
        details: `Coach capacity full. PNR ${pnr} added to FIFO Queue at Position ${waitingNumber}.`,
        timestamp: now,
        meta: { pnr, position: waitingNumber }
      };

      // Temporarily store wlEntry
      (params as any)._pendingWLEntry = wlEntry;
    }

    const totalFare = classConfig.fare * params.passengers.length;

    const newBooking: Booking = {
      id: 'bk_' + crypto.randomUUID(),
      pnr,
      userId: user.id,
      userEmail: user.email,
      userName: user.name,
      trainId: train.id,
      trainNumber: train.trainNumber,
      trainName: train.name,
      fromStationCode: fromStation?.code || 'SRC',
      toStationCode: toStation?.code || 'DST',
      journeyDate: params.journeyDate,
      travelClass: params.travelClass,
      passengers: finalPassengers,
      status: isConfirmed ? 'CONFIRMED' : 'WAITING',
      waitingNumber,
      totalFare,
      createdAt: now
    };

    if ((params as any)._pendingWLEntry) {
      const wl = (params as any)._pendingWLEntry as WaitingListEntry;
      wl.bookingId = newBooking.id;
      this.data.waitingList.push(wl);
    }

    this.data.bookings.push(newBooking);
    this.data.dsaEvents.unshift(dsaEvent);

    // Achievements check
    this.unlockAchievement(user.id, 'first_booking');
    if (!isConfirmed) {
      this.unlockAchievement(user.id, 'waiting_list_explorer');
    }

    this.saveData();
    return { booking: newBooking, dsaEvent };
  }

  // --- Real Ticket Cancellation with FIFO Promotion ---
  public cancelBooking(bookingId: string, userId: string): {
    cancelledBooking: Booking;
    promotedBooking?: Booking;
    events: DSAEvent[];
  } {
    const booking = this.data.bookings.find((b) => b.id === bookingId && b.userId === userId);
    if (!booking) throw new Error('Booking not found or unauthorized');
    if (booking.status === 'CANCELLED') throw new Error('Booking is already cancelled');

    const now = new Date().toISOString();
    const wasConfirmed = booking.status === 'CONFIRMED';
    booking.status = 'CANCELLED';
    booking.cancellationDate = now;

    const events: DSAEvent[] = [];

    // DSA Event: Stack Push of Cancellation Record
    events.push({
      id: 'ev_' + crypto.randomUUID(),
      type: 'STACK_PUSH',
      title: `Booking Cancelled (PNR: ${booking.pnr})`,
      operation: 'push(cancelledRecord)',
      principle: 'LIFO — Last In, First Out Action Stack',
      complexity: 'O(1)',
      spaceComplexity: 'O(1)',
      railwayUse: 'Cancellation audit log & undo / refund processing history',
      details: `Ticket cancelled for PNR ${booking.pnr}. Record pushed to action audit stack.`,
      timestamp: now,
      meta: { pnr: booking.pnr }
    });

    let promotedBooking: Booking | undefined;

    if (wasConfirmed) {
      events.push({
        id: 'ev_' + crypto.randomUUID(),
        type: 'SEAT_RELEASED',
        title: `Seat Released for ${booking.trainNumber}`,
        operation: 'free(seat_slot)',
        principle: 'Memory / Inventory Reclamation',
        complexity: 'O(1)',
        spaceComplexity: 'O(1)',
        railwayUse: 'Vacated berth is immediately made available for waiting list promotion',
        details: `Released seat(s): ${booking.passengers.map((p) => p.allocatedSeat).join(', ')}.`,
        timestamp: now
      });

      // Check Waiting List Queue for earliest eligible entry (FIFO DEQUEUE)
      const waitingEntries = this.data.waitingList
        .filter(
          (w) => w.trainId === booking.trainId && w.journeyDate === booking.journeyDate && w.travelClass === booking.travelClass
        )
        .sort((a, b) => a.position - b.position);

      if (waitingEntries.length > 0) {
        // Dequeue earliest entry (WL1)
        const earliestWL = waitingEntries[0];
        this.data.waitingList = this.data.waitingList.filter((w) => w.id !== earliestWL.id);

        // Find the actual booking record for this waiting passenger
        const targetBooking = this.data.bookings.find((b) => b.id === earliestWL.bookingId);
        if (targetBooking && targetBooking.status === 'WAITING') {
          targetBooking.status = 'CONFIRMED';
          targetBooking.waitingNumber = undefined;

          // Reallocate the vacated seat to the promoted passenger
          const releasedSeat = booking.passengers[0]?.allocatedSeat || `${booking.travelClass}-1`;
          targetBooking.passengers = targetBooking.passengers.map((p, idx) => ({
            ...p,
            allocatedSeat: releasedSeat,
            allocatedBerth: 'Confirmed Promotion'
          }));

          promotedBooking = targetBooking;

          // Event: Queue Dequeue
          events.push({
            id: 'ev_' + crypto.randomUUID(),
            type: 'QUEUE_DEQUEUE',
            title: `Queue Dequeue: PNR ${targetBooking.pnr} Promoted!`,
            operation: 'dequeue()',
            principle: 'FIFO — First In, First Out',
            complexity: 'O(1)',
            spaceComplexity: 'O(1)',
            railwayUse: 'Earliest waiting-list passenger is promoted first to ensure 100% fairness',
            details: `Passenger from WL1 promoted to CONFIRMED. Assigned berth: ${releasedSeat}.`,
            timestamp: now,
            meta: { promotedPnr: targetBooking.pnr, seat: releasedSeat }
          });

          // Recalculate remaining waiting list positions (Shift queue: WL2 -> WL1, WL3 -> WL2)
          const remainingWaiting = this.data.waitingList
            .filter(
              (w) => w.trainId === booking.trainId && w.journeyDate === booking.journeyDate && w.travelClass === booking.travelClass
            )
            .sort((a, b) => a.position - b.position);

          remainingWaiting.forEach((entry, idx) => {
            const newPos = idx + 1;
            entry.position = newPos;
            const bRecord = this.data.bookings.find((b) => b.id === entry.bookingId);
            if (bRecord) {
              bRecord.waitingNumber = newPos;
              bRecord.passengers.forEach((p) => {
                p.allocatedSeat = `WL-${newPos}`;
              });
            }
          });
        }
      }
    } else {
      // If a waiting ticket is cancelled, remove from waiting queue and reindex
      this.data.waitingList = this.data.waitingList.filter((w) => w.bookingId !== booking.id);
      const remainingWaiting = this.data.waitingList
        .filter(
          (w) => w.trainId === booking.trainId && w.journeyDate === booking.journeyDate && w.travelClass === booking.travelClass
        )
        .sort((a, b) => a.position - b.position);

      remainingWaiting.forEach((entry, idx) => {
        entry.position = idx + 1;
        const bRecord = this.data.bookings.find((b) => b.id === entry.bookingId);
        if (bRecord) {
          bRecord.waitingNumber = idx + 1;
        }
      });
    }

    events.forEach((ev) => this.data.dsaEvents.unshift(ev));
    this.saveData();
    return { cancelledBooking: booking, promotedBooking, events };
  }

  // --- Real User Bookings Retrieval ---
  public getUserBookings(userId: string): Booking[] {
    return this.data.bookings
      .filter((b) => b.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  // --- PNR Status Lookup with Real Hash Map Computation ---
  public getBookingByPNR(pnrQuery: string): {
    booking: Booking | null;
    hashDetails: {
      pnr: string;
      numBuckets: number;
      bucketIndex: number;
      hashFunctionFormula: string;
      rawHashValue: number;
      chainDepth: number;
      lookupComplexity: string;
      isMatch: boolean;
      allBuckets: { index: number; count: number; activePnr?: string }[];
    };
    dsaEvent: DSAEvent;
  } {
    const cleanPNR = pnrQuery.trim();
    const NUM_BUCKETS = 16;

    // Polynomial Rolling Hash computation for PNR string
    let hash = 0;
    const PRIME = 31;
    for (let i = 0; i < cleanPNR.length; i++) {
      hash = (hash * PRIME + cleanPNR.charCodeAt(i)) % 1000000007;
    }
    const bucketIndex = Math.abs(hash) % NUM_BUCKETS;

    // Map all active bookings in DB into hash table buckets
    const bucketMap: { [key: number]: string[] } = {};
    for (let i = 0; i < NUM_BUCKETS; i++) {
      bucketMap[i] = [];
    }

    this.data.bookings.forEach((b) => {
      let bHash = 0;
      for (let i = 0; i < b.pnr.length; i++) {
        bHash = (bHash * PRIME + b.pnr.charCodeAt(i)) % 1000000007;
      }
      const bIdx = Math.abs(bHash) % NUM_BUCKETS;
      bucketMap[bIdx].push(b.pnr);
    });

    const chain = bucketMap[bucketIndex] || [];
    const chainDepth = chain.indexOf(cleanPNR) !== -1 ? chain.indexOf(cleanPNR) + 1 : 1;

    // Direct O(1) Lookup in Bookings array
    const booking = this.data.bookings.find((b) => b.pnr === cleanPNR) || null;

    const allBuckets = Object.keys(bucketMap).map((key) => {
      const idx = parseInt(key, 10);
      return {
        index: idx,
        count: bucketMap[idx].length,
        activePnr: bucketMap[idx][0]
      };
    });

    const dsaEvent: DSAEvent = {
      id: 'ev_' + crypto.randomUUID(),
      type: 'HASH_LOOKUP',
      title: `PNR Hash Map Lookup for ${cleanPNR}`,
      operation: `hash("${cleanPNR}") → Bucket [${bucketIndex}]`,
      principle: 'Hash Function & O(1) Direct Key Addressing',
      complexity: 'O(1) Average',
      spaceComplexity: 'O(N)',
      railwayUse: 'Instant O(1) retrieval of booking tickets among millions of records without scanning the whole DB',
      details: booking
        ? `Found booking record for PNR ${cleanPNR} in Bucket #${bucketIndex} (Chain depth: ${chainDepth}).`
        : `Key "${cleanPNR}" mapped to Bucket #${bucketIndex}, slot is empty/no matching ticket record.`,
      timestamp: new Date().toISOString(),
      meta: { pnr: cleanPNR, bucketIndex, match: !!booking }
    };

    this.data.dsaEvents.unshift(dsaEvent);
    this.saveData();

    return {
      booking,
      hashDetails: {
        pnr: cleanPNR,
        numBuckets: NUM_BUCKETS,
        bucketIndex,
        hashFunctionFormula: `h(key) = (\\sum key[i] \\times 31^{n-i}) \\bmod ${NUM_BUCKETS}`,
        rawHashValue: hash,
        chainDepth,
        lookupComplexity: 'O(1) average / O(k) chain',
        isMatch: !!booking,
        allBuckets
      },
      dsaEvent
    };
  }

  // --- DSA Events ---
  public getDSAEvents(limit = 20): DSAEvent[] {
    return this.data.dsaEvents.slice(0, limit);
  }

  // --- Achievements ---
  public getUserAchievements(userId: string): { id: string; unlockedAt: string }[] {
    return this.data.achievements.filter((a) => a.userId === userId);
  }

  public unlockAchievement(userId: string, achievementId: string): boolean {
    const existing = this.data.achievements.find((a) => a.userId === userId && a.achievementId === achievementId);
    if (existing) return false;

    this.data.achievements.push({
      id: 'ach_' + crypto.randomUUID(),
      userId,
      achievementId,
      unlockedAt: new Date().toISOString()
    });
    this.saveData();
    return true;
  }

  // --- Game Attempts ---
  public recordGameAttempt(params: {
    userId: string;
    level: number;
    challengeId: string;
    selectedOption: string;
    isCorrect: boolean;
    score: number;
    xpEarned: number;
    language: string;
  }): { attempt: GameAttempt; totalXp: number; level: number } {
    const attempt: GameAttempt = {
      id: 'att_' + crypto.randomUUID(),
      ...params,
      timestamp: new Date().toISOString()
    };
    this.data.gameAttempts.push(attempt);

    let totalXp = 0;
    let userLevel = 1;

    if (params.xpEarned > 0) {
      const xpRes = this.addXP(params.userId, params.xpEarned);
      totalXp = xpRes.user.xp;
      userLevel = xpRes.user.level;

      if (params.level >= 6 && params.isCorrect) {
        this.unlockAchievement(params.userId, 'algorithm_master');
      }
    } else {
      const user = this.findUserById(params.userId);
      if (user) {
        totalXp = user.xp;
        userLevel = user.level;
      }
    }

    this.saveData();
    return { attempt, totalXp, level: userLevel };
  }

  public getUserGameStats(userId: string) {
    const attempts = this.data.gameAttempts.filter((a) => a.userId === userId);
    const totalAttempts = attempts.length;
    const correctAttempts = attempts.filter((a) => a.isCorrect).length;
    const accuracy = totalAttempts > 0 ? Math.round((correctAttempts / totalAttempts) * 100) : 0;

    return {
      totalAttempts,
      correctAttempts,
      accuracy,
      levelsCompleted: Array.from(new Set(attempts.filter((a) => a.isCorrect).map((a) => a.level)))
    };
  }

  // --- Admin Stats (REAL DATA ONLY - NO FAKE METRICS) ---
  public getSystemMetrics() {
    return {
      registeredUsers: this.data.users.length,
      totalBookings: this.data.bookings.length,
      confirmedBookings: this.data.bookings.filter((b) => b.status === 'CONFIRMED').length,
      waitingListEntries: this.data.waitingList.length,
      cancellations: this.data.bookings.filter((b) => b.status === 'CANCELLED').length,
      dsaOperationsRecorded: this.data.dsaEvents.length,
      gameAttempts: this.data.gameAttempts.length
    };
  }
}

export const db = new DatabaseService();
